<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Setting_bdp_model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	function get_daftar_pendidikan($count=false,$param='',$order='',$start='',$limits='')
	{
		$brilliance = $this->load->database('aspirasi', true);
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $brilliance->escape($item);
								}else{
									$arr_temp[$idx] = $brilliance->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $brilliance->escape($value['value']);
							}else{
								$field_value = $brilliance->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE JenisPendidikan <> '' AND ".$where : " WHERE JenisPendidikan <> '' ";
		$table = "(SELECT ID_SDP AS IdPendidikan, Alias, CorporateTitle AS CtDir, Deskripsi, 'SC' AS JenisPendidikan, 'Soft Competency' AS JenisPendidikanDesc, Status, Modified, ModifiedBy
		FROM MasterSoftCompetency
		UNION 
		SELECT ID_HDP AS IdPendidikan, Alias, Direktorat AS CtDir, Deskripsi, 'HC' AS JenisPendidikan, 'Hard Competency' AS JenisPendidikanDesc, Status, Modified, ModifiedBy
		FROM MasterHardCompetency) edu";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $brilliance->query($qstr);
			$brilliance->close();
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT * FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $brilliance->query($qstr);
			$brilliance->close();
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}
	
	function insert_pendidikan($jenis_pendidikan, $data)
	{
		if(!$this->is_pendidikan_exist($jenis_pendidikan, $data['Deskripsi'])){
			$insert = false;
			$brilliance = $this->load->database('aspirasi', true);

			if($jenis_pendidikan == 'SC'){
				$insert = $brilliance->insert('MasterSoftCompetency', $data);
			}
			elseif($jenis_pendidikan == 'HC'){
				$insert = $brilliance->insert('MasterHardCompetency', $data);
			}

			if($insert){
				$return = array('status'=>true,'message'=>'Pendidikan berhasil ditambahkan.');
			}else{
				$return = array('status'=>false,'message'=>'Pendidikan gagal ditambahkan.');
			}
			$brilliance->close();
		}else{
			$return = array('status'=>false,'message'=>'Pendidikan yang Anda masukkan sudah terdaftar.');
		}
		return $return;
	}
	
	function is_pendidikan_exist($jenis_pendidikan, $deskripsi_pendidikan)
	{
		$brilliance = $this->load->database('aspirasi', true);
		$num_rows = 0;
		if($jenis_pendidikan == 'SC'){
			$query = $brilliance->get_where('MasterSoftCompetency',array('Deskripsi'=>$deskripsi_pendidikan));
			$num_rows = $query->num_rows();
		}
		elseif($jenis_pendidikan == 'HC'){
			$query = $brilliance->get_where('MasterHardCompetency',array('Deskripsi'=>$deskripsi_pendidikan));
			$num_rows = $query->num_rows();
		}
		$brilliance->close();
		if($num_rows>0){
			return true;
		}else{
			return false;
		}
	}
	
	function update_pendidikan($data, $jenis_pendidikan, $id_pendidikan)
	{
		$brilliance = $this->load->database('aspirasi', true);
		$update = false;

		if($jenis_pendidikan == 'SC'){
			$update = $brilliance->update('MasterSoftCompetency', $data, array('ID_SDP' => $id_pendidikan));
		}
		elseif($jenis_pendidikan == 'HC'){
			$update = $brilliance->update('MasterHardCompetency', $data, array('ID_HDP' => $id_pendidikan));
		}

		if($update){
			$return = array('status'=>true,'message'=>'Pendidikan berhasil diupdate.');
		}else{
			$return = array('status'=>false,'message'=>'Pendidikan gagal diupdate.');
		}
		$brilliance->close();
		return $return;
	}

	function mst_jenis_pendidikan() 
	{
        $jenis_pendidikan    = array();
		$jenis_pendidikan[''] = '- Pilih Jenis Pendidikan -';
		$jenis_pendidikan['SC'] = 'Soft Competency';
		$jenis_pendidikan['HC'] = 'Hard Competency';
       
        return $jenis_pendidikan;
	}
	
	function mst_corporate_title() 
	{
		$this->db->order_by('urutan asc');
        $query      = $this->db->get_where('MasterCorpTitle', array('status' => 1));
        $ct    = array();
		$ct[''] = '- Pilih Corporate Title -';
        foreach ($query->result() as $row) {
            $ct[$row->corp_title_id] = $row->corp_title_desc;
        }
        return $ct;
	}
	
	function get_pendidikan($jenis_pendidikan, $id_pendidikan)
	{
		$brilliance = $this->load->database('aspirasi', true);
		$num_rows = 0;
		if($jenis_pendidikan == 'SC'){
			$query = $brilliance->get_where('MasterSoftCompetency',array('ID_SDP'=>$id_pendidikan));
			$num_rows = $query->num_rows();
		}
		elseif($jenis_pendidikan == 'HC'){
			$query = $brilliance->get_where('MasterHardCompetency',array('ID_HDP'=>$id_pendidikan));
			$num_rows = $query->num_rows();
		}
		$brilliance->close();
		if($num_rows>0){
			return $query->row();
		}else{
			return false;
		}
	}

	function get_register_pendidikan($count=false,$param='',$order='',$start='',$limits='')
	{
		$brilliance = $this->load->database('aspirasi', true);
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $brilliance->escape($item);
								}else{
									$arr_temp[$idx] = $brilliance->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $brilliance->escape($value['value']);
							}else{
								$field_value = $brilliance->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE edu.JenisPendidikan <> '' AND ".$where : " WHERE edu.JenisPendidikan <> '' ";
		$table = "(
		SELECT a.RegisterID, a.Pernr, a.Keterangan, b.Deskripsi AS PendidikanDesc , a.DevType AS JenisPendidikan, 'Soft Competency' AS JenisPendidikanDesc, a.Modified, a.ModifiedBy
		FROM RegisterDevelopment a
		INNER JOIN MasterSoftCompetency b on a.DevID = b.ID_SDP
		WHERE a.DevType = 'SC'
		UNION 
		SELECT a.RegisterID, a.Pernr, a.Keterangan, b.Deskripsi AS PendidikanDesc , a.DevType AS JenisPendidikan, 'Hard Competency' AS JenisPendidikanDesc, a.Modified, a.ModifiedBy
		FROM RegisterDevelopment a
		INNER JOIN MasterHardCompetency b on a.DevID = b.ID_HDP
		WHERE a.DevType = 'HC'
		) edu 
		INNER JOIN pa0001_eof eof ON edu.Pernr = eof.PERNR";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $brilliance->query($qstr);
			$brilliance->close();
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT edu.*, eof.SNAME as Nama FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $brilliance->query($qstr);
			$brilliance->close();
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	function delete_register_pendidikan($condition)
	{
		$brilliance = $this->load->database('aspirasi', true);
		$delete = false;

		$delete = $brilliance->delete('RegisterDevelopment', $condition);

		if($delete){
			$return = array('status'=>true,'message'=>'Register pendidikan berhasil dihapus.');
		}else{
			$return = array('status'=>false,'message'=>'Register pendidikan gagal dihapus.');
		}
		$brilliance->close();
		return $return;
	}

	function upload_register_pendidikan($file)
	{
		if(!empty($file)){
			try {
				$return = FALSE;
				$brilliance = $this->load->database('aspirasi', true);
				$brilliance->trans_begin();
				$tmp_table = $this->libs->generate_unique_name('tmp_register_pendidikan');
				$qstr = "DROP TABLE IF EXISTS `{$tmp_table}`;";
				$brilliance->query($qstr);
				$qstr = "CREATE TEMPORARY TABLE IF NOT EXISTS `{$tmp_table}` (
							`Pernr` varchar(8) COLLATE latin1_general_ci DEFAULT NULL,
							`DevType` enum('SC','HC') COLLATE latin1_general_ci DEFAULT NULL,
							`DevID` int(11) DEFAULT NULL,
							`Keterangan` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
							PRIMARY KEY (`Pernr`, `DevType`, `DevID`),
							INDEX `IDX01` (`Pernr`, `DevType`, `DevID`)
						) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;";
				$brilliance->query($qstr);

				$filename = fopen($file, "r");
				$i = 0;
				while (($emapData = fgetcsv($filename, 10000, "@")) !== FALSE)
				{
					if($i > 0){
						$qstr = "INSERT IGNORE INTO `{$tmp_table}` VALUES('$emapData[0]','$emapData[1]','$emapData[2]','$emapData[3]')";
						$brilliance->query($qstr);
					}
					$i++;
				}
				fclose($filename);
			
				$qstr = "REPLACE INTO RegisterDevelopment SELECT 0, LPAD(REPLACE(REPLACE(Pernr, '\r', ''), '\n', ''), 8 , '0'), DevType, DevID,  Keterangan, NOW(),'".$_SESSION[$this->config->item('session_prefix')]['pernr'].'|'.$_SESSION[$this->config->item('session_prefix')]['nama']."'  FROM `{$tmp_table}`;";
				$brilliance->query($qstr);
				if ($brilliance->trans_status() === FALSE){
					$brilliance->trans_rollback();
					$return = FALSE;
				}else{
					$brilliance->trans_commit();
					$return = TRUE;
				}
				$brilliance->close();
				return $return;
			}catch(Exception $e){
				return FALSE;
			}
		}else{
			return FALSE;
		}
	}
}