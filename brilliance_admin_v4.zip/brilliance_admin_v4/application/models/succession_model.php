<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class succession_model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	public function getOptBucket($orgeh='', $hilfm='', $corp_title_id = ''){
		$query_plans = "select * from TalentBucket where OrgUnit = '{$orgeh}' and Hilfm = '{$hilfm}' and CorpTitleId= '{$corp_title_id}' and Status not in (4) and Modifier = '{$_SESSION[$this->config->item('session_prefix')]['pernr']}' order by ModifiedDate desc";
		//echo $query_plans;
		$query = $this->db->query($query_plans);
		$data = array();
		foreach ($query->result() as $row) {
			$data[$row->IdBucket] =  $row->BucketName;
		}
		return $data;
	}

	public function mst_jf(){
		$query = "select * from JOB_FAMILY where FLAG = ? order by initials";
		$query = $this->db->query($query, array('JF'));
		$data = array();
		foreach ($query->result() as $row) {
			$data[$row->INITIALS] =  '['.$row->INITIALS.'] '.$row->DESKRIPSI;
		}
		return $data;
	}

	public function mst_sjf($jf=''){
		$query = "select * from JOB_FAMILY where FLAG = ? AND PARENT = ? order by initials";
		$query = $this->db->query($query, array('SJF', $jf));
		return $query->result();
	}

	function get_successors($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "SuccessionPlanOverallCompability";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT *, Rank as SetRank FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	function get_bucket_successors($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "TalentCandidatesResults";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT *, Urutan as SetRank FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	function get_candidates($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "TalentBucket a";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	function insert_candidates_bucket($param_ins, $param){
		try{
			$this->db->trans_begin();
			
			$this->db->insert('TalentBucket', $param_ins);
			$ins_id = $this->db->insert_id();
			
			$qstr = "insert into TalentCandidatesResults select {$ins_id} as IdBucket, a.*, @rank:=@rank+1 AS Urutan
			from SuccessionPlanOverallCompability a 
			join (select @rank:=0) b
			where a.OrgUnit = '{$param['orgeh']}' and a.Hilfm = '{$param['hilfm']}' and a.CorpTitleId = '{$param['corp_title_id']}' and a.IsChecked = 1 
			order by a.Rank;";
			
			$this->db->query($qstr);
	
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				return array('status'=>false,'message'=>'Data gagal disimpan.');
			} else { 
				$this->db->trans_commit();
				return array('status'=>true,'message'=>'Data berhasil disimpan.');
			}
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return array('status'=>false,'message'=>'Data gagal disimpan. Terjadi kesalahan sistem.');
        }
	}

	function insert_new_candidates_bucket($param_ins, $param){
		try{
			$this->db->trans_begin();
			
			$this->db->insert('TalentBucket', $param_ins);
			$ins_id = $this->db->insert_id();
			
			$qstr = "insert into TalentCandidatesResults 
			select {$ins_id} as id_bucket, a.pernr, a.keyjobs, a.overall_compability, a.overall_compability_category, a.overall_compability_class,
			a.nama, a.expertise, a.jobgrade, a.tanggallahir, a.area, a.subarea, a.costcenter, a.talent_class, a.talent_class_desc, a.corp_title_desc, a.htext,
			a.readiness, a.competency, a.skor_exp_compability, a.skor_jg_compability, a.skor_talent_compability, a.skor_potential_compability, a.skor_sertification_compability,
			a.skor_award_compability, a.bobot_exp, a.bobot_jg, a.bobot_talent, a.bobot_potential, a.bobot_sertification, a.bobot_award, a.rank, a.is_checked,
			@rank:=@rank+1 AS Urutan
			from TalentCandidatesResults a
			join (select @rank:=0) b
			where a.OrgUnit = '{$param['orgeh']}' and a.Hilfm = '{$param['hilfm']}' and a.IsChecked = 1 and a.IdBucket = '{$param['bucket']}'
			order by a.Rank;";
			
			$this->db->query($qstr);
	
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				return array('status'=>false,'message'=>'Data gagal disimpan.');
			} else { 
				$this->db->trans_commit();
				return array('status'=>true,'message'=>'Data berhasil disimpan.');
			}
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return array('status'=>false,'message'=>'Data gagal disimpan. Terjadi kesalahan sistem.');
        }
	}

	function update_ordered_list($param=array(), $new_urutan=0){
		try{
			$this->db->trans_begin();
			$ret = array('status' => false, 'message'=> 'Terjadi Kesalahan Sistem.');
		
			$candidates = $this->db->get_where('TalentCandidatesResults', $param)->row();
			
			if($candidates->Urutan > $new_urutan){
				$str = "update TalentCandidatesResults set Urutan = (Urutan+1) where IdBucket = {$candidates->IdBucket} and OrgUnit = '{$candidates->OrgUnit}' and Hilfm = '{$candidates->Hilfm}' and CorpTitleId = '{$candidates->CorpTitleId}' and Urutan < {$candidates->Urutan} and Urutan >= {$new_urutan}";
				$exe = $this->db->query($str);
			}
			else{
				$str = "update TalentCandidatesResults set Urutan = (Urutan-1) where IdBucket = {$candidates->IdBucket} and OrgUnit = '{$candidates->OrgUnit}' and Hilfm = '{$candidates->Hilfm}' and CorpTitleId = '{$candidates->CorpTitleId}' and Urutan <= {$new_urutan} and Urutan > {$candidates->Urutan}";
				$exe = $this->db->query($str);
			}
			//echo $str;
			$this->db->update('TalentCandidatesResults', array('Urutan' => $new_urutan), $param);
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
			} else { 
				$this->db->trans_commit();
				$ret['status'] = true;
				$ret['message'] = 'Perubahan berhasil disimpan.';
			}
			return $ret;
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return $ret;
        }
	}

	function delete_candidates($param){
		try{
			$this->db->trans_begin();
			$ret = array('status' => false, 'message'=> 'Terjadi Kesalahan Sistem.');
			$candidates = $this->db->get_where('TalentCandidatesResults', $param)->row();
			
			$this->db->delete('TalentCandidatesResults', $param);
			
			$str = "update TalentCandidatesResults set Urutan = (Urutan-1) where IdBucket = {$candidates->IdBucket} and OrgUnit = '{$candidates->OrgUnit}' and Hilfm = '{$candidates->Hilfm}' and CorpTitleId = '{$candidates->CorpTitleId}' and Urutan > {$candidates->Urutan} ";
			$exe = $this->db->query($str);

			$modify = array(
				'Modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
				, 'ModifiedBy' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
				, 'ModifiedDate' => date('Y-m-d H:i:s')
			);
			$this->db->update('TalentBucket', $modify, array('IdBucket' => $param['IdBucket']));
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
			} else { 
				$this->db->trans_commit();
				$ret['status'] = true;
				$ret['message'] = 'Perubahan berhasil disimpan.';
			}
			return $ret;
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return $ret;
        }
	}

	function save_new_candidates($param, $candidates, $keyjobs){
		try{
			$this->db->trans_begin();
			$ret = array('status' => false, 'message'=> 'Terjadi Kesalahan Sistem.');
			
			$this->db->select('max(urutan) as maks_urutan');
			$talent = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $param['IdBucket']))->row();

			$orgeh = isset($keyjobs->orgeh)?$keyjobs->orgeh:'';
			$hilfm = isset($keyjobs->hilfm)?$keyjobs->hilfm:'';
			$corp_title_id = isset($keyjobs->corp_title_id)?$keyjobs->corp_title_id:'';
			$jg = isset($keyjobs->jobgrade)?$keyjobs->jobgrade:'';
			$c_pernr = isset($candidates->PERNR)?$candidates->PERNR:'';

			$corp_title_condition = "";
			$corp_title_array = array();
			if($corp_title_id == 'SM' || $corp_title_id == 'AVP'){
				$corp_title_condition = "'SM', 'AVP'";
				$corp_title_array = array('SM', 'AVP');
			}
			elseif($corp_title_id == 'SEVP' || $corp_title_id == 'DIR'){
				$corp_title_condition = "'SEVP', 'DIR'";
				$corp_title_array = array('SEVP', 'DIR');
			}
			else{
				$corp_title_condition = "'".$corp_title_id."'";
				$corp_title_array = array($corp_title_id);
			}
		
			$qstr = "SELECT '{$orgeh}' AS OrgUnit, '{$hilfm}' AS Hilfm, '{$corp_title_id}' AS CorpTitleId,
						EXP.PERNR, PA.SNAME, THM.expertise AS Expertise, SUBSTRING(PA.JGPG, 3,2) AS JobGrade, PA.TANGGALLAHIR, PA.WERKS_TX, PA.BTRTL_TX, PA.KOSTL_TX, 
						THM.talent_class, THM.talent_class_desc, THM.corp_title_desc, PA.htext, THM.readiness, THM.competency,
						EXP.SkorExpertiseCompability,
						CASE WHEN ({$jg}-SUBSTRING(PA.JGPG, 3,2)) = 0 THEN 3
						WHEN ({$jg}-SUBSTRING(PA.JGPG, 3,2)) = 1 THEN 2
						WHEN ({$jg}-SUBSTRING(PA.JGPG, 3,2)) = 2 THEN 1
						ELSE 0 END AS SkorJobGradeCompability,
						IFNULL(THM.poin_talent, 0) AS SkorTalentCompability,
						IFNULL(EAC.LEADERSHIP_COMPETENCY, 0) AS SkorPotentialCompability,
						CASE WHEN LAP.Pernr IS NOT NULL THEN 2*(IFNULL(ME.ManagementScore, 0)+IFNULL(SE.SuccessorScore, 0))
						ELSE (IFNULL(ME.ManagementScore, 0)+IFNULL(SE.SuccessorScore, 0)) END AS SkorEndorseCompability,
						IFNULL(EAS.AWARDS_SCORE, 0) AS SkorAwardsCompability,
						IFNULL(EBS.BLDP_SCORE, 0) AS SkorBLDPCompability,
						IFNULL(ESS.SOCIAL_SCORE, 0) AS SkorSocialCompability
						FROM (
							SELECT a.PERNR, GROUP_CONCAT(a.INITIALS SEPARATOR ',') AS Expertise, CASE WHEN COUNT(a.INITIALS) > 3 THEN 3 ELSE COUNT(a.INITIALS) END AS SkorExpertiseCompability
							FROM EMPLOYEE_EXPERTISES a
							INNER JOIN ORGEH_TECHNICALITIES b on a.INITIALS = b.INITIALS
							WHERE a.PERNR = '{$c_pernr}' AND a.FLAG = 'JF' AND b.ORGEH = '{$orgeh}' AND b.FLAG = 'JF'
							GROUP BY a.PERNR
						) EXP
						INNER JOIN talent_hav_matrix_aspirasi THM ON EXP.PERNR = THM.pernr AND THM.method = 1 and THM.type = 0 AND THM.jenis_asesmen = 1
						INNER JOIN pa0001_eof PA ON EXP.PERNR = PA.PERNR
						LEFT JOIN EMPLOYEE_AWARDS_SCORE EAS ON EXP.PERNR = EAS.PERNR
						LEFT JOIN EMPLOYEE_LEADERSHIP_COMPETENCY EAC ON EXP.PERNR = EAC.PERNR
						LEFT JOIN EMPLOYEE_BLDP_SCORE EBS ON EXP.PERNR = EBS.PERNR
						LEFT JOIN EMPLOYEE_SOCIAL_SCORE ESS ON EXP.PERNR = ESS.PERNR
						LEFT JOIN AspirasiKarirPekerja LAP ON EXP.PERNR = LAP.Pernr AND LAP.OrgUnit = '{$orgeh}' AND LAP.Hilfm = '{$hilfm}' AND LAP.CorporateTitleId IN (".$corp_title_condition.") AND LAP.StatusData = 1
						LEFT JOIN
						(
							SELECT Pernr, Nama, CASE WHEN COUNT(Pernr) >= 1 THEN 1 ELSE 0 END AS ManagementScore
							FROM AspirasiKarirEndorse
							WHERE Pernr = '{$c_pernr}' AND OrgUnit = '{$orgeh}' AND Hilfm = '{$hilfm}' AND CorporateTitleId IN (".$corp_title_condition.")
							GROUP BY Pernr, Nama
						) ME ON EXP.PERNR = ME.Pernr
						LEFT JOIN
						(
							SELECT Pernr, Nama, CASE WHEN COUNT(Pernr) >= 1 THEN 1 ELSE 0 END AS SuccessorScore
							FROM AspirasiSuksesorSaya
							WHERE Pernr = '{$c_pernr}' AND OrgUnitAction = '{$orgeh}' AND HilfmAction = '{$hilfm}' AND CorporateTitleIdAction IN (".$corp_title_condition.")
							GROUP BY Pernr, Nama
						) SE ON EXP.PERNR = SE.Pernr
						LEFT JOIN
						(
							SELECT Pernr, Nama, CASE WHEN COUNT(Pernr) >= 1 THEN 1 ELSE 0 END AS ManagementScore2
							FROM AspirasiKarirEndorseME2
							WHERE OrgUnit = '{$orgeh}' AND CorporateTitleId IN (".$corp_title_condition.") AND Hilfm = '{$hilfm}'
							GROUP BY Pernr, Nama
						) ME2 ON EXP.PERNR = ME2.Pernr
						WHERE PA.PERNR = '{$c_pernr}';";
			
			/*echo '<pre>';
			var_dump($qstr);
			echo '</pre>';
			die;*/
			$talent_result = $this->db->query($qstr)->row();
			
			if(!isset($talent_result->PERNR)){
				$qstr = "SELECT '{$orgeh}' AS OrgUnit, '{$hilfm}' AS Hilfm, '{$corp_title_id}' AS CorpTitleId,
						PA.PERNR, PA.SNAME, THM.expertise AS Expertise, SUBSTRING(PA.JGPG, 3,2) AS JobGrade, PA.TANGGALLAHIR, PA.WERKS_TX, PA.BTRTL_TX, PA.KOSTL_TX, 
						THM.talent_class, THM.talent_class_desc, THM.corp_title_desc, PA.htext, THM.readiness, THM.competency,
						0 AS SkorExpertiseCompability,
						CASE WHEN ({$jg}-SUBSTRING(PA.JGPG, 3,2)) = 0 THEN 3
						WHEN ({$jg}-SUBSTRING(PA.JGPG, 3,2)) = 1 THEN 2
						WHEN ({$jg}-SUBSTRING(PA.JGPG, 3,2)) = 2 THEN 1
						ELSE 0 END AS SkorJobGradeCompability,
						IFNULL(THM.poin_talent, 0) AS SkorTalentCompability,
						IFNULL(EAC.LEADERSHIP_COMPETENCY, 0) AS SkorPotentialCompability,
						CASE WHEN LAP.Pernr IS NOT NULL THEN 2*(IFNULL(ME.ManagementScore, 0)+IFNULL(SE.SuccessorScore, 0)+IFNULL(ME2.ManagementScore2, 0))
						ELSE (IFNULL(ME.ManagementScore, 0)+IFNULL(SE.SuccessorScore, 0)) END AS SkorEndorseCompability,
						IFNULL(EAS.AWARDS_SCORE, 0) AS SkorAwardsCompability,
						IFNULL(EBS.BLDP_SCORE, 0) AS SkorBLDPCompability,
						IFNULL(ESS.SOCIAL_SCORE, 0) AS SkorSocialCompability
						FROM pa0001_eof PA 
						INNER JOIN talent_hav_matrix_aspirasi THM ON PA.PERNR = THM.pernr AND THM.method = 1 and THM.type = 0 AND THM.jenis_asesmen = 1
						LEFT JOIN EMPLOYEE_AWARDS_SCORE EAS ON PA.PERNR = EAS.PERNR
						LEFT JOIN EMPLOYEE_LEADERSHIP_COMPETENCY EAC ON PA.PERNR = EAC.PERNR
						LEFT JOIN EMPLOYEE_BLDP_SCORE EBS ON PA.PERNR = EBS.PERNR
						LEFT JOIN EMPLOYEE_SOCIAL_SCORE ESS ON PA.PERNR = ESS.PERNR
						LEFT JOIN AspirasiKarirPekerja LAP ON PA.PERNR = LAP.Pernr AND LAP.OrgUnit = '{$orgeh}' AND LAP.Hilfm = '{$hilfm}' AND LAP.CorporateTitleId IN (".$corp_title_condition.") AND LAP.StatusData = 1
						LEFT JOIN
						(
							SELECT Pernr, Nama, CASE WHEN COUNT(Pernr) >= 1 THEN 1 ELSE 0 END AS ManagementScore
							FROM AspirasiKarirEndorse
							WHERE Pernr = '{$c_pernr}' AND OrgUnit = '{$orgeh}' AND Hilfm = '{$hilfm}' AND CorporateTitleId IN (".$corp_title_condition.")
							GROUP BY Pernr, Nama
						) ME ON PA.PERNR = ME.Pernr
						LEFT JOIN
						(
							SELECT Pernr, Nama, CASE WHEN COUNT(Pernr) >= 1 THEN 1 ELSE 0 END AS SuccessorScore
							FROM AspirasiSuksesorSaya
							WHERE Pernr = '{$c_pernr}' AND OrgUnitAction = '{$orgeh}' AND HilfmAction = '{$hilfm}' AND CorporateTitleIdAction IN (".$corp_title_condition.")
							GROUP BY Pernr, Nama
						) SE ON PA.PERNR = SE.Pernr
						LEFT JOIN
						(
							SELECT Pernr, Nama, CASE WHEN COUNT(Pernr) >= 1 THEN 1 ELSE 0 END AS ManagementScore2
							FROM AspirasiKarirEndorseME2
							WHERE OrgUnit = '{$orgeh}' AND CorporateTitleId IN (".$corp_title_condition.") AND Hilfm = '{$hilfm}'
							GROUP BY Pernr, Nama
						) ME2 ON PA.PERNR = ME2.Pernr
						WHERE PA.PERNR = '{$c_pernr}';";
				$talent_result = $this->db->query($qstr)->row();
			}

			$data_ins = array(
				'IdBucket' => $param['IdBucket']
				, 'OrgUnit' => $orgeh
				, 'Hilfm' => $hilfm
				, 'CorpTitleId' => $corp_title_id
				, 'Pernr' => isset($talent_result->PERNR)?$talent_result->PERNR:''
				, 'Nama' => isset($talent_result->SNAME)?$talent_result->SNAME:''
				, 'Expertise' => isset($talent_result->Expertise)?$talent_result->Expertise:''
				, 'JobGrade' => isset($talent_result->JobGrade)?$talent_result->JobGrade:''
				, 'TanggalLahir' => isset($talent_result->TANGGALLAHIR)?$talent_result->TANGGALLAHIR:''
				, 'Area' => isset($talent_result->WERKS_TX)?$talent_result->WERKS_TX:''
				, 'SubArea' => isset($talent_result->BTRTL_TX)?$talent_result->BTRTL_TX:''
				, 'CostCenter' => isset($talent_result->KOSTL_TX)?$talent_result->KOSTL_TX:''
				, 'TalentClass' => isset($talent_result->talent_class)?$talent_result->talent_class:''
				, 'TalentClassDesc' => isset($talent_result->talent_class_desc)?$talent_result->talent_class_desc:''
				, 'CorpTitleDesc' => isset($talent_result->corp_title_desc)?$talent_result->corp_title_desc:''
				, 'Htext' => isset($talent_result->htext)?$talent_result->htext:''
				, 'Readiness' => isset($talent_result->readiness)?$talent_result->readiness:''
				, 'Competency' => isset($talent_result->competency)?$talent_result->competency:''
				, 'SkorExpertiseCompability' => isset($talent_result->SkorExpertiseCompability)?$talent_result->SkorExpertiseCompability:''
				, 'SkorJobGradeCompability' => isset($talent_result->SkorJobGradeCompability)?$talent_result->SkorJobGradeCompability:''
				, 'SkorTalentCompability' => isset($talent_result->SkorTalentCompability)?$talent_result->SkorTalentCompability:''
				, 'SkorPotentialCompability' => isset($talent_result->SkorPotentialCompability)?$talent_result->SkorPotentialCompability:''
				, 'SkorEndorseCompability' => isset($talent_result->SkorEndorseCompability)?$talent_result->SkorEndorseCompability:''
				, 'SkorAwardsCompability' => isset($talent_result->SkorAwardsCompability)?$talent_result->SkorAwardsCompability:''
				, 'SkorBLDPCompability' => isset($talent_result->SkorBLDPCompability)?$talent_result->SkorBLDPCompability:''
				, 'SkorSocialCompability' => isset($talent_result->SkorSocialCompability)?$talent_result->SkorSocialCompability:''
				, 'IsChecked' => 1
				, 'Urutan' => isset($talent->maks_urutan)?$talent->maks_urutan+1:1
			);
			
			$data_ins['BobotExpertiseCompability'] =  isset($talent_result->SkorExpertiseCompability)?(0.20*$talent_result->SkorExpertiseCompability):0;
			$data_ins['BobotJobGradeCompability'] =  isset($talent_result->SkorJobGradeCompability)?(0.10*$talent_result->SkorJobGradeCompability):0;
			$data_ins['BobotTalentCompability'] =  isset($talent_result->SkorTalentCompability)?(0.20*$talent_result->SkorTalentCompability):0;
			$data_ins['BobotPotentialCompability'] =  isset($talent_result->SkorPotentialCompability)?(0.15*$talent_result->SkorPotentialCompability):0;
			$data_ins['BobotEndorseCompability'] =  isset($talent_result->SkorEndorseCompability)?(0.25*$talent_result->SkorEndorseCompability):0;
			$data_ins['BobotAwardsCompability'] =  isset($talent_result->SkorAwardsCompability)?(0.05*$talent_result->SkorAwardsCompability):0;
			$data_ins['BobotBLDPCompability'] =  isset($talent_result->SkorBLDPCompability)?(0*$talent_result->SkorBLDPCompability):0;
			$data_ins['BobotSocialCompability'] =  isset($talent_result->SkorSocialCompability)?(0.05*$talent_result->SkorSocialCompability):0;
			$data_ins['OverallCompabilityScore'] = $data_ins['BobotExpertiseCompability']+$data_ins['BobotJobGradeCompability']+
												$data_ins['BobotTalentCompability']+$data_ins['BobotPotentialCompability']+
												$data_ins['BobotEndorseCompability']+$data_ins['BobotAwardsCompability']+
												$data_ins['BobotBLDPCompability']+$data_ins['BobotSocialCompability'];
			
			
			$data_ins['EmployeeAspiration'] = $this->getEmployeeAspiration($orgeh, $hilfm, $corp_title_array, $c_pernr);
			$data_ins['ManagementEndorsement'] = $this->getManagementEndorsement($orgeh, $hilfm, $corp_title_array, $c_pernr);
			$data_ins['SuccessorEndorsement'] = $this->getSuccessorEndorsement($orgeh, $hilfm, $corp_title_array, $c_pernr);
			$data_ins['AwardWinner'] = $this->getAwardWinner($c_pernr);
			$data_ins['CultureAgent'] = $this->getCultureAgent($c_pernr);
			$data_ins['BrilianSocietyMember'] = $this->getBrilianSocietyMember($c_pernr);
			$data_ins['Top5BLDPRank'] = $this->getTop5BLDPRank($c_pernr);
			
			$this->db->insert('TalentCandidatesResults', $data_ins);

			$modify = array(
				'Modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
				, 'ModifiedBy' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
				, 'ModifiedDate' => date('Y-m-d H:i:s')
			);
			$this->db->update('TalentBucket', $modify, array('IdBucket' => $param['IdBucket']));
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
			} else { 
				$this->db->trans_commit();
				$ret['status'] = true;
				$ret['message'] = 'Data berhasil disimpan.';
			}
			
			
			return $ret;
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return $ret;
        }
	}
	
	function getEmployeeAspiration($orgeh, $hilfm, $corp_title_id, $pernr){

		$this->db->select('count(Pernr) as jumlah');
		$this->db->where_in('CorporateTitleId', $corp_title_id);
		$query = $this->db->get_where('AspirasiKarirPekerja', array('OrgUnit' => $orgeh, 'Hilfm' => $hilfm, 'Pernr' => $pernr, 'StatusData' => 1))->row();
		return $query->jumlah > 0 ? 1 : 0;
	}

	function getManagementEndorsement($orgeh, $hilfm, $corp_title_id, $pernr){
		$this->db->select('count(Pernr) as jumlah');
		$this->db->where_in('CorporateTitleId', $corp_title_id);
		$query = $this->db->get_where('AspirasiKarirEndorse', array('OrgUnit' => $orgeh, 'Hilfm' => $hilfm, 'Pernr' => $pernr))->row();
		return $query->jumlah > 0 ? 1 : 0;
	}

	function getManagementEndorsement2($orgeh, $hilfm, $corp_title_id, $pernr){
		$this->db->select('count(Pernr) as jumlah');
		$this->db->where_in('CorporateTitleId', $corp_title_id);
		$query = $this->db->get_where('AspirasiKarirEndorseME2', array('OrgUnit' => $orgeh, 'Hilfm' => $hilfm, 'Pernr' => $pernr))->row();
		return $query->jumlah > 0 ? 1 : 0;
	}

	function getSuccessorEndorsement($orgeh, $hilfm, $corp_title_id, $pernr){
		$this->db->select('count(Pernr) as jumlah');
		$this->db->where_in('CorporateTitleIdAction', $corp_title_id);
		$query = $this->db->get_where('AspirasiSuksesorSaya', array('OrgUnitAction' => $orgeh, 'HilfmAction' => $hilfm, 'Pernr' => $pernr))->row();
		return $query->jumlah > 0 ? 1 : 0;
	}

	function getAwardWinner($pernr){
		$this->db->select('count(PERNR) as jumlah');
		$query = $this->db->get_where('EMPLOYEE_AWARDS_SCORE_INITIAL', array('PERNR' => $pernr))->row();
		return $query->jumlah > 0 ? 1 : 0;
	}

	function getCultureAgent($pernr){
		$this->db->select('count(PERNR) as jumlah');
		$query = $this->db->get_where('CULTURE_AGENT', array('PERNR' => $pernr))->row();
		return $query->jumlah > 0 ? 1 : 0;
	}

	function getBrilianSocietyMember($pernr){
		$this->db->select('count(PERNR) as jumlah');
		$query = $this->db->get_where('BRILIAN_SOCIETY_MEMBER', array('PERNR' => $pernr))->row();
		return $query->jumlah > 0 ? 1 : 0;
	}

	function getTop5BLDPRank($pernr){
		$this->db->select('count(PERNR) as jumlah');
		$query = $this->db->get_where('EMPLOYEE_BLDP_SCORE', array('PERNR' => $pernr))->row();
		return $query->jumlah > 0 ? 1 : 0;
	}

	function is_candidates_exist($param){
		$condition = array('IdBucket' => $param['IdBucket'], 'OrgUnit' => $param['OrgUnit'], 'Hilfm' => $param['Hilfm'], 'Pernr' => $param['candidates']);
		$this->db->select('count(*) as jml');
		$candidates = $this->db->get_where('TalentCandidatesResults', $condition)->row();
		return isset($candidates->jml)?($candidates->jml>0?true:false):true;
	}

	public function approve_data($id_bucket = 0, $komentar = ''){
		try{
			$username = $_SESSION[$this->config->item('session_prefix')]['pernr'];
			$tgl_proses 	= date('Y-m-d H:i:s');

			$clr_catatan 	= $this->db->escape(str_replace('~', ' ', $komentar));
			$this->db->select('IdBucket, Approver, StatusApproval, Status, Posisi');
			$usulan = $this->db->get_where('TalentBucket', array('IdBucket' => $id_bucket))->row();
			//var_dump();die;
			$split_username_approver = explode('~', $usulan->Approver);
			$status_approval = trim($usulan->StatusApproval);
			$status_approval = $status_approval.($status_approval!=''?'|':'').'0';
			
			$clr_status = 1;
			if ($username == $split_username_approver[count($split_username_approver) - 1]) {   //posisi terakhir atasan
				$clr_posisi_usulan = 'SELESAI';
				$clr_status = 2;
			} else {
				$posisi = 0;
				for ($i = 0; $i < count($split_username_approver); $i++) {
					if ($split_username_approver[$i] == $username) {
						$posisi = $i;
						break;
					}
				}

				$clr_posisi_usulan = $split_username_approver[$posisi + 1];
			}
			
			$approve_usulan =  "UPDATE TalentBucket 
									SET 	Status = {$clr_status}
										  , CatatanApprover = 	
											CASE 
												WHEN CatatanApprover <> '' THEN CONCAT(CatatanApprover, '~', {$clr_catatan}) 
												ELSE {$clr_catatan} 
											END
										  , TglProses = 
											CASE 
												WHEN TglProses <> '' THEN CONCAT(TglProses, '~', '{$tgl_proses}') 
												ELSE '{$tgl_proses}' 
											END
										  , Posisi = '{$clr_posisi_usulan}'
										  , StatusApproval = '{$status_approval}'
											WHERE IdBucket = {$id_bucket}";

			$this->db->query($approve_usulan);

			if ($this->db->trans_status() === FALSE) {
				$this->db->trans_rollback();
				return array('error' => true, 'message' => 'Pengajuan Gagal Disetujui. Terjadi Kesalahan Sistem.');
			} else {
				$this->db->trans_commit();
				return array('error' => false, 'message' => 'Pengajuan Berhasil Disetujui.', 'status' => $clr_status);
			}
			
		} catch(Exception $e) {
			return array('error' => true, 'message' => 'Pengajuan Gagal Disetujui. Terjadi Kesalahan Sistem.');
		}
	}
	
	public function reject_data($id_bucket = 0, $komentar = ''){
		try{

			$username = $_SESSION[$this->config->item('session_prefix')]['pernr'];
			$tgl_proses 	= date('Y-m-d H:i:s');

			$clr_catatan 	= $this->db->escape(str_replace('~', ' ', $komentar));
			
			$this->db->select('IdBucket, Approver, StatusApproval, Status, Posisi');
			$usulan = $this->db->get_where('TalentBucket', array('IdBucket' => $id_bucket))->row();
			
			$status_approval = trim($usulan->StatusApproval);
			$status_approval = $status_approval.($status_approval!=''?'|':'').'1';
			
			$approve_usulan =  "UPDATE TalentBucket 
									SET 	Status = 3
										  , CatatanApprover = 	
											CASE 
												WHEN CatatanApprover <> '' THEN CONCAT(CatatanApprover, '~', {$clr_catatan}) 
												ELSE {$clr_catatan} 
											END
										  , TglProses = 
											CASE 
												WHEN TglProses <> '' THEN CONCAT(TglProses, '~', '{$tgl_proses}') 
												ELSE '{$TglProses}' 
											END
										  , StatusApproval = '{$status_approval}'
											WHERE IdBucket = {$id_bucket}";

			$this->db->query($approve_usulan);

			if ($this->db->trans_status() === FALSE) {
				$this->db->trans_rollback();
				return array('error' => true, 'message' => 'Pengajuan Gagal Ditolak. Terjadi Kesalahan Sistem.');
			} else {
				$this->db->trans_commit();
				return array('error' => false, 'message' => 'Pengajuan Berhasil Ditolak.');
			}
		} catch(Exception $e) {
			return array('error' => true, 'message' => 'Pengajuan Gagal Ditolak. Terjadi Kesalahan Sistem.');
		}
	}

	function get_successors_aspiration($count=false,$param='',$filter='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		if($filter['jenis_aspirasi']==1){
			$table = "AspirasiKarirPekerja a 
						INNER JOIN AspirasiOverallCompability b ON a.Pernr = b.Pernr AND a.OrgUnit = b.OrgUnit AND a.Hilfm = b.Hilfm AND a.Level = b.Level AND a.Urutan = b.Urutan
						INNER JOIN talent_hav_matrix_aspirasi c ON a.Pernr = c.pernr AND c.method = 1 AND c.method = 1 AND c.type = 0 AND c.jenis_asesmen = 1";
		}
		elseif($filter['jenis_aspirasi']==2){
			/*$table = "AspirasiKarirEndorse a
						INNER JOIN talent_hav_matrix_aspirasi c ON a.Pernr = c.pernr AND c.method = 1 AND c.method = 1 AND c.type = 0 AND c.jenis_asesmen = 1";*/
			$qstr 	= "SELECT a.*,
						c.nama AS Nama, c.tanggallahir As TanggalLahir, c.htext as Htext, c.costcenter AS CostCenter, 
						c.corp_title_desc AS CorpTitleDesc, c.jobgrade AS JobGrade, c.expertise AS Expertise, 
						c.readiness AS Readiness, c.talent_class AS TalentClass, c.talent_class_desc AS TalentClassDesc 
						FROM (
							SELECT ASP.Pernr, MAX(ASP.OverallCompabilityScore) AS OverallCompabilityScore
							FROM (
								SELECT a.Pernr, a.OcsScore AS OverallCompabilityScore
								FROM AspirasiKarirEndorse a 
								WHERE  a.OrgUnit = ? AND a.Hilfm = ? AND a.CorporateTitleId IN (?,?)
								UNION
								SELECT a.Pernr, a.OcsScore AS OverallCompabilityScore
								FROM AspirasiKarirEndorseME2 a 
								WHERE  a.OrgUnit = ? AND a.Hilfm = ? AND a.CorporateTitleId IN (?,?)
							) ASP
							GROUP BY ASP.Pernr
						) a
						INNER JOIN talent_hav_matrix_aspirasi c ON a.Pernr = c.pernr AND c.method = 1 AND c.method = 1 AND c.type = 0 AND c.jenis_asesmen = 1";
			$table = "( " . $qstr . ") c_";
			$params_arr = array();
			if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
				$params_arr = array($filter['orgeh'], $filter['hilfm'], 'SM', 'AVP', $filter['orgeh'], $filter['hilfm'], 'SM', 'AVP');
			}
			elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id'] == 'DIR'){
				$params_arr = array($filter['orgeh'], $filter['hilfm'], 'SEVP', 'DIR', $filter['orgeh'], $filter['hilfm'], 'SEVP', 'DIR');
			}
			else{
				$params_arr = array($filter['orgeh'], $filter['hilfm'], $filter['corp_title_id'], $filter['corp_title_id'], $filter['orgeh'], $filter['hilfm'], $filter['corp_title_id'], $filter['corp_title_id']);
			}
		}
		elseif($filter['jenis_aspirasi']==3){
			$table = "AspirasiSuksesorSaya a
						INNER JOIN talent_hav_matrix_aspirasi c ON a.Pernr = c.pernr AND c.method = 1 AND c.method = 1 AND c.type = 0 AND c.jenis_asesmen = 1";	
		}
		elseif($filter['jenis_aspirasi']==4){
			$qstr 	= "SELECT a.*,
						c.nama AS Nama, c.tanggallahir As TanggalLahir, c.htext as Htext, c.costcenter AS CostCenter, 
						c.corp_title_desc AS CorpTitleDesc, c.jobgrade AS JobGrade, c.expertise AS Expertise, 
						c.readiness AS Readiness, c.talent_class AS TalentClass, c.talent_class_desc AS TalentClassDesc 
						FROM (
							SELECT ASP.Pernr, MAX(ASP.OverallCompabilityScore) AS OverallCompabilityScore
							FROM (
								SELECT a.Pernr, b.OverallCompabilityScore
								FROM AspirasiKarirPekerja a 
								INNER JOIN AspirasiOverallCompability b ON a.Pernr = b.Pernr AND a.OrgUnit = b.OrgUnit AND a.Hilfm = b.Hilfm AND a.Level = b.Level AND a.Urutan = b.Urutan 
								WHERE a.OrgUnit = ? AND a.Hilfm = ? AND a.CorporateTitleId IN (?,?) AND a.StatusData = 1
								UNION
								SELECT a.Pernr, a.OcsScore AS OverallCompabilityScore
								FROM AspirasiKarirEndorse a 
								WHERE  a.OrgUnit = ? AND a.Hilfm = ? AND a.CorporateTitleId IN (?,?)
								UNION
								SELECT a.Pernr, a.OcsScore AS OverallCompabilityScore
								FROM AspirasiKarirEndorseME2 a 
								WHERE  a.OrgUnit = ? AND a.Hilfm = ? AND a.CorporateTitleId IN (?,?)
								UNION
								SELECT a.Pernr, a.OcsScore AS OverallCompabilityScore
								FROM AspirasiSuksesorSaya a 
								WHERE a.OrgUnitAction = ? AND a.HilfmAction = ? AND a.CorporateTitleIdAction IN (?,?)
							) ASP
							GROUP BY ASP.Pernr
						) a
						INNER JOIN talent_hav_matrix_aspirasi c ON a.Pernr = c.pernr AND c.method = 1 AND c.method = 1 AND c.type = 0 AND c.jenis_asesmen = 1";
			$table = "( " . $qstr . ") c_";
			$params_arr = array();
			if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
				$params_arr = array($filter['orgeh'], $filter['hilfm'], 'SM', 'AVP', $filter['orgeh'], $filter['hilfm'], 'SM', 'AVP', $filter['orgeh'], $filter['hilfm'], 'SM', 'AVP', $filter['orgeh'], $filter['hilfm'], 'SM', 'AVP');
			}
			elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id'] == 'DIR'){
				$params_arr = array($filter['orgeh'], $filter['hilfm'], 'SEVP', 'DIR', $filter['orgeh'], $filter['hilfm'], 'SEVP', 'DIR', $filter['orgeh'], $filter['hilfm'], 'SEVP', 'DIR', $filter['orgeh'], $filter['hilfm'], 'SEVP', 'DIR');
			}
			else{
				$params_arr = array($filter['orgeh'], $filter['hilfm'], $filter['corp_title_id'], $filter['corp_title_id'], $filter['orgeh'], $filter['hilfm'], $filter['corp_title_id'], $filter['corp_title_id'], $filter['orgeh'], $filter['hilfm'], $filter['corp_title_id'], $filter['corp_title_id'], $filter['orgeh'], $filter['hilfm'], $filter['corp_title_id'], $filter['corp_title_id']);
			}
		}

		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			if($filter['jenis_aspirasi']!=4 && $filter['jenis_aspirasi']!=2){
				$qstr	= $qstr.$where;
				$query 	= $this->db->query($qstr);
			}
			else{
				$qstr	= $qstr.$where;
				$query = $this->db->query($qstr, $params_arr);
			}
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';


			if($filter['jenis_aspirasi']==1){
				$qstr	= "SELECT a.Pernr, a.Nama, b.BobotExpertiseCompability, b.BobotJobGradeCompability, 
				b.BobotTalentCompability, b.BobotPotentialCompability, b.BobotEndorseCompability, 
				b.BobotAwardsCompability, b.BobotSocialCompability, b.OverallCompabilityScore, 
				c.tanggallahir As TanggalLahir, c.htext as Htext, c.costcenter AS CostCenter, c.corp_title_desc AS CorpTitleDesc,
				c.jobgrade AS JobGrade, c.expertise AS Expertise, c.readiness AS Readiness, c.talent_class AS TalentClass,
				c.talent_class_desc AS TalentClassDesc FROM {$table}";
				$qstr	= $qstr.$where.$order.$clause_limit;
				$query 	= $this->db->query($qstr);
			}
			elseif($filter['jenis_aspirasi']==2){
				/*$qstr	= "SELECT a.Pernr, a.Nama, a.OcsScore AS OverallCompabilityScore,
				c.tanggallahir As TanggalLahir, c.htext as Htext, c.costcenter AS CostCenter, c.corp_title_desc AS CorpTitleDesc,
				c.jobgrade AS JobGrade, c.expertise AS Expertise, c.readiness AS Readiness, c.talent_class AS TalentClass,
				c.talent_class_desc AS TalentClassDesc FROM {$table}";*/
				$order = "ORDER BY a.OverallCompabilityScore DESC";
				$qstr	= $qstr.$where.$order.$clause_limit;
				$query = $this->db->query($qstr, $params_arr);
			}
			elseif($filter['jenis_aspirasi']==3){
				$qstr	= "SELECT a.Pernr, a.Nama, a.OcsScore AS OverallCompabilityScore,
				c.tanggallahir As TanggalLahir, c.htext as Htext, c.costcenter AS CostCenter, c.corp_title_desc AS CorpTitleDesc,
				c.jobgrade AS JobGrade, c.expertise AS Expertise, c.readiness AS Readiness, c.talent_class AS TalentClass,
				c.talent_class_desc AS TalentClassDesc FROM {$table}";
				$qstr	= $qstr.$where.$order.$clause_limit;
				$query 	= $this->db->query($qstr);
			}
			elseif($filter['jenis_aspirasi']==4){
				$order = "ORDER BY a.OverallCompabilityScore DESC";
				$qstr	= $qstr.$where.$order.$clause_limit;
				$query = $this->db->query($qstr, $params_arr);
				
			}

			//echo $this->db->last_query();
			
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	function get_job_family($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE  ".$where : "  ";
		$table = "JOB_FAMILY sjf LEFT JOIN JOB_FAMILY jf ON sjf.PARENT = jf.INITIALS";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT jf.INITIALS AS JF, jf.DESKRIPSI AS JF_DESKRIPSI, sjf.INITIALS AS SJF, sjf.DESKRIPSI AS SJF_DESKRIPSI FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	function get_master_corp_title($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE  ".$where : "  ";
		$table = "MasterCorpTitle a";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT * FROM {$table} where a.corp_title_id IN('A', 'O', 'AM', 'M')";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	public function countCTSjf($sjf){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		if($tipe_uker == 'KP'){
			$query = "select b.kode_corp_title, count(a.pernr) as jml
						from pa0001_eof a
						inner join mapping_corp_title b on substr(a.jgpg,1,4) = b.jg and a.hilfm = b.hilfm
						inner join EMPLOYEE_TALENT_POOL c on a.pernr = c.pernr
						where a.persk in (?,?,?,?,?,?,?,?,?,?) and c.initials = ?
						group by b.kode_corp_title;";
		} else {
			$query = "select b.kode_corp_title, count(a.pernr) as jml
						from pa0001_eof a
						inner join mapping_corp_title b on substr(a.jgpg,1,4) = b.jg and a.hilfm = b.hilfm
						inner join EMPLOYEE_TALENT_POOL c on a.pernr = c.pernr
						where a.persk in (?,?,?,?,?,?,?,?,?,?) and c.initials = ?
						and a.WERKS = '{$pa}'
						group by b.kode_corp_title;";
		}
		$query = $this->db->query($query, array('10','12','13','14','15','26','41','42','97','98', $sjf));
		return $query->result();
	}

	public function countCTGrade($sjf, $ct){
		$query = "select b.kode_corp_title, b.jg, count(a.pernr) as jml
					from pa0001_eof a
					inner join mapping_corp_title b on substr(a.jgpg,1,4) = b.jg and a.hilfm = b.hilfm
					inner join EMPLOYEE_TALENT_POOL c on a.pernr = c.pernr
					where a.persk in (?,?,?,?,?,?,?,?,?,?) and b.kode_corp_title = ? and c.initials = ?
					group by b.kode_corp_title, b.jg;";
		//echo $query;
		$query = $this->db->query($query, array('10','12','13','14','15','26','41','42','97','98', $ct, $sjf));
		return $query->result();
	}

	function get_talent_pool_ct_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "pa0001_eof a
				inner join mapping_corp_title b on substr(a.jgpg,1,4) = b.jg and a.hilfm = b.hilfm
				inner join EMPLOYEE_TALENT_POOL c on a.pernr = c.pernr";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT c.INITIALS, c.JOBFAMILY, c.MK_BULAN, b.kode_corp_title, b.corp_title, b.jg, a.PERNR, a.SNAME, a.KOSTL_TX, a.WERKS_TX, a.BTRTL_TX, a.ORGEH_TX, a.HTEXT, a.STELL_TX FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query;
		}
	}

	public function listEmployeeBucket($orgeh='', $hilfm='', $corp_title_id = '', $pernr = ''){
		$query_plans = "select distinct a.IdBucket, a.BucketName 
				from TalentBucket a 
				inner join TalentCandidatesResults b on a.IdBucket = b.IdBucket
				where a.OrgUnit = ? 
				and a.Hilfm = ?
				and a.CorpTitleId= ?
				and a.Status not in (?) 
				and b.Pernr = ? order by ModifiedDate desc";
		//echo $query_plans;
		$query = $this->db->query($query_plans, array($orgeh, $hilfm, $corp_title_id, 4, $pernr));
		$data = $query->result();
		return $data;
	}

	function action_choose($param=array(), $candidate=array()){
		try{
			$this->db->trans_begin();
			
			$data_ = array(
				'Choosen' => isset($candidate->PERNR)?$candidate->PERNR:''
				, 'ChoosenName' => isset($candidate->SNAME)?$candidate->SNAME:''
				, 'ChoosenDate' => date('Y-m-d H:i:s')
			);
			$condition = array(
				'ComiteId' => $param['id_comite']
				, 'BucketId' => $param['id_bucket']
			);
			$this->db->update('TalentComiteBucket', $data_, $condition);
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				return array('status'=>false,'message'=>'Data gagal disimpan.');
			} else { 
				$this->db->trans_commit();
				return array('status'=>true,'message'=>'Data berhasil disimpan.');
			}
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return array('status'=>false,'message'=>'Data gagal disimpan. Terjadi kesalahan sistem.');
        }
	}
	
}