<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Option_model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	

    /*public function opt_mk_jabatan_uker()
    {
        return array(
                        '-1|18'=>'0 s/d 1,5 th'
                        ,'18|24'=>'>1,5 s/d 2 th'
                        ,'24|36'=>'>2 s/d 3 th'
                        ,'36|9999'=>'> 3 th'
                        ,'NULL'=>'- Lainnya -'
                    );
    }*/

    public function opt_mk_jabatan_uker()
    {
        return array(
                        '-1|12'=>'0 s/d 1 th'
                        ,'12|24'=>'>1 s/d 2 th'
                        ,'24|36'=>'>2 s/d 3 th'
                        ,'36|9999'=>'> 3 th'
                        ,'NULL'=>'- Lainnya -'
                    );
    }
    
    public function opt_mk_jg_pg()
    {
        return array(
                        '-1|6'=>'Memenuhi Persyaratan s/d 6 bln'
                        ,'6|12'=>'>6 s/d 12 bln dari Persyaratan'
                        ,'12|9999'=>'>12 bln dari Persyaratan'
                        ,'NULL'=>'- Lainnya -'
                    );
    }

    public function opt_jabatan()
    {
        $string     = "SELECT DISTINCT OBJECTSUBCLASS,TEXT FROM OBJECT_SUBCLASSES WHERE OBJECTCLASS = '9071' ORDER BY TEXT ASC";
        $query      = $this->db->query($string);
        $jabatan    = array();
        foreach ($query->result() as $row) {
            $jabatan[$row->OBJECTSUBCLASS] = $row->TEXT;
        }

        return $jabatan;
    } 



    public function opt_program_masuk()
    {
        $string     = "SELECT DISTINCT PROGRAM_MASUK FROM sdm_monitoring_pekerja WHERE PROGRAM_MASUK <> ''";
        $query      = $this->db->query($string);
        $program    = array();
        foreach ($query->result() as $row) {
            $program[$row->PROGRAM_MASUK] = $row->PROGRAM_MASUK;
        }

        return $program;
    }


    public function opt_job_grade()
    {
        return array(   '' => '- Pilih JG -',
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '6' => '6',
                        '7' => '7',
                        '8' => '8',
                        '9' => '9',
                        '10' => '10',
                        '11' => '11',
                        '12' => '12',
                        '13' => '13',
                        '14' => '14',
                        '15' => '15',
                        '16' => '16',
                        '17' => '17',
                        '18' => '18',
                    );
    }


    public function opt_person_grade()
    {
        return array(   '' => '- Pilih PG -',
                        '1' => '1',
                        '2' => '2',
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '6' => '6',
                        '7' => '7',
                        '8' => '8',
                        '9' => '9',
                        '10' => '10',
                        '11' => '11',
                        '12' => '12',
                        '13' => '13',
                        '14' => '14',
                        '15' => '15',
                        '16' => '16',
                        '17' => '17',
                        '18' => '18',
                        '19' => '19',
                        '20' => '20',
                        '21' => '21',
                        '22' => '22',
                        '23' => '23',
                        '24' => '24',
                    );
    }


    public function opt_agama()
    {
        return array(   
                        ''              => '- Pilih Agama -',
                        'ISLAM'         => 'Islam',
                        'HINDU'         => 'Hindu',
                        'BUDHA'         => 'Budha',
                        'KATOLIK'       => 'Katolik',
                        'PROTESTAN'     => 'Protestan',
                        'KHONGHUCU'     => 'Khonghucu',
                        'KEPERCAYAAN'   => 'Kepercayaan'
                    );
    }
	
	public function opt_rekomendasi_asesmen()
    {
        return array(   
                        'Sangat Direkomendasikan'  => 'Sangat Direkomendasikan',
                        'Direkomendasikan'         => 'Direkomendasikan',
                        'Memerlukan Pengembangan'  => 'Memerlukan Pengembangan',
                        'Belum Direkomendasikan'   => 'Belum Direkomendasikan',
                    );
    }
	
	public function opt_jenis_klaim(){
		$query_plans = "select * from mst_klaim_kesehatan order by teks";
        $query = $this->db->query($query_plans);
        foreach ($query->result() as $row) {
            $data[$row->kode] = $row->teks . ' [ ' . $row->kode . ' ]';
        }
		return $data;
	}
	
	function opt_get_insus() {
    	return array(   
                        '01'  => '01 - Sedang Proses',
                        '02'  => '02 - Tidak Bersalah',
                        '03'  => '03 - Bersalah',
                        '04'  => '04 - Kadaluarsa'
                    );
    }
	
	public function opt_corp_title_nonkp(){
		$query_plans = "select * from mst_corp_title where status = 1 and corp_title_id between 6 and 9 order by corp_title_id";
        $query = $this->db->query($query_plans);
		//$data[''] = '- Choose Corporate Title -';
        foreach ($query->result() as $row) {
            $data[$row->corp_title_id] =  $row->corp_title_desc;
        }
		return $data;
	}
    
    public function opt_corp_title(){
		$query_plans = "select * from mst_corp_title where status = 1 order by corp_title_id";
        $query = $this->db->query($query_plans);
		//$data[''] = '- Choose Corporate Title -';
        foreach ($query->result() as $row) {
            $data[$row->corp_title_id] =  $row->corp_title_desc;
        }
		return $data;
	}
	
    
    public function opt_hilfm(){
		$query_plans = "select * from mst_hilfm where status = 1 order by hilfm";
        $query = $this->db->query($query_plans);
		//$data[''] = '- Choose Jobs -';
        foreach ($query->result() as $row) {
            $data[$row->hilfm] =  $row->htext;
        }
		return $data;
	}
	
	public function opt_rekomendasi(){
		$query_plans = "select * from mst_rekomendasi";
        $query = $this->db->query($query_plans);
		//$data[''] = '- Choose Jobs -';
        foreach ($query->result() as $row) {
            $data[$row->id_rekomendasi] =  $row->klasifikasi;
        }
		return $data;
    }
    
    public function opt_direktorat(){
        //$query_plans = "select * from mst_organization where organization_area = 'KP' and organization_class = 'direktorat-level';";
        $query_plans = "select objid as organization, myname as organization_desc from mst_direktorat where flag = 1;";
        $query = $this->db->query($query_plans);
		//$data[''] = '- Choose Jobs -';
        foreach ($query->result() as $row) {
            $data[$row->organization] =  $row->organization_desc;
        }
		return $data;
    }
	
	function opt_category() {
    	return array(   
                        '1'  => 'Domestic Standart',
                       // '2'  => 'Global Standart'
                    );
    }
	
	function opt_talent_class() {
    	return array(   
						''  => '- Choose Talent Class -',
                        '1'  => 'Five Talent Class',
                        '2'  => 'Nine Talent Class'
                    );
    }

    function opt_talent_class_v() {
    	return array(   
						''  => '- Choose Talent Class -',
                       // '1'  => 'Five Talent Class',
                        '2'  => 'Nine Talent Class'
                    );
    }
	
	function opt_organization_area() {
    	return array(   
						''  => '- Choose Organization Area -',
                        'KP'  => 'Kantor Pusat',
                        'KW'  => 'Kantor Wilayah',
                        'AIW'  => 'Audit Intern Wilayah',
                        'AP'  => 'BRI Group'
                    );
    }
	function opt_severity_level() {
    	return array(   
						''  => '- Choose Severity level -',
                        '1'  => 'Green',
                        '2'  => 'Red'
                    );
    }
	function opt_status() {
    	return array(   
                        '0'  => 'Non Aktif',
                        '1'  => 'Aktif'
                    );
    }
	function opt_flightrisk() {
    	return array(   
                        'Low'  => 'Low',
                        'Moderate'  => 'Moderate',
                        'High'  => 'High'
                    );
    }
	function opt_jobgrade() {
    	return array(   
                        '22'  => '22',
                        '21'  => '21',
                        '20'  => '20',
                        '19'  => '19',
                        '18'  => '18',
                        '17'  => '17',
                        '16'  => '16',
                        '15'  => '15',
                        '14'  => '14',
                        '13'  => '13',
                        '12'  => '12',
                        '11'  => '11',
                        '10'  => '10'
                    );
    }
	function opt_type() {
    	return array(   
                        '1'  => 'Bisnis',
                        '2'  => 'Non Bisnis'
                    );
    }

    function opt_jenis_asesmen(){
        return array(   
            ''  => '- Choose Assessment -',
            '1'  => 'Competency',
           // '2'  => 'Leadership Potential'
        );
    }

    function opt_hav()
    {
        $string     = "SELECT * FROM mst_hav_matrix";
        $query      = $this->db->query($string);
        $hav    = array();
        foreach ($query->result() as $row) {
            $hav[$row->id_hav] = '['.$row->id_hav.'] '.$row->deskripsi;
        }

        return $hav;
    }

    function opt_readiness()
    {
        $string     = "SELECT * FROM mst_rekomendasi";
        $query      = $this->db->query($string);
        $readiness    = array();
        foreach ($query->result() as $row) {
            $readiness[$row->id_rekomendasi] = $row->readiness;
        }

        return $readiness;
    }

    function get_hasil_asm($pernr=''){
        $str = "select a.*, b.readiness from mst_hasil_assessment a inner join mst_rekomendasi b on a.rekomendasi = b.id_rekomendasi
                where a.pernr = '{$pernr}' and a.method = 1 and a.type = 0 and a.jenis_asesmen = 1";
        $query = $this->db->query($str);
        return isset($query->row()->pernr)?$query->row():array();
    }

    function get_hasil_asm_das($pernr=''){
        $str = "select a.*, b.readiness from mst_hasil_assessment_das a inner join mst_rekomendasi b on a.rekomendasi = b.id_rekomendasi
                where a.pernr = '{$pernr}' and a.method = 1 and a.type = 0 and a.jenis_asesmen = 1";
        $query = $this->db->query($str);
        return isset($query->row()->pernr)?$query->row():array();
    }
}