<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Laporan_model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	function get_aspirasi_karir($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiKarirPekerja a INNER JOIN AspirasiOverallCompability b ON a.Pernr = b.Pernr AND a.Level = b.Level AND a.Urutan = b.Urutan JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalArea = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, b.OverallCompabilityScore, b.Rank FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_aspirasi_karir_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		//$table = "AspirasiKarirPekerja a INNER JOIN AspirasiOverallCompability b ON a.Pernr = b.Pernr AND a.Level = b.Level AND a.Urutan = b.Urutan
		//			INNER JOIN AspirasiKarirPekerjaJF c on a.IDAspirasi = c.IDAspirasi";
		$table = "AspirasiKarirPekerja a INNER JOIN AspirasiOverallCompability b ON a.Pernr = b.Pernr AND a.Level = b.Level AND a.Urutan = b.Urutan JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalArea = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			//$qstr	= "SELECT a.*, b.OverallCompabilityScore, REPLACE(REPLACE(REPLACE(c.Reason,',','.'), '\r', ''), '\n', '') AS Reason FROM {$table}";
			$qstr	= "SELECT a.*, b.OverallCompabilityScore FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function get_suksesor_saya($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiSuksesorSaya a JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalAreaAction = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_suksesor_saya_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiSuksesorSaya a JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalAreaAction = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function get_endorse_subordinate($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiKarirEndorse a JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalArea = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_endorse_subordinate_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiKarirEndorse a JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalArea = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			//$qstr	= "SELECT Pernr,Nama,JenisUker,CostCenter,CostCenterDesc,PersonnalArea,PersonnalAreaDesc,PersonnalSubArea,PersonnalSubAreaDesc,OrgUnit,OrgUnitDesc,JobGrade,CorporateTitleId,CorporateTitleDesc,Hilfm,Htext,JobGradeCurr,CorporateTitleIdCurr,CorporateTitleDescCurr,HilfmCurr,HtextCurr,StellCurr,CostCenterCurr,CostCenterDescCurr,PersonnalAreaCurr,PersonnalAreaDescCurr,PersonnalSubAreaCurr,PersonnalSubAreaDescCurr,OrgUnitCurr,OrgUnitDescCurr,PernrEndorse,NamaEndorse,OrgehEndorse,JobGradeEndorse,CorporateTitleIdEndorse,CorporateTitleDescEndorse,HilfmEndorse,HtextEndorse,StellEndorse,CostCenterEndorse,CostCenterDescEndorse,PersonnalAreaEndorse,PersonnalAreaDescEndorse,PersonnalSubAreaEndorse,PersonnalSubAreaDescEndorse,OrgUnitEndorse,OrgUnitDescEndorse,OcsScore,InsertDate,REPLACE(REPLACE(REPLACE(Reason,',','.'), '\r', ''), '\n', '') AS Reason FROM {$table}";
			$qstr	= "SELECT a.*, REPLACE(REPLACE(REPLACE(a.Reason,',','.'), '\r', ''), '\n', '') AS Reason FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function arrPiluker()
	{
		return array('KP'=>'Kantor Pusat'
					, 'KW'=>'Kantor Wilayah'
					, 'AIW'=>'Audit Intern Wilayah'
					, 'KC'=>'Kantor Cabang'
					, 'RC'=>'Regional Campus'
					, 'SLP'=>'Sentra Layanan Prioritas'
					, 'KCP'=>'Kantor Cabang Pembantu'
					, 'KK'=>'Kantor Kas'
					, 'UNT'=>'BRI Unit'
					, 'AP'=>'Perusahaan Anak'
				);
	}

	function get_aspirasi_kompetensi($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiJobFamily a LEFT JOIN pa0001_eof b ON a.Pernr = b.PERNR";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, b.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_aspirasi_kompetensi_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiJobFamily a LEFT JOIN pa0001_eof b ON a.Pernr = b.PERNR";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, b.SNAME, b.KOSTL_TX, b.WERKS_TX, b.BTRTL_TX, b.ORGEH_TX, b.BRANCH, b.STELL_TX, b.HTEXT FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function get_endorse_me2($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiKarirEndorseME2 a JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalArea = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_endorse_me2_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiKarirEndorseME2 a JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalArea = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT Pernr,Nama,CostCenter,CostCenterDesc,PersonnalArea,PersonnalAreaDesc,PersonnalSubArea,PersonnalSubAreaDesc,OrgUnit,OrgUnitDesc,JobGrade,CorporateTitleId,CorporateTitleDesc,Hilfm,Htext,JobGradeCurr,CorporateTitleIdCurr,CorporateTitleDescCurr,HilfmCurr,HtextCurr,StellCurr,CostCenterCurr,CostCenterDescCurr,PersonnalAreaCurr,PersonnalAreaDescCurr,PersonnalSubAreaCurr,PersonnalSubAreaDescCurr,OrgUnitCurr,OrgUnitDescCurr,PernrEndorse,NamaEndorse,OrgehEndorse,JobGradeEndorse,CorporateTitleIdEndorse,CorporateTitleDescEndorse,HilfmEndorse,HtextEndorse,StellEndorse,CostCenterEndorse,CostCenterDescEndorse,PersonnalAreaEndorse,PersonnalAreaDescEndorse,PersonnalSubAreaEndorse,PersonnalSubAreaDescEndorse,OrgUnitEndorse,OrgUnitDescEndorse,OcsScore,InsertDate,REPLACE(REPLACE(REPLACE(Reason,',','.'), '\r', ''), '\n', '') AS Reason FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function get_bdp($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiBDP a JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalArea = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_bdp_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "AspirasiBDP a JOIN pa0001_eof c ON a.Pernr = c.Pernr AND a.PersonnalArea = c.WERKS";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.IDBDP, a.IDAspirasi, a.Pernr, a.Nama, a.Coach, a.CoachDesc, a.Mentor, a.MentorDesc, a.SDPDesc, a.FlagSDP, a.HDPDesc,
			a.CostCenter, a.CostCenterDesc, a.PersonnalArea, a.PersonnalAreaDesc, a.PersonnalSubArea, a.PersonnalSubAreaDesc, a.OrgUnit, a.OrgUnitDesc,
			a.JobGrade, a.CorporateTitleDesc, a.Htext, a.Level, a.Urutan, a.AspirasiUnitKerja, a.AspirasiJabatan, a.HistorySMK, a.RekomendasiAsm,  
			REPLACE(REPLACE(REPLACE(a.Strength,',','.'), '\r', ''), '\n', '') AS Strength, REPLACE(REPLACE(REPLACE(a.AreaDevelopment,',','.'), '\r', ''), '\n', '') AS AreaDevelopment,
			a.InsertDate
			FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function arrPilAwards()
	{
		return array('NARASUMBER'=>'Narasumber'
					, 'PENGHARGAAN'=>'Penghargaan'
					, 'PUBLIKASI'=>'Publikasi'
					, 'ORGANISASI'=>'Riwayat Organisasi'
				);
	}

	function get_narasumber($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "NARASUMBER a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, c.SNAME as Nama, c.WERKS_TX as pa, c.BTRTL_TX as psa FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_narasumber_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "NARASUMBER a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		//$table = "NARASUMBER a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function get_achievement($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "ACHIEVEMENT a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, c.SNAME as Nama, c.WERKS_TX as pa, c.BTRTL_TX as psa FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_achievement_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "ACHIEVEMENT a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		//$table = "NARASUMBER a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function get_karya_tulis($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "KARYA_TULIS a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, c.SNAME as Nama, c.WERKS_TX as pa, c.BTRTL_TX as psa FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_karya_tulis_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "KARYA_TULIS a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		//$table = "NARASUMBER a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}

	function get_organisasi($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "RIWAYAT_ORGANISASI a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, c.SNAME as Nama, c.WERKS_TX as pa, c.BTRTL_TX as psa FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query->result();
		}
	}

	function get_organisasi_csv($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		$portal = $this->load->database('aspirasi', true);
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $portal->escape($item);
								}else{
									$arr_temp[$idx] = $portal->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $portal->escape($value['value']);
							}else{
								$field_value = $portal->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "RIWAYAT_ORGANISASI a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		//$table = "NARASUMBER a JOIN pa0001_eof c ON a.Pernr = c.Pernr";
		
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.* FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $portal->query($qstr);
			if(!$query){
				throw new Exception();
			}
			$portal->close();
			return $query;
		}
	}
}