<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Talent_model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	function get_mapping_hav_matrix($param='',$talent_class = '', $order='', $start='', $limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where); 
		$where = ($where!='')?" WHERE talent_class IN ({$talent_class}) AND ".$where : " WHERE talent_class IN ({$talent_class}) ";
		
		$table = "talent_hav_matrix_aspirasi a JOIN pa0001_eof b ON a.Pernr = b.Pernr";
		
		$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
		$qstr	= $qstr.$where;
		//echo $qstr . '<br>';
		$query 	= $this->db->query($qstr);
		if(!$query){
			throw new Exception();
		}
		if($query->num_rows()>0){
			return $query->row()->jumlah_row;
		}else{
			return 0;
		}
		
	}
	
	function get_detail_nine_talent_class($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "talent_hav_matrix_aspirasi a 
				left join mst_direktorat_detail b on a.direktorat = b.objid_org
				left join mst_direktorat c on b.objid_dir = c.objid 
				JOIN pa0001_eof d ON a.Pernr = d.Pernr";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, c.MYNAME as organization_desc FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}
	
	function get_detail_five_talent_class($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "talent_hav_matrix_aspirasi a 
				left join mst_direktorat_detail b on a.direktorat = b.objid_org
				left join mst_direktorat c on b.objid_dir = c.objid 
				JOIN pa0001_eof d ON a.Pernr = d.Pernr";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, c.MYNAME as organization_desc FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}
	
	function data_personal($pernr)
	{
		$pernr = $this->db->escape($pernr);
		$qstr = "select pernr, werks, btrtl, kostl, orgeh, stell, sname, werks_tx, btrtl_tx, kostl_tx, orgeh_tx, stell_tx, HTEXT, jgpg, sisa_ct, sisa_cb, upok, premium, rekening, eselon, nip, tct, jk, tempatlahir, tanggallahir, agama, tmt_pt, mke, mpp, tmt_masuk, tipe_uker, add_area, period_diff(date_format(now(), '%Y%m'), date_format(tmt_masuk, '%Y%m')) as bulan_masa_kerja, npwp, ktp, hp1, hp2, jamsostek, goldarah, alamat, kawin from pa0001_eof where pernr = ". $pernr ." limit 1";
		//echo $qstr;
		$pekerja = $this->db->query($qstr);
		if($pekerja->num_rows()>0){
			return $pekerja->row();
		}else{
			return '';
		}
	}
	
	function get_organization($parent = '', $s_level = ''){
		$qstr = "SELECT * FROM mst_organization where `organization_parent` = '{$parent}' and severity_level in ($s_level) and status = 1";
		$query = $this->db->query($qstr);
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return array();
		}
	}
	
	function get_organization_setting($parent = '', $s_level = ''){
		$qstr = "SELECT * FROM mst_organization where `organization_parent` = '{$parent}' and severity_level in ($s_level)";
		$query = $this->db->query($qstr);
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return array();
		}
	}
	
	function get_keyjobs($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "mst_keyjobs a left join talent_hav_matrix b on a.jobholder = b.pernr and b.method = 1 and b.type = 0 and b.jenis_asesmen = 1";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, b.nama, b.expertise, b.talent_class, b.talent_class_desc FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}
	
	function get_jobs_key($key = '', $keyjobs = ''){
		$table = 'mst_jobfamilies';
		$select_col = 'b.jf';
		if($key == 'jt'){
			$table = 'mst_jobtechnicalities';
			$select_col = 'b.jt';
		}
		$qstr = "select a.keyjobs, GROUP_CONCAT($select_col SEPARATOR ',') AS `keys`
				from mst_keyjobs a
				inner join $table b on a.keyjobs = b.keyjobs
				where a.keyjobs = '{$keyjobs}'
				group by a.keyjobs";
		//echo $qstr;
		$query = $this->db->query($qstr);
		if($query->num_rows()>0){
			return $query->row();
		}else{
			return array();
		}
	}
	
	function get_successors($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "talent_succession_plan_results";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT *, rank as set_rank FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}
	
	function get_history_smk($pernr = ''){
		$query = $this->db->get_where('mst_smk_konsolidasi', array('pernr' => $pernr));
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return array();
		}
	}
	function get_masa_kerja($pernr = '', $kategori = '')
	{
		//$mutasi = $this->load->database('mutasi', true);
		$riwayat = $this->db->get_where("masa_kerja",array('pernr'=>$pernr, 'kategori' => $kategori));
		$result = $riwayat->row();
		//$mutasi->close();
		return $result;
	}
	
	function get_new_org($organization_area = ''){
		$str = "select concat('$organization_area', lpad(max(CONVERT(SUBSTRING_INDEX(organization,'$organization_area',-1),UNSIGNED INTEGER))+1, 5, '0')) AS new_org
				from mst_organization
				where organization_area = '{$organization_area}'";
		$query = $this->db->query($str);
		$new_org = isset($query->row()->new_org)?$query->row()->new_org:'-';
		return $new_org;
	}
	
	function get_new_keyjobs(){
		$str = "select concat('KYJ', lpad(max(CONVERT(SUBSTRING_INDEX(keyjobs,'KYJ',-1),UNSIGNED INTEGER))+1, 5, '0')) AS new_keyjobs
				from mst_keyjobs";
		$query = $this->db->query($str);
		$new_keyjobs = isset($query->row()->new_keyjobs)?$query->row()->new_keyjobs:'-';
		return $new_keyjobs;
	}
	
	function get_auto_organization($term)
	{
		$term = $this->db->escape_str($term);
		$where = " (organization LIKE '%{$term}%' OR organization_desc LIKE '%{$term}%' OR organization_abr LIKE '%{$term}%')";
		$qstr = "(SELECT * FROM mst_organization WHERE ". $where . ")  LIMIT 0, 10";
		$query = $this->db->query($qstr);
		return $query->result();
	}
	
	function get_auto_organization_parent($term)
	{
		$term = $this->db->escape_str($term);
		$where = " (organization LIKE '%{$term}%' OR organization_desc LIKE '%{$term}%' OR organization_abr LIKE '%{$term}%') and organization_class in ('top-level','direktorat-level')";
		$qstr = "(SELECT * FROM mst_organization WHERE ". $where . ")  LIMIT 0, 10";
		$query = $this->db->query($qstr);
		return $query->result();
	}
	
	function get_auto_expertise($term)
	{
		$term = $this->db->escape_str($term);
		$where = " (expertise LIKE '%{$term}%' OR expertise_desc LIKE '%{$term}%')";
		$qstr = "(SELECT * FROM mst_expertise WHERE ". $where . ")  LIMIT 0, 10";
		$query = $this->db->query($qstr);
		return $query->result();
	}
	
	function get_expertise($pernr = '')
	{
		$pernr = $this->db->escape_str($pernr);
		$qstr = "SELECT a.*, b.expertise_desc FROM mst_employee_expertise a inner join mst_expertise b on a.expertise = b.expertise  WHERE a.pernr = '{$pernr}' ";
		$query = $this->db->query($qstr);
		return $query->result();
	}
	
	function get_organization_top_holder($org = '')
	{
		$org = $this->db->escape_str($org);
		$qstr = "SELECT a.*, b.pernr, b.sname, b.stell_tx FROM mst_organization a inner join pa0001_eof b on a.organization_top_holder = b.pernr  WHERE a.organization = '{$org}' LIMIT 0,1";
		$query = $this->db->query($qstr);
		return $query->row();
	}
	
	function get_jobfamily($keyjobs = '')
	{
		$keyjobs = $this->db->escape_str($keyjobs);
		$qstr = "SELECT a.*, b.expertise_desc as jf_desc FROM mst_jobfamilies a inner join mst_expertise b on a.jf = b.expertise  WHERE a.keyjobs = '{$keyjobs}' ";
		$query = $this->db->query($qstr);
		return $query->result();
	}
	
	function get_jobtechnicality($keyjobs = '')
	{
		$keyjobs = $this->db->escape_str($keyjobs);
		$qstr = "SELECT a.*, b.expertise_desc as jt_desc FROM mst_jobtechnicalities a inner join mst_expertise b on a.jt = b.expertise  WHERE a.keyjobs = '{$keyjobs}' ";
		$query = $this->db->query($qstr);
		return $query->result();
	}

	function get_talent_class($keyjobs = '')
	{
		$keyjobs = $this->db->escape_str($keyjobs);
		$qstr = "SELECT * FROM mst_keyjobs_talent_class WHERE keyjobs = '{$keyjobs}' ";
		$query = $this->db->query($qstr);
		$selected_talent_class = array();
		foreach($query->result() as $item){
			$selected_talent_class[$item->talent_class] = $item->talent_class;
		}
		return $selected_talent_class;
	}

	function get_readiness($keyjobs = '')
	{
		$keyjobs = $this->db->escape_str($keyjobs);
		$qstr = "SELECT * FROM mst_keyjobs_readiness WHERE keyjobs = '{$keyjobs}' ";
		$query = $this->db->query($qstr);
		$selected_readiness = array();
		foreach($query->result() as $item){
			$selected_readiness[$item->readiness] = $item->readiness;
		}
		return $selected_readiness;
	}
	
	function get_successors_person($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "talent_succession_plan_results_person";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT * FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	function insert_candidates_bucket($param_ins, $param){
		try{
			$this->db->trans_begin();
			
			$this->db->insert('talent_bucket', $param_ins);
			$ins_id = $this->db->insert_id();
			
			$qstr = "insert into talent_candidates_results select {$ins_id} as id_bucket, a.*, @rank:=@rank+1 AS urutan
			from talent_succession_plan_results a 
			join (select @rank:=0) b
			where a.keyjobs = '{$param['keyjobs']}' and a.is_checked = 1 
			order by a.rank;";
			
			$this->db->query($qstr);
	
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				return array('status'=>false,'message'=>'Data gagal disimpan.');
			} else { 
				$this->db->trans_commit();
				return array('status'=>true,'message'=>'Data berhasil disimpan.');
			}
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return array('status'=>false,'message'=>'Data gagal disimpan. Terjadi kesalahan sistem.');
        }
	}

	function get_candidates($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "talent_bucket a inner join mst_keyjobs b on a.keyjobs = b.keyjobs inner join mst_organization c on b.organization = c.organization";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT a.*, b.keyjobs_desc, c.organization_desc, c.organization_abr FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	public function get_checker_signer($term) {
		$clr_term = $this->db->escape_str($term);
		$query_users = 	   "SELECT 		A.PERNR
								  	  , A.SNAME
								  	  , A.STELL_TX
								  	  , A.KOSTL_TX 
							FROM 		pa0001_eof A 
							WHERE 		(A.PERNR LIKE '%{$clr_term}%' 
									OR 	A.SNAME LIKE '%{$clr_term}%')  AND BTRTL = 'KP01' AND PERNR <> '{$_SESSION[$this->config->item('session_prefix')]['pernr']}'
							ORDER BY 	A.PERNR ASC
							LIMIT 0,10";
		
		return $this->db->query($query_users);
	}

	public function get_auto_candidates($term) {
		$clr_term = $this->db->escape_str($term);
		$query_users = 	   "SELECT 		A.PERNR
								  	  , A.SNAME
								  	  , A.STELL_TX
								  	  , A.KOSTL_TX 
							FROM 		pa0001_eof A 
							WHERE 		(A.PERNR LIKE '%{$clr_term}%' 
									OR 	A.SNAME LIKE '%{$clr_term}%')
							ORDER BY 	A.PERNR ASC
							LIMIT 0,10";
		
		return $this->db->query($query_users);
	}

	public function get_selected_pekerja($pernr='') {
		return $this->db->get_where('pa0001_eof', array('pernr' => $pernr))->row();
	}

	function update_ordered_list($param=array(), $new_urutan=0){
		try{
			$this->db->trans_begin();
			$ret = array('status' => false, 'message'=> 'Terjadi Kesalahan Sistem.');
		
			$candidates = $this->db->get_where('talent_candidates_results', $param)->row();
			
			if($candidates->urutan > $new_urutan){
				$str = "update talent_candidates_results set urutan = (urutan+1) where id_bucket = {$candidates->id_bucket} and keyjobs = '{$candidates->keyjobs}' and urutan < {$candidates->urutan} and urutan >= {$new_urutan}";
				$exe = $this->db->query($str);
			}
			else{
				$str = "update talent_candidates_results set urutan = (urutan-1) where id_bucket = {$candidates->id_bucket} and keyjobs = '{$candidates->keyjobs}' and urutan <= {$new_urutan} and urutan > {$candidates->urutan}";
				$exe = $this->db->query($str);
			}
			//echo $str;
			$this->db->update('talent_candidates_results', array('urutan' => $new_urutan), $param);
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
			} else { 
				$this->db->trans_commit();
				$ret['status'] = true;
				$ret['message'] = 'Perubahan berhasil disimpan.';
			}
			return $ret;
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return $ret;
        }
	}

	function delete_candidates($param){
		try{
			$this->db->trans_begin();
			$ret = array('status' => false, 'message'=> 'Terjadi Kesalahan Sistem.');
			$candidates = $this->db->get_where('talent_candidates_results', $param)->row();
			
			$this->db->delete('talent_candidates_results', $param);
			
			$str = "update talent_candidates_results set urutan = (urutan-1) where id_bucket = {$candidates->id_bucket} and keyjobs = '{$candidates->keyjobs}' and urutan > {$candidates->urutan} ";
			$exe = $this->db->query($str);
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
			} else { 
				$this->db->trans_commit();
				$ret['status'] = true;
				$ret['message'] = 'Perubahan berhasil disimpan.';
			}
			return $ret;
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return $ret;
        }
	}

	function save_new_candidates($param, $candidates){
		try{
			$this->db->trans_begin();
			$ret = array('status' => false, 'message'=> 'Terjadi Kesalahan Sistem.');
			
			$this->db->select('max(urutan) as maks_urutan');
			$talent = $this->db->get_where('talent_candidates_results', array('id_bucket' => $param['id_bucket']))->row();

			$jg = explode("/",isset($candidates->JGPG)?$candidates->JGPG:0);
			$jg = isset($jg[0]) ? (substr(trim($jg[0]), -2)) : 0;
			$data_ins = array(
				'id_bucket' => $param['id_bucket']
				, 'pernr' => isset($candidates->PERNR)?$candidates->PERNR:''
				, 'keyjobs' => $param['keyjobs']
				, 'nama' => isset($candidates->SNAME)?$candidates->SNAME:''
				, 'jobgrade' => $jg
				, 'tanggallahir' => isset($candidates->TANGGALLAHIR)?$candidates->TANGGALLAHIR:''
				, 'area' => isset($candidates->WERKS_TX)?$candidates->WERKS_TX:''
				, 'subarea' => isset($candidates->BTRTL_TX)?$candidates->BTRTL_TX:''
				, 'costcenter' => isset($candidates->KOSTL_TX)?$candidates->KOSTL_TX:''
				, 'htext' => isset($candidates->HTEXT)?$candidates->HTEXT:''
				, 'overall_compability' => $param['overall_compability']
				, 'is_checked' => 1
				, 'urutan' => isset($talent->maks_urutan)?$talent->maks_urutan+1:1
			);

			$this->db->insert('talent_candidates_results', $data_ins);
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
			} else { 
				$this->db->trans_commit();
				$ret['status'] = true;
				$ret['message'] = 'Data berhasil disimpan.';
			}
			return $ret;
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return $ret;
        }
	}

	function is_candidates_exist($param){
		$condition = array('id_bucket' => $param['id_bucket'], 'keyjobs' => $param['keyjobs'], 'pernr' => $param['candidates']);
		$this->db->select('count(*) as jml');
		$candidates = $this->db->get_where('talent_candidates_results', $condition)->row();
		return isset($candidates->jml)?($candidates->jml>0?true:false):true;
	}

	public function approve_data($id_bucket = 0, $komentar = ''){
		try{
			$username = $_SESSION[$this->config->item('session_prefix')]['pernr'];
			$tgl_proses 	= date('Y-m-d H:i:s');

			$clr_catatan 	= $this->db->escape(str_replace('~', ' ', $komentar));
			$this->db->select('id_bucket, approver, status_approval, status, posisi');
			$usulan = $this->db->get_where('talent_bucket', array('id_bucket' => $id_bucket))->row();
			//var_dump();die;
			$split_username_approver = explode('~', $usulan->approver);
			$status_approval = trim($usulan->status_approval);
			$status_approval = $status_approval.($status_approval!=''?'|':'').'0';
			
			$clr_status = 1;
			if ($username == $split_username_approver[count($split_username_approver) - 1]) {   //posisi terakhir atasan
				$clr_posisi_usulan = 'SELESAI';
				$clr_status = 2;
			} else {
				$posisi = 0;
				for ($i = 0; $i < count($split_username_approver); $i++) {
					if ($split_username_approver[$i] == $username) {
						$posisi = $i;
						break;
					}
				}

				$clr_posisi_usulan = $split_username_approver[$posisi + 1];
			}
			
			$approve_usulan =  "UPDATE talent_bucket 
									SET 	status = {$clr_status}
										  , catatan_approver = 	
											CASE 
												WHEN tgl_proses <> '' THEN CONCAT(catatan_approver, '~', {$clr_catatan}) 
												ELSE {$clr_catatan} 
											END
										  , tgl_proses = 
											CASE 
												WHEN tgl_proses <> '' THEN CONCAT(tgl_proses, '~', '{$tgl_proses}') 
												ELSE '{$tgl_proses}' 
											END
										  , posisi = '{$clr_posisi_usulan}'
										  , status_approval = '{$status_approval}'
											WHERE id_bucket = {$id_bucket}";

			$this->db->query($approve_usulan);

			if ($this->db->trans_status() === FALSE) {
				$this->db->trans_rollback();
				return array('error' => true, 'message' => 'Pengajuan Gagal Disetujui. Terjadi Kesalahan Sistem.');
			} else {
				$this->db->trans_commit();
				return array('error' => false, 'message' => 'Pengajuan Berhasil Disetujui.', 'status' => $clr_status);
			}
			
		} catch(Exception $e) {
			return array('error' => true, 'message' => 'Pengajuan Gagal Disetujui. Terjadi Kesalahan Sistem.');
		}
	}
	
	public function reject_data($id_bucket = 0, $komentar = ''){
		try{

			$username = $_SESSION[$this->config->item('session_prefix')]['pernr'];
			$tgl_proses 	= date('Y-m-d H:i:s');

			$clr_catatan 	= $this->db->escape(str_replace('~', ' ', $komentar));
			
			$this->db->select('id_bucket, approver, status_approval, status, posisi');
			$usulan = $this->db->get_where('talent_bucket', array('id_bucket' => $id_bucket))->row();
			
			$status_approval = trim($usulan->status_approval);
			$status_approval = $status_approval.($status_approval!=''?'|':'').'1';
			
			$approve_usulan =  "UPDATE talent_bucket 
									SET 	status = 3
										  , catatan_approver = 	
											CASE 
												WHEN tgl_proses <> '' THEN CONCAT(catatan_approver, '~', {$clr_catatan}) 
												ELSE {$clr_catatan} 
											END
										  , tgl_proses = 
											CASE 
												WHEN tgl_proses <> '' THEN CONCAT(tgl_proses, '~', '{$tgl_proses}') 
												ELSE '{$tgl_proses}' 
											END
										  , status_approval = '{$status_approval}'
											WHERE id_bucket = {$id_bucket}";

			$this->db->query($approve_usulan);

			if ($this->db->trans_status() === FALSE) {
				$this->db->trans_rollback();
				return array('error' => true, 'message' => 'Pengajuan Gagal Ditolak. Terjadi Kesalahan Sistem.');
			} else {
				$this->db->trans_commit();
				return array('error' => false, 'message' => 'Pengajuan Berhasil Ditolak.');
			}
		} catch(Exception $e) {
			return array('error' => true, 'message' => 'Pengajuan Gagal Ditolak. Terjadi Kesalahan Sistem.');
		}
	}

	public function get_opt_bucket($keyjobs=''){
		$query_plans = "select * from talent_bucket where keyjobs = '{$keyjobs}' and status not in (4) order by modified_date desc";
		$query = $this->db->query($query_plans);
		$data = array();
		foreach ($query->result() as $row) {
			$data[$row->id_bucket] =  $row->bucket_name;
		}
		return $data;
	}

	function get_bucket_successors($count=false,$param='',$order='',$start='',$limits='')
	{
		$order = trim($order);
		$start = trim($start);
		$limits= trim($limits);
		$where = '';
		if($param!=''){
			if(is_array($param)){
				foreach($param as $value){
					if(trim($where)!=''){
						$where .= isset($value['operator'])?" {$value['operator']} ":'';
					}
					$field = isset($value['field'])?$value['field']:'';
					$field_operator = isset($value['field_operator'])?' '.$value['field_operator'].' ':'';
					if(isset($value['value'])){
						if(is_array($value['value'])){
							$arr_temp = array();
							foreach($value['value'] as $idx=>$item){
								if($value['escape_type']==1){
									$arr_temp[$idx] = $this->db->escape($item);
								}else{
									$arr_temp[$idx] = $this->db->escape_str($item);
								}
							}
							$field_value = "(".implode(",",$arr_temp).")";
						}else{
							if($value['escape_type']==1){
								$field_value = $this->db->escape($value['value']);
							}else{
								$field_value = $this->db->escape_str($value['value']);
							}
						}
					}else{
						$field_value = '';
					}
					$prefix = isset($value['prefix'])?$value['prefix']:'';
					$sufix = isset($value['sufix'])?$value['sufix']:'';
					$where .= $field.$field_operator.$prefix.$field_value.$sufix;
				}
			}else{
				$where = trim($param);
			}
		}
		$where = trim($where);
		$where = ($where!='')?" WHERE 1 AND ".$where : " WHERE 1 ";
		$table = "talent_candidates_results";
		if($count){
			$qstr	= "SELECT count(*) as jumlah_row FROM {$table}";
			$qstr	= $qstr.$where;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			if($query->num_rows()>0){
				return $query->row()->jumlah_row;
			}else{
				return 0;
			}
		}else{
			$clause_limit = '';
			if($start!=='' && $limits!==''){
				$clause_limit = " LIMIT {$start},{$limits}";
			}
			$order = $order!=''?" ORDER BY ".$order:'';
			$qstr	= "SELECT *, urutan as set_rank FROM {$table}";
			$qstr	= $qstr.$where.$order.$clause_limit;
			//echo $qstr;
			$query 	= $this->db->query($qstr);
			if(!$query){
				throw new Exception();
			}
			return $query->result();
		}
	}

	function insert_new_candidates_bucket($param_ins, $param){
		try{
			$this->db->trans_begin();
			
			$this->db->insert('talent_bucket', $param_ins);
			$ins_id = $this->db->insert_id();
			
			$qstr = "insert into talent_candidates_results 
			select {$ins_id} as id_bucket, a.pernr, a.keyjobs, a.overall_compability, a.overall_compability_category, a.overall_compability_class,
			a.nama, a.expertise, a.jobgrade, a.tanggallahir, a.area, a.subarea, a.costcenter, a.talent_class, a.talent_class_desc, a.corp_title_desc, a.htext,
			a.readiness, a.competency, a.skor_exp_compability, a.skor_jg_compability, a.skor_talent_compability, a.skor_potential_compability, a.skor_sertification_compability,
			a.skor_award_compability, a.bobot_exp, a.bobot_jg, a.bobot_talent, a.bobot_potential, a.bobot_sertification, a.bobot_award, a.rank, a.is_checked,
			@rank:=@rank+1 AS urutan
			from talent_candidates_results a 
			join (select @rank:=0) b
			where a.keyjobs = '{$param['keyjobs']}' and a.is_checked = 1 and a.id_bucket = '{$param['bucket']}'
			order by a.rank;";
			
			$this->db->query($qstr);
	
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				return array('status'=>false,'message'=>'Data gagal disimpan.');
			} else { 
				$this->db->trans_commit();
				return array('status'=>true,'message'=>'Data berhasil disimpan.');
			}
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return array('status'=>false,'message'=>'Data gagal disimpan. Terjadi kesalahan sistem.');
        }
	}

	function get_drop_list($param){
		$drop_list =  $this->db->get_where('drop_candidates_list', array('keyjobs' => $param['keyjobs']))->result(); 
		$list_pernr = array(); 
		foreach($drop_list as $item){
			$list_pernr[] = $item->pernr;
		}
		return $list_pernr;
	}

	function get_successors_rotasi($param, $limit){
		$list_pernr = $this->get_drop_list($param);
		$condition = array(
			'keyjobs' => $param['keyjobs']
			, 'corp_title_desc' => $param['corp_title']
		);
		$this->db->order_by('overall_compability desc');
		$this->db->where($condition);
		if(count($list_pernr) > 0){
			$this->db->where_not_in('pernr', $list_pernr);
		}
		$query = $this->db->get('talent_succession_plan_results', $limit, 0);
		//echo $this->db->last_query();
		return $query->result();
	}

	function get_successors_case_promosi($param, $limit){
		$list_pernr = $this->get_drop_list($param);
		$condition = array(
			'keyjobs' => $param['keyjobs']
			, 'corp_title_desc <>' => $param['corp_title']
		);

		$this->db->order_by('overall_compability desc');

		if($param['corp_title'] != 'Executive Vice President'){
			$condition = array(
				'keyjobs' => $param['keyjobs']
			);
			$this->db->where_not_in('corp_title_desc', array('Executive Vice President', 'Vice President'));
		}
		$this->db->where($condition);
		if(count($list_pernr) > 0){
			$this->db->where_not_in('pernr', $list_pernr);
		}
		$query = $this->db->get('talent_succession_plan_results', $limit, 0);
		//echo $this->db->last_query();
		return $query->result();

	}

	function get_wakil_keyjobs($keyjobs = '', $organization = ''){
		//$qstr = "select a.keyjobs, a.jobholder, b.pernr, b.sname as nama, b.htext, b.kostl_tx as costcenter from mst_keyjobs a inner join sdm_monitoring_pekerja b on a.jobholder = b.pernr
		//		where a.status = 1 and a.organization = '{$organization}' and a.keyjobs_desc like 'wakil%' and a.jobholder <> '' limit 0,5";
		$qstr = "select final_oc.*
				from (
				select pernr, keyjobs, skor_exp_compability, skor_jg_compability, skor_talent_compability, skor_potential_compability, skor_sertification_compability, skor_award_compability, 
				(0.35*skor_exp_compability) as `bobot_exp`,
				(0.10*skor_jg_compability) as `bobot_jg`,
				(0.40*skor_talent_compability) as `bobot_talent`,
				bobot_potential,
				bobot_sertification,
				bobot_award,
				((0.35*skor_exp_compability)+(0.10*skor_jg_compability)+(0.40*skor_talent_compability)+bobot_potential+bobot_sertification+bobot_award) as overall_compability
				from (
					select ec.pernr, ec.keyjobs, skor as skor_exp_compability, 
					case when (ec.jobgrade-thm.jobgrade) = 0 then 3
						when (ec.jobgrade-thm.jobgrade) = 1 then 2
						when (ec.jobgrade-thm.jobgrade) = 2 then 1
						else 0 end as skor_jg_compability,
					thm.talent_score as skor_talent_compability,
									0 as `skor_potential_compability`, 0 as `skor_sertification_compability`, 0 as `skor_award_compability`, tpc.bobot_potential, tpc.bobot_sertification, tpc.bobot_award
					from tmp_expertise_compability ec
					inner join talent_hav_matrix thm on ec.pernr = thm.pernr and thm.method = 1 and thm.type = 0 and thm.jenis_asesmen = 1
					inner join tmp_parameter_compability tpc on ec.pernr = tpc.pernr 
					where (ec.jobgrade-thm.jobgrade) <= 5 and (ec.jobgrade-thm.jobgrade) >= 0 
					and ec.keyjobs = '{$keyjobs}' and ec.pernr in (select b.pernr from mst_keyjobs a inner join pa0001_eof b on a.jobholder = b.pernr where a.status = 1 and a.organization = '{$organization}' and a.keyjobs_desc like 'wakil%' and a.jobholder <> '') 
					and ec.pernr not in (select pernr from drop_candidates_list where keyjobs = '{$keyjobs}')
				) oc
			) final_oc
			order by final_oc.overall_compability desc 
			limit 0,3";
		$query = $this->db->query($qstr);
		return $query->result();
	}

	function get_talent_hav($pernr=''){
		$condition = array(
			'pernr' => $pernr
			, 'method' => 1
			, 'type' => 0
			, 'jenis_asesmen' => 1
		);

		$query = $this->db->get_where('talent_hav_matrix', $condition);
		return $query->row();

	}

	function drop_candidates_view($keyjobs, $pernr){
		try{
			$this->db->trans_begin();
			$ret = array('status' => false, 'message'=> 'Terjadi Kesalahan Sistem.');
			$condition = array(
				'keyjobs' => $keyjobs
				, 'pernr' => $pernr
			);
			
			$this->db->delete('drop_candidates_list', $condition);
			
			$param = array(
				'keyjobs' => $keyjobs
				, 'pernr' => $pernr
				, 'last_updated' => date('Y-m-d H:i:s')
				, 'modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			);

			$this->db->insert('drop_candidates_list', $param);
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
			} else { 
				$this->db->trans_commit();
				$ret['status'] = true;
				$ret['message'] = 'Perubahan berhasil disimpan.';
			}
			return $ret;
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return $ret;
        }
	}

	function get_new_candidates_keyjobs($keyjobs = '', $organization = ''){
		//$qstr = "select a.keyjobs, a.jobholder, b.pernr, b.sname as nama, b.htext, b.kostl_tx as costcenter from mst_keyjobs a inner join sdm_monitoring_pekerja b on a.jobholder = b.pernr
		//		where a.status = 1 and a.organization = '{$organization}' and a.keyjobs_desc like 'wakil%' and a.jobholder <> '' limit 0,5";
		$qstr = "select final_oc.*
				from (
				select pernr, keyjobs, skor_exp_compability, skor_jg_compability, skor_talent_compability, skor_potential_compability, skor_sertification_compability, skor_award_compability, 
				(0.35*skor_exp_compability) as `bobot_exp`,
				(0.10*skor_jg_compability) as `bobot_jg`,
				(0.40*skor_talent_compability) as `bobot_talent`,
				bobot_potential,
				bobot_sertification,
				bobot_award,
				((0.35*skor_exp_compability)+(0.10*skor_jg_compability)+(0.40*skor_talent_compability)+bobot_potential+bobot_sertification+bobot_award) as overall_compability
				from (
					select ec.pernr, ec.keyjobs, skor as skor_exp_compability, 
					case when (ec.jobgrade-thm.jobgrade) = 0 then 3
						when (ec.jobgrade-thm.jobgrade) = 1 then 2
						when (ec.jobgrade-thm.jobgrade) = 2 then 1
						else 0 end as skor_jg_compability,
					thm.talent_score as skor_talent_compability,
									0 as `skor_potential_compability`, 0 as `skor_sertification_compability`, 0 as `skor_award_compability`, tpc.bobot_potential, tpc.bobot_sertification, tpc.bobot_award
					from tmp_expertise_compability ec
					inner join talent_hav_matrix thm on ec.pernr = thm.pernr and thm.method = 1 and thm.type = 0 and thm.jenis_asesmen = 1
					inner join tmp_parameter_compability tpc on ec.pernr = tpc.pernr 
					where (ec.jobgrade-thm.jobgrade) <= 5 and (ec.jobgrade-thm.jobgrade) >= 0 
					and ec.keyjobs = '{$keyjobs}' and ec.pernr in (select pernr from add_candidates_list where keyjobs = '{$keyjobs}') 
					and ec.pernr not in (select pernr from drop_candidates_list where keyjobs = '{$keyjobs}')
				) oc
			) final_oc
			order by final_oc.overall_compability desc 
			limit 0,10";
		//echo $qstr;
		$query = $this->db->query($qstr);
		return $query->result();
	}

	function add_candidates_view($keyjobs, $pernr){
		try{
			$this->db->trans_begin();
			$ret = array('status' => false, 'message'=> 'Terjadi Kesalahan Sistem.');
			$condition = array(
				'keyjobs' => $keyjobs
				, 'pernr' => $pernr
			);
			
			$this->db->delete('add_candidates_list', $condition);

			$exp = $this->db->get_where('tmp_expertise_compability', $condition)->row();

			if(!isset($exp->pernr)){
				$talent = $this->get_talent_hav($pernr);
				$ins = array(
					'keyjobs' => $keyjobs
					, 'pernr' => $pernr
					, 'jobgrade' => isset($talent->jobgrade)?$talent->jobgrade:0
					, 'skor' => 0
				);
				$this->db->insert('tmp_expertise_compability', $ins);
			}
			
			$param = array(
				'keyjobs' => $keyjobs
				, 'pernr' => $pernr
				, 'last_updated' => date('Y-m-d H:i:s')
				, 'modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			);

			$this->db->insert('add_candidates_list', $param);
			
			if($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
			} else { 
				$this->db->trans_commit();
				$ret['status'] = true;
				$ret['message'] = 'Perubahan berhasil disimpan.';
			}
			return $ret;
		}
		catch (Exception $e) {
			$this->db->trans_rollback();
            return $ret;
        }
	}

}