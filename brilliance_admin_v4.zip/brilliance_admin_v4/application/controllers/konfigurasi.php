<?php defined('BASEPATH') OR exit('No direct script access allowed');
header("Strict-Transport-Security: max-age=31536000; includeSubDomains; preload");

class Konfigurasi extends CI_Controller {
	
	public function __construct()
   	{
		parent::__construct();
		// Your own constructor code
		$this->mysession->check_no_session();
		$this->mysession->check_session_expired();
		$this->load->model(array('user_model', 'konfigurasi_model', 'template_model', 'option_model', 'talent_model', 'hasil_model', 'pegawai_model'));
   	}
	
	public function autocomp_template(){
		$term = $this->input->get('term');
		$self_id = $this->input->get('self_id');
		if($self_id == '')
			$self_id = 0;
		$res = $this->konfigurasi_model->autocomp_template($term, 1, $self_id);
		if($res->num_rows() > 0){
			$ret = array();
			foreach($res->result() as $row){
				$ret[] = array('id'=>$row->id, 'label'=> ($row->id . ' / ' . $row->t_text));
			}
			echo json_encode($ret);
		} else{
			echo json_encode(array('0'=>array('id'=>'', 'label'=>'-Data tidak ditemukan-')));
		}
	}
	
	public function filter_tree_template()
	{
		$data = array();
		$this->load->view('konfigurasi/filter_tree_template',$data);
	}
	
	public function tree_template() {
		$this->form_validation->set_rules('f_keyword', 'Kata Kunci', 'trim');
		if($this->form_validation->run() == TRUE) {
			$filter['f_keyword'] 	= $this->input->post('f_keyword');
			
			if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KW'){
				$param["a.area"] = array('AND',1,$_SESSION[$this->config->item('session_prefix')]['pa']);
			}
			
			if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KC' || $_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KN' || $_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'SD'){
				$param["a.subarea"] = array('AND',1,$_SESSION[$this->config->item('session_prefix')]['psa']);
			}
			
			if($filter['f_keyword'] != '') {
				$arr_term = explode('/',$filter['f_keyword']);
				$id = isset($arr_term[0])?trim($arr_term[0]):'';
				$param["a.id"] = array('AND',1,$id);
			}
			else{
				$param["a.id"] = array('AND',1,1);
				if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KW'){
					$param["a.subarea"] = array('OR',1,'ALL');
				}
				
				if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KC' || $_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KN' || $_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'SD'){
					$param["a.area"] = array('OR',1,'ALL');
				}
			}
			
			
			$data['template'] = $this->konfigurasi_model->get_parent_template($param);
			if(count($data['template']) > 0)
				$this->load->view('konfigurasi/tree_template',$data);
			else
				echo $this->libs->generate_message('danger','Data Tidak Ditemukan.');
		} else {
			echo '<center class="error message" style="cursor:pointer;">Parameter tidak valid.</center>';
		}
	}
	
	// public function get_child_template()
	// {
	// 	$id = $this->input->post('id');
	// 	$child = $this->konfigurasi_model->get_child_template($id);
	// 	$count = count($child);
	// 	if( $count > 0){
	// 		echo '<ul class="jstree-children" role="group">';
	// 		$last = '';
	// 		foreach($child as $idx => $ch){
	// 			$last = ($count == ($idx+1)) ? 'jstree-last' : '';
	// 			$li_id = "j" . $idx . '_' . rand();
	// 			echo '<li id="'.$li_id.'" class="jstree-node '.($ch->is_search == 0 ? "jstree-closed" : "jstree-leaf").' '.$last.'" role="treeitem" aria-selected="false" aria-level="2" aria-labelledby="'.$li_id.'_anchor" aria-expanded="false"><i class="jstree-icon jstree-ocl" role="presentation"></i>';
	// 			echo '<a class="jstree-anchor" href="#" tabindex="-1" id="'.$li_id.'_anchor"><i class="jstree-icon jstree-themeicon" role="presentation"></i><span class="ch_template to_child" rel="'.$ch->id.'" level="'.$ch->level.'" is_search="'.$ch->is_search.'">'.$ch->t_text.'</span>';
	// 			if($ch->is_search == 0)
	// 				echo '<table style="float:right;border-collapse:collapse;margin:-25px;" cellspacing="0px" cellpadding="0px" border="0"><tbody><tr><td width="360px" valign="top" align="right"><input type="button" value="Add Child" class="btn btn-xs btn-info add_child">&nbsp;<input value="Detail" class="btn btn-xs btn-primary detail" type="button">&nbsp;<input value="Move" class="btn btn-xs btn-danger move" type="button">&nbsp;<input value="Edit" class="btn btn-xs btn-info edit" type="button">&nbsp;<input value="Copy" class="btn btn-xs btn-warning salin" type="button">&nbsp;<input value="Delete" class="btn btn-xs btn-danger delete" type="button"></td></tr></tbody></table>';
				
	// 			echo '</a></li>';
	// 		}
	// 		echo '</ul>';
	// 	}
	// }
	
	public function add_template_child(){
		$id = $this->input->post('id');
		$data['parent'] = $this->konfigurasi_model->get_template($id);
		$this->load->view('konfigurasi/add_template_child',$data);
	}
	
	public function save_child(){	
		$param = array(
			't_text' => $this->input->post('deskripsi'),
			'level' => ($this->input->post('parent_level') + 1),
			'parent' => ($this->input->post('parent_id')),
			'status' => 1,
			'is_search' => 0,	
			'area' => $_SESSION[$this->config->item('session_prefix')]['pa'],	
			'subarea' => $_SESSION[$this->config->item('session_prefix')]['psa'],
			'tipe_uker' => $_SESSION[$this->config->item('session_prefix')]['tipe_uker'],
			'last_updated' => date('Y-m-d H:i:s'),
			'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx'],
			'periode' => date('m') . date('Y')
		);
		$process = $this->konfigurasi_model->save_child($param);
		if($process['status']){
			$this->auditrail_model->add_log('Konfigurasi', 'Add Child');
			$data['message'] = $this->libs->generate_message('success',$process['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$process['message']);
		}
		$this->load->view('konfigurasi/filter_tree_template',$data);
	}
	
	public function view_template_child(){
		$id = $this->input->post('id');
		$data['self'] = $this->konfigurasi_model->get_template($id);
		$data['parent'] = $this->konfigurasi_model->get_template($data['self']->parent);
		$this->load->view('konfigurasi/view_template_child',$data);
	}
	
	public function move_template_child(){
		$id = $this->input->post('id');
		$data['self'] = $this->konfigurasi_model->get_template($id);
		$data['parent'] = $this->konfigurasi_model->get_template($data['self']->parent);
		$this->load->view('konfigurasi/move_template_child',$data);
	}
	
	public function move_child(){
		$new_parent = explode('/', $this->input->post('new_parent'));
		$id = isset($new_parent[0])?($this->db->escape(trim($new_parent[0]))):'';
		$get_new_parent = $this->konfigurasi_model->get_template($id);
		if(count($get_new_parent) > 0){
			$param = array(
				'parent' => $get_new_parent->id,
				'last_updated' => date('Y-m-d H:i:s'),
				'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			);
			$condition = array('id' => $this->input->post('self_id'));
			$process = $this->konfigurasi_model->move_child($param, $condition);
			
			if($process['status']){
				$this->auditrail_model->add_log('Konfigurasi', 'Move Child');
				$data['message'] = $this->libs->generate_message('success',$process['message']);
			}
			else{
				$data['message'] = $this->libs->generate_message('danger',$process['message']);
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','New Parent Tidak Ditemukan');
		}
		$this->load->view('konfigurasi/filter_tree_template',$data);
	}
	
	public function edit_template_child(){
		$id = $this->input->post('id');
		$data['self'] = $this->konfigurasi_model->get_template($id);
		$data['parent'] = $this->konfigurasi_model->get_template($data['self']->parent);
		$this->load->view('konfigurasi/edit_template_child',$data);
	}
	
	public function edit_child(){	
		$param = array(
			't_text' => $this->input->post('deskripsi'),
			'last_updated' => date('Y-m-d H:i:s'),
			'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
		);
		$process = $this->db->update('mst_tree_template', $param, array('id' => $this->input->post('self_id')));
		if($process){
			$this->auditrail_model->add_log('Konfigurasi', 'Edit Child');
			$data['message'] = $this->libs->generate_message('success','Data Berhasil Disimpan.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Data Gagal Disimpan.');
		}
		$this->load->view('konfigurasi/filter_tree_template',$data);
	}
	
	public function salin_template_child(){
		$id = $this->input->post('id');
		$data['self'] = $this->konfigurasi_model->get_template($id);
		$data['parent'] = $this->konfigurasi_model->get_template($data['self']->parent);
		$this->load->view('konfigurasi/salin_template_child',$data);
	}
	
	public function salin_child(){
		$new_parent = explode('/', $this->input->post('parent'));
		$old_id_template = $this->input->post('old_id_template');
		$id = isset($new_parent[0])?($this->db->escape(trim($new_parent[0]))):'';
		$get_new_parent = $this->konfigurasi_model->get_template($id);
		if(count($get_new_parent) > 0){
			$old_key = $this->template_model->get_template_filter_by($old_id_template);
			$param = array(
				't_text' => $this->input->post('deskripsi'),
				'level' => ($get_new_parent->level + 1),
				'parent' => ($get_new_parent->id),
				'status' => 1,
				'is_search' => 0,	
				'area' => $_SESSION[$this->config->item('session_prefix')]['pa'],	
				'subarea' => $_SESSION[$this->config->item('session_prefix')]['psa'],	
				'tipe_uker' => $_SESSION[$this->config->item('session_prefix')]['tipe_uker'],
				'last_updated' => date('Y-m-d H:i:s'),
				'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			);
			$process = $this->konfigurasi_model->salin_child($param, $old_key);
			
			if($process['status']){
				$this->auditrail_model->add_log('Konfigurasi', 'Salin Child');
				$data['message'] = $this->libs->generate_message('success',$process['message']);
			}
			else{
				$data['message'] = $this->libs->generate_message('danger',$process['message']);
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Parent Tidak Ditemukan');
		}
		$this->load->view('konfigurasi/filter_tree_template',$data);
	}
	
	public function delete_template_child(){	
		$param = array(
			'status' => 0,
			'last_updated' => date('Y-m-d H:i:s'),
			'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
		);
		$process = $this->db->update('mst_tree_template', $param, array('id' => $this->input->post('id')));
		if($process){
			$this->auditrail_model->add_log('Konfigurasi', 'Delete Child');
			$data['message'] = $this->libs->generate_message('success','Data Berhasil Dihapus.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Data Gagal Dihapus.');
		}
		$this->load->view('konfigurasi/filter_tree_template',$data);
	}
	
	public function filter_user_access(){
		$data = array(
			'opt_user' => $this->konfigurasi_model->mst_level_user()
        );
		$data['result'] = $this->user_access(true);
		$this->load->view('konfigurasi/filter_user_access', $data);
	}
	
	public function user_access($string=false)
	{
		$filter['f_user'] = trim($this->input->post('f_user'));
		$filter['f_pernr'] = trim($this->input->post('f_pernr'));
		
		$this->load->library(array('pagination'));
		$param = array();
		if($filter['f_pernr']!=''){
			if(strpos($filter['f_pernr'],'/')!=FALSE){
				$arr_term = explode('/',$filter['f_pernr']);
				$kode = isset($arr_term[0])?trim($arr_term[0]):'';
				$nama = isset($arr_term[1])?trim($arr_term[1]):'';
				$param[] = $this->libs->arrWhere('AND','a.pernr',"%{$kode}%",'1','LIKE');
				$param[] = $this->libs->arrWhere('AND','a.nama',"%{$nama}%",'1','LIKE');
			}else{
				$param[] = $this->libs->arrWhere('AND','(a.pernr',"%{$filter['f_pernr']}%",'1','LIKE');
				$param[] = $this->libs->arrWhere('OR','a.nama',"%{$filter['f_pernr']}%",'1','LIKE','',')');
			}
		}
		if($filter['f_user']!=''){
			$param[] = $this->libs->arrWhere('AND','a.level',"{$filter['f_user']}",'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/user_access/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_mst_user(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['user'] = $this->konfigurasi_model->get_mst_user(false,$param,'a.pernr asc, a.nama asc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('konfigurasi/user_access',$data,true); 
		}else{
			$this->load->view('konfigurasi/user_access',$data);
		}
	}
	
	public function delete_mst_user()
	{
		if($this->input->post('delete')){
			$this->form_validation->set_rules('pernr', 'PERNR', 'trim|required');
			if($this->form_validation->run()==TRUE){
				$this->auditrail_model->add_log('Konfigurasi', 'Delete User Access');
				if($this->konfigurasi_model->delete_mst_user($this->input->post('pernr'))){
					$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('success','Data berhasil dihapus.');
				}else{
					$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('danger','Data gagal dihapus.');
				}
			}else{
				$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('danger','Parameter tidak valid.');
			}
		}
		$this->user_access(false);
	}
	
	public function add_mst_user()
	{
		if($this->input->post('save')){
			$this->form_validation->set_rules('pernr', 'Personal Number', 'trim|required');
			$this->form_validation->set_rules('level', 'Level User', 'trim|required');
			if($this->form_validation->run()==TRUE){
				$arr_pekerja = explode('/', $this->input->post('pernr'));
				$pernr = $this->libs->correctDigit(8,$arr_pekerja[0]);
				$param[] = $this->libs->arrWhere('AND','PERNR',$pernr);
				$param[] = $this->libs->arrWhere('AND','TIPE_UKER', array('KP', 'KW', 'SD', 'KN', 'KCK', 'KC'),'1','IN');
				$pekerja = $this->general_model->mysql_get_data_with_connection(false,'portalsdm','pa0001_eof','',$param,'PERNR ASC',0,1);
				if(count($pekerja)>0){
					$data_ins = array(
						'pernr' => $pekerja[0]->PERNR,
						'nama' => $pekerja[0]->SNAME,
						'detail' => $pekerja[0]->STELL_TX . ' / ' . $pekerja[0]->KOSTL_TX . ' / ' . $pekerja[0]->BTRTL_TX,
						'area' => $pekerja[0]->WERKS,
						'subarea' => $pekerja[0]->BTRTL,
						'tipe_uker' => $pekerja[0]->TIPE_UKER,
						'level' => $this->input->post('level'),
						'last_updated' => date('Y-m-d H:i:s'),
						'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
					);
					$arr_user = $this->konfigurasi_model->insert_mst_user($data_ins);
					if($arr_user['status']){
						$data['message'] = $this->libs->generate_message('success',$arr_user['message']);
						unset($_POST);
					}else{
						$data['message'] = $this->libs->generate_message('danger',$arr_user['message']);
					}
				}else{
					$data['message'] = $this->libs->generate_message('danger','Personal number yang Anda masukkan tidak valid.');
				}
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}
		$data['opt_user'] = $this->konfigurasi_model->mst_level_user();
		$this->load->view('konfigurasi/form_add_user',$data);
	}
	
	public function filter_parameter_gauge()
	{
		$data = array(
			'opt_status' => array('' => '- Pilih Status -', 1 => 'Aktif', 2 => 'Non Aktif')
        );
		$data['result'] = $this->parameter_gauge(true);
		$this->load->view('konfigurasi/filter_parameter_gauge', $data);
	}
	
	public function parameter_gauge($string=false)
	{
		$filter['f_status'] = trim($this->input->post('f_status'));
		
		$this->load->library(array('pagination'));
		$param = array();

		if($filter['f_status']!=''){
			$param[] = $this->libs->arrWhere('AND','status',"{$filter['f_status']}",'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/parameter_gauge/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_mst_gauge(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['user'] = $this->konfigurasi_model->get_mst_gauge(false,$param,'urutan',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('konfigurasi/parameter_gauge',$data,true); 
		}else{
			$this->load->view('konfigurasi/parameter_gauge',$data);
		}
	}
	
	public function add_mst_gauge()
	{
		if($this->input->post('save')){
			$this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim|required');
			$this->form_validation->set_rules('formula', 'Formula', 'trim|required');
			$this->form_validation->set_rules('satuan', 'Satuan', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			$this->form_validation->set_rules('target', 'Target', 'trim|required|is_numeric');
			$this->form_validation->set_rules('pencapaian', 'Pencapaian', 'trim|required|is_numeric');
			$this->form_validation->set_rules('urutan', 'Urutan', 'trim|required|is_numeric');
			$this->form_validation->set_rules('max_range', 'Maks Range', 'trim|required|is_numeric');
			if($this->form_validation->run()==TRUE){
				$data_ins = array(
					'keterangan' => $this->input->post('deskripsi'),
					'formula' => $this->input->post('formula'),
					'satuan' => $this->input->post('satuan'),
					'target' => $this->input->post('target'),
					'max_range' => $this->input->post('max_range'),
					'pencapaian' => $this->input->post('pencapaian'),
					'status' => $this->input->post('status'),
					'urutan' => $this->input->post('urutan'),
					'last_updated' => date('Y-m-d H:i:s'),
					'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
				);
				$arr_user = $this->konfigurasi_model->insert_mst_gauge($data_ins);
				if($arr_user['status']){
					$data['message'] = $this->libs->generate_message('success',$arr_user['message']);
					unset($_POST);
				}else{
					$data['message'] = $this->libs->generate_message('danger',$arr_user['message']);
				}

			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}
		$data['opt_farmula'] = array('' => '- Pilih Formula -', 'maximize' => 'Maximize', 'minimize' => 'Minimize');
		$data['opt_status'] = array('' => '- Pilih Status -', 1 => 'Aktif', 2 => 'Non Aktif');
		$this->load->view('konfigurasi/form_add_gauge',$data);
	}
	
	public function status_mst_gauge()
	{
		if($this->input->post('id_gauge')){
			$this->form_validation->set_rules('id_gauge', 'ID', 'trim|required');
			if($this->form_validation->run()==TRUE){
				$this->auditrail_model->add_log('Konfigurasi', 'Non Aktifkan Parameter Gauge.');
				if($this->db->update('mst_gauge',array('status' => $this->input->post('status')), array('id_gauge' => $this->input->post('id_gauge')))){
					$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('success','Data berhasil dirubah.');
				}else{
					$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('danger','Data gagal dirubah.');
				}
			}else{
				$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('danger','Parameter tidak valid.');
			}
		}
		$this->parameter_gauge(false);
	}
	
	public function update_mst_gauge()
	{
		$data = array();
		$id_gauge = $this->input->post('id_gauge');
		if($this->input->post('save')){
			$this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim|required');
			$this->form_validation->set_rules('formula', 'Formula', 'trim|required');
			$this->form_validation->set_rules('satuan', 'Satuan', 'trim|required');
			$this->form_validation->set_rules('target', 'Target', 'trim|required|is_numeric');
			$this->form_validation->set_rules('pencapaian', 'Pencapaian', 'trim|required|is_numeric');
			$this->form_validation->set_rules('urutan', 'Urutan', 'trim|required|is_numeric');
			$this->form_validation->set_rules('max_range', 'Range Maks', 'trim|required|is_numeric');
			if($this->form_validation->run()==TRUE){
				$data_ = array(
					'keterangan' => $this->input->post('deskripsi'),
					'formula' => $this->input->post('formula'),
					'satuan' => $this->input->post('satuan'),
					'target' => $this->input->post('target'),
					'max_range' => $this->input->post('max_range'),
					'pencapaian' => $this->input->post('pencapaian'),
					'urutan' => $this->input->post('urutan'),
					'last_updated' => date('Y-m-d H:i:s'),
					'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
				);
				$arr_input = $this->konfigurasi_model->update_mst_gauge($data_, $id_gauge);
				if($arr_input['status']){
					$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
					unset($_POST);
				}else{
					$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
				}
				
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}
		$data['gauge'] = $this->db->get_where('mst_gauge',array('id_gauge'=>$id_gauge))->row();
		$data['opt_farmula'] = array('' => '- Pilih Formula -', 'maximize' => 'Maximize', 'minimize' => 'Minimize');
		$data['opt_status'] = array('' => '- Pilih Status -', 1 => 'Aktif', 2 => 'Non Aktif');
		$this->load->view('konfigurasi/form_update_gauge',$data);
	}
	
	public function filter_struktur_organisasi(){
		$data = array(
			'opt_organization_area' => $this->option_model->opt_organization_area()
        );
		$data['result'] = $this->load->view('talent/empty_organization_area', $data, true);
		$this->load->view('konfigurasi/filter_struktur_organisasi', $data);
	}
	
	public function struktur_organisasi(){
		$data = array();
		$f_organization_area = $this->input->post('f_organization_area');
		if($f_organization_area != ''){
			$data['parent'] = $this->db->get_where('mst_organization' , array('organization_level' => 0, 'organization_area' => $f_organization_area))->row();
			$this->load->view('konfigurasi/struktur_organisasi', $data);
		}
		else{
			$this->load->view('talent/empty_organization_area', $data);
		}
	}
	
	public function organization_setting(){
		$data = array();
		$filter['organization'] = $this->input->get_post('organization');
		
		if($this->input->post('save')){
			$this->form_validation->set_rules('organization_desc', 'Organization Desc.', 'trim|required');
			$this->form_validation->set_rules('organization_abr', 'Organization Abre.', 'trim|required');
			$this->form_validation->set_rules('organization_top_holder', 'Organization Top Holder', 'trim');
			//$this->form_validation->set_rules('organization_class', 'Organization Class', 'trim|required');
			$this->form_validation->set_rules('status', 'Status Class', 'trim|required');
			
			if($this->form_validation->run()==TRUE){
				$top_holder = $this->input->post('organization_top_holder');
				$arr_pekerja = explode('/', $top_holder);
				$pernr = $this->libs->correctDigit(8,$arr_pekerja[0]);
				$param[] = $this->libs->arrWhere('AND','PERNR',$pernr);
				$pekerja = $this->general_model->mysql_get_data_with_connection(false,'portalsdm','pa0001_eof','',$param,'PERNR ASC',0,1);
				if(count($pekerja)>0 || $top_holder == ''){
					if($top_holder == '')
						$pernr = 'none';
					$data_ = array(
						'organization_desc' => $this->input->post('organization_desc'),
						'organization_abr' => $this->input->post('organization_abr'),
						'status' => $this->input->post('status'),
						'organization_top_holder' => $pernr,
						'last_updated' => date('Y-m-d H:i:s'),
						'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
					);
					$arr_input = $this->konfigurasi_model->update_organization($data_, $filter['organization']);
					if($arr_input['status']){
						$this->auditrail_model->add_log('Konfigurasi', 'Update Organization');
						$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
						unset($_POST);
					}else{
						$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
					}
				}else{
					$data['message'] = $this->libs->generate_message('danger','Personal number yang Anda masukkan tidak valid.');
				}
				
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}
		$data['filter'] = $filter;
		$data['self'] = $this->db->get_where('mst_organization' , array('organization' => $filter['organization']))->row();
		$data['parent'] = $this->db->get_where('mst_organization' , array('organization' => $data['self']->organization_parent))->row();
		$data['opt_status'] = array('' => '- Pilih Status -', 1 => 'Aktif', 2 => 'Non Aktif');
		$data['opt_class'] = array('direktorat-level' => 'Direktorat', 'org-level' => 'Divisi / Kanwil / Kanins');
		$this->load->view('konfigurasi/organization_setting', $data);
	}
	
	public function add_child_organization(){
		$data = array();
		$filter['organization'] = $this->input->get_post('organization');
		$data['parent'] = $this->db->get_where('mst_organization' , array('organization' => $filter['organization']))->row();
		if($this->input->post('save')){
			$this->form_validation->set_rules('organization_desc', 'Organization Desc.', 'trim|required');
			$this->form_validation->set_rules('organization_abr', 'Organization Abre.', 'trim|required');
			$this->form_validation->set_rules('organization_top_holder', 'Organization Top Holder', 'trim');
			$this->form_validation->set_rules('organization_class', 'Organization Class', 'trim|required');
			$this->form_validation->set_rules('status', 'Status Class', 'trim|required');
			
			if($this->form_validation->run()==TRUE){
				$top_holder = $this->input->post('organization_top_holder');
				$arr_pekerja = explode('/', $top_holder);
				$pernr = $this->libs->correctDigit(8,$arr_pekerja[0]);
				$param[] = $this->libs->arrWhere('AND','PERNR',$pernr);
				$pekerja = $this->general_model->mysql_get_data_with_connection(false,'portalsdm','pa0001_eof','',$param,'PERNR ASC',0,1);
				if(count($pekerja)>0 || $top_holder == ''){
					if($top_holder == '')
						$pernr = 'none';
					
					$org = $this->db->get_where('mst_organization' , array('organization_desc' => $this->input->post('organization_desc')))->row();
					
					if(!isset($org->organization)){
						$new_org = $this->talent_model->get_new_org($data['parent']->organization_area);
						$data_ = array(
							'organization' => $new_org,
							'organization_desc' => $this->input->post('organization_desc'),
							'organization_abr' => $this->input->post('organization_abr'),
							'organization_level' => isset($data['parent']->organization_level)?($data['parent']->organization_level+1):0,
							'organization_area' => isset($data['parent']->organization_area)?($data['parent']->organization_area):'',
							'organization_class' => $this->input->post('organization_class'),
							'organization_parent' => isset($data['parent']->organization)?($data['parent']->organization):'',
							'status' => $this->input->post('status'),
							'organization_top_holder' => $pernr,
							'severity_level' => 0,
							'last_updated' => date('Y-m-d H:i:s'),
							'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
						);
						$arr_input = $this->konfigurasi_model->insert_organization($data_);
						if($arr_input['status']){
							$this->auditrail_model->add_log('Konfigurasi', 'Add Organization');
							$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
							unset($_POST);
						}else{
							$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
						}
					}
					else{
						$data['message'] = $this->libs->generate_message('danger','Data struktur organisasi sudah ada.');
					}
				}else{
					$data['message'] = $this->libs->generate_message('danger','Personal number yang Anda masukkan tidak valid.');
				}
				
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}
		$data['filter'] = $filter;
		$data['opt_status'] = array('' => '- Pilih Status -', 1 => 'Aktif', 2 => 'Non Aktif');
		
		if($data['parent']->organization_level <= 1 && $data['parent']->organization_area == 'KP')
			$data['opt_class'] = array('' => '- Pilih Organization Class -', 'direktorat-level' => 'Direktorat', 'org-level' => 'Divisi / Kanwil / Kanins');
		else
			$data['opt_class'] = array('' => '- Pilih Organization Class -', 'org-level' => 'Divisi / Kanwil / Kanins');
		$this->load->view('konfigurasi/add_child_organization', $data);
	}
	
	public function move_organization(){
		$data = array();
		$filter['organization'] = $this->input->get_post('organization');
		
		if($this->input->post('save')){
			$this->form_validation->set_rules('organization_parent', 'Organization Parent Dest.', 'trim|required');
			if($this->form_validation->run()==TRUE){
				$organization_parent = $this->input->post('organization_parent');
				$arr_org = explode('-', $organization_parent);
				
				$org = $this->db->get_where('mst_organization' , array('organization' => trim($arr_org[0])))->row();
				
				if(isset($org->organization)){
					$data_ = array(
						'organization_parent' => $org->organization,
						'last_updated' => date('Y-m-d H:i:s'),
						'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
					);
					$arr_input = $this->konfigurasi_model->update_organization($data_, $filter['organization']);
					if($arr_input['status']){
						$this->auditrail_model->add_log('Konfigurasi', 'Move Organization');
						$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
						unset($_POST);
					}else{
						$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
					}
				}
				else{
					$data['message'] = $this->libs->generate_message('danger','Organization Parent New tidak valid');
				}
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}
		$data['filter'] = $filter;
		$data['self'] = $this->db->get_where('mst_organization' , array('organization' => $filter['organization']))->row();
		$data['parent'] = $this->db->get_where('mst_organization' , array('organization' => $data['self']->organization_parent))->row();
		$this->load->view('konfigurasi/move_organization', $data);
	}
	
	public function auto_organization()
	{
		$term = trim($this->input->get_post('term'));
		$org = $this->talent_model->get_auto_organization($term);
		if(count($org)>0){
			foreach($org as $idx=>$row){
				$data[$idx] =  array('id'=>$row->organization, 'value'=> $row->organization ." - ". $row->organization_desc);
			}
		}else{
			$data = array(0=>array('id'=>'','value'=>'- data tidak ditemukan -'));
		}
		echo json_encode($data);
	}
	
	public function auto_organization_parent()
	{
		$term = trim($this->input->get_post('term'));
		$org = $this->talent_model->get_auto_organization_parent($term);
		if(count($org)>0){
			foreach($org as $idx=>$row){
				$data[$idx] =  array('id'=>$row->organization, 'value'=> $row->organization ." - ". $row->organization_desc);
			}
		}else{
			$data = array(0=>array('id'=>'','value'=>'- data tidak ditemukan -'));
		}
		echo json_encode($data);
	}
	
	public function filter_hasil_asesmen(){
		$data = array(
			'opt_category' => $this->option_model->opt_category(),
			'opt_corp_title' => $this->option_model->opt_corp_title(),
			'opt_rekomendasi' => $this->option_model->opt_rekomendasi()
        );
		$data['result'] = $this->hasil_asesmen(true);
		$this->load->view('konfigurasi/filter_hasil_asesmen', $data);
	}
	
	public function hasil_asesmen($string=false)
	{
		$filter['f_category'] = trim($this->input->post('f_category'));
		$filter['f_corp_title'] = trim($this->input->post('f_corp_title'));
		$filter['f_rekomendasi'] = trim($this->input->post('f_rekomendasi'));
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();

		if($filter['f_category']!=''){
			$param[] = $this->libs->arrWhere('AND','method',"{$filter['f_category']}",'1','=');
		}
		
		if($filter['f_corp_title']!=''){
			$param[] = $this->libs->arrWhere('AND','corp_title',"{$filter['f_corp_title']}",'1','=');
		}
		
		if($filter['f_rekomendasi']!=''){
			$param[] = $this->libs->arrWhere('AND','rekomendasi',"{$filter['f_rekomendasi']}",'1','=');
		}
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.pernr',"%{$filter['f_keyword']}%",'1','LIKE');
				$param[] = $this->libs->arrWhere('OR','a.nama',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/hasil_asesmen/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_mst_hasil_asesmen(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['asesmen'] = $this->konfigurasi_model->get_mst_hasil_asesmen(false,$param,'a.pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('konfigurasi/hasil_asesmen',$data,true); 
		}else{
			$this->load->view('konfigurasi/hasil_asesmen',$data);
		}
	}
	
	public function add_hasil_asesmen(){
		$data = array();
		if($this->input->post('save')){
			$this->form_validation->set_rules('pernr', 'Pekerja', 'trim|required');
			$this->form_validation->set_rules('corp_title', 'Corp. Title', 'trim|required');
			$this->form_validation->set_rules('category', 'Category', 'trim|required');
			$this->form_validation->set_rules('rekomendasi', 'Rekomendasi', 'trim|required');
			$this->form_validation->set_rules('ratas', 'Ratas', 'trim|is_numeric');
			$this->form_validation->set_rules('expertise', 'Expertise', 'required');
			
			if($this->form_validation->run()==TRUE){
				$arr_pekerja = explode('/', $this->input->post('pernr'));
				$pernr = $this->libs->correctDigit(8,$arr_pekerja[0]);
				$param[] = $this->libs->arrWhere('AND','PERNR',$pernr);
				$pekerja = $this->general_model->mysql_get_data_with_connection(false,'portalsdm','pa0001_eof','',$param,'PERNR ASC',0,1);
				
				if(count($pekerja)>0){
					
					$hasil = $this->db->get_where('mst_hasil_assessment' , array('pernr' => $this->input->post('pernr'), 'method' => $this->input->post('category')))->row();
					
					if(!isset($hasil->pernr)){
						$arr_exp = array_unique($this->input->post('kode_expertise'));
						$data_ = array(
							'pernr' => isset($pekerja[0]->PERNR)?$pekerja[0]->PERNR:'',
							'nama' => isset($pekerja[0]->SNAME)?$pekerja[0]->SNAME:'',
							'corp_title' => $this->input->post('corp_title'),
							'method' => $this->input->post('category'),
							'rekomendasi' => $this->input->post('rekomendasi'),
							'ratas_kompetensi' => $this->input->post('ratas'),
							'last_updated' => date('Y-m-d H:i:s'),
							'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
						);
						$arr_input = $this->konfigurasi_model->insert_hasil_asesmen($data_, $arr_exp);
						if($arr_input['status']){
							$this->auditrail_model->add_log('Konfigurasi', 'Insert Hasil Assessment');
							$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
							unset($_POST);
						}else{
							$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
						}
					}
					else{
						$data['message'] = $this->libs->generate_message('danger','Data hasil assessment pekerja sudah ada.');
					}
				}else{
					$data['message'] = $this->libs->generate_message('danger','Personal number yang Anda masukkan tidak valid.');
				}
				
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}
		
		$data['opt_category'] = $this->option_model->opt_category();
		$data['opt_corp_title'] = $this->option_model->opt_corp_title();
		$data['opt_rekomendasi'] = $this->option_model->opt_rekomendasi();
		
		$this->load->view('konfigurasi/form_add_hasil_asesmen', $data);
	}
	
	public function auto_expertise()
	{
		$term = trim($this->input->get_post('term'));
		$exp = $this->talent_model->get_auto_expertise($term);
		if(count($exp)>0){
			foreach($exp as $idx=>$row){
				$data[$idx] =  array('id'=>$row->expertise, 'value'=> $row->expertise ." - ". $row->expertise_desc);
			}
		}else{
			$data = array(0=>array('id'=>'','value'=>'- data tidak ditemukan -'));
		}
		echo json_encode($data);
	}
	
	public function ubah_hasil_asesmen(){
		$data = array();
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['method'] = $this->input->get_post('method');
		if($this->input->post('save')){
			$this->form_validation->set_rules('corp_title', 'Corp. Title', 'trim|required');
			$this->form_validation->set_rules('rekomendasi', 'Rekomendasi', 'trim|required');
			$this->form_validation->set_rules('ratas', 'Ratas', 'trim|is_numeric');
			$this->form_validation->set_rules('expertise', 'Expertise', 'required');
			
			if($this->form_validation->run()==TRUE){
				$pernr = $filter['pernr'];
				$hasil = $this->db->get_where('mst_hasil_assessment' , array('pernr' => $this->input->post('pernr'), 'method' => $this->input->post('method')))->row();
				
				if(isset($hasil->pernr)){
					$arr_exp = array_unique($this->input->post('kode_expertise'));
					$data_ = array(
						'corp_title' => $this->input->post('corp_title'),
						'rekomendasi' => $this->input->post('rekomendasi'),
						'ratas_kompetensi' => $this->input->post('ratas'),
						'last_updated' => date('Y-m-d H:i:s'),
						'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
					);
					$arr_input = $this->konfigurasi_model->update_hasil_asesmen($data_, $arr_exp, $filter);
					if($arr_input['status']){
						$this->auditrail_model->add_log('Konfigurasi', 'Ubah Hasil Assessment');
						$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
						unset($_POST);
					}else{
						$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
					}
				}
				else{
					$data['message'] = $this->libs->generate_message('danger','Data hasil assessment pekerja tidak detemukan.');
				}
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}
		
		$data['opt_category'] = $this->option_model->opt_category();
		$data['opt_corp_title'] = $this->option_model->opt_corp_title();
		$data['opt_rekomendasi'] = $this->option_model->opt_rekomendasi();
		$data['param'] = $filter;
		$data['asesmen'] = $this->db->get_where('mst_hasil_assessment', array('pernr' => $filter['pernr'], 'method' => $filter['method']))->row();
		$data['expertise'] = $this->talent_model->get_expertise($filter['pernr']);
		$this->load->view('konfigurasi/form_update_hasil_asesmen', $data);
	}
	
	public function delete_hasil_asesmen()
	{
		if($this->input->post('delete')){
			$this->form_validation->set_rules('pernr', 'PERNR', 'trim|required');
			if($this->form_validation->run()==TRUE){
				$this->auditrail_model->add_log('Konfigurasi', 'Delete Hasil Assessment');
				if($this->konfigurasi_model->delete_hasil_asesmen($this->input->post('pernr'), $this->input->post('method'))){
					$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('success','Data berhasil dihapus.');
				}else{
					$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('danger','Data gagal dihapus.');
				}
			}else{
				$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('danger','Parameter tidak valid.');
			}
		}
		$this->hasil_asesmen(false);
	}
	
	public function filter_keyjobs(){
		$data = array(
			'opt_flightrisk' => $this->option_model->opt_flightrisk(),
			'opt_jobgrade' => $this->option_model->opt_jobgrade(),
			'opt_status' => $this->option_model->opt_status()
        );
		$data['result'] = $this->keyjobs(true);
		$this->load->view('konfigurasi/filter_keyjobs', $data);
	}
	
	public function keyjobs($string=false)
	{
		$filter['f_flightrisk'] = trim($this->input->post('f_flightrisk'));
		$filter['f_jobgrade'] = trim($this->input->post('f_jobgrade'));
		$filter['f_status'] = trim($this->input->post('f_status'));
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();

		if($filter['f_flightrisk']!=''){
			$param[] = $this->libs->arrWhere('AND','a.flight_risk',"{$filter['f_flightrisk']}",'1','=');
		}
		
		if($filter['f_jobgrade']!=''){
			$param[] = $this->libs->arrWhere('AND','a.jobgrade',"{$filter['f_jobgrade']}",'1','=');
		}
		
		if($filter['f_status']!=''){
			$param[] = $this->libs->arrWhere('AND','a.status',"{$filter['f_status']}",'1','=');
		}
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.keyjobs_desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.keyjobs',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.organization',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.organization_desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.organization_abr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.sname',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/keyjobs/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_mst_keyjobs(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['keyjobs'] = $this->konfigurasi_model->get_mst_keyjobs(false,$param,'a.keyjobs, a.organization',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('konfigurasi/keyjobs',$data,true); 
		}else{
			$this->load->view('konfigurasi/keyjobs',$data);
		}
	}
	
	public function add_keyjobs(){
		$data = array();
		if($this->input->post('save')){
			$this->form_validation->set_rules('keyjobs_desc', 'Keyjobs Desc.', 'trim|required');
			$this->form_validation->set_rules('jobgrade', 'Jobgrade', 'trim|required');
			$this->form_validation->set_rules('organization', 'Organization', 'trim|required');
			$this->form_validation->set_rules('flightrisk', 'Flight Risk', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			$this->form_validation->set_rules('jf', 'Job Family', 'required');
			$this->form_validation->set_rules('jt', 'Job Technicality', 'required');
			
			if($this->form_validation->run()==TRUE){
				
				$arr_org = explode('-', $this->input->post('organization'));
				$org = $this->db->get_where('mst_organization' , array('organization' => trim($arr_org[0])))->row();
				
				if(isset($org->organization)){
					$job_holder = $this->input->post('jobholder');
					$arr_pekerja = explode('/', $this->input->post('jobholder'));
					$pernr = $this->libs->correctDigit(8,$arr_pekerja[0]);
					$param[] = $this->libs->arrWhere('AND','PERNR',$pernr);
					$pekerja = $this->general_model->mysql_get_data_with_connection(false,'portalsdm','pa0001_eof','',$param,'PERNR ASC',0,1);
					
					if(count($pekerja)>0 || $job_holder == ''){
						$hasil = $this->db->get_where('mst_keyjobs' , array('jobholder' => $pernr, 'status' => 1))->row();
						if(!isset($hasil->jobholder) || $job_holder == ''){
								if($job_holder == '')
									$pernr = '';
								
								$new_keyjobs = $this->talent_model->get_new_keyjobs();
								$arr_jt = array_unique($this->input->post('kode_jf'));
								$arr_jf = array_unique($this->input->post('kode_jt'));
								$arr_talent_class = array_unique($this->input->post('talent_class'));
								$arr_readiness = array_unique($this->input->post('readiness'));
								$data_ = array(
									'keyjobs' => $new_keyjobs,
									'organization' => $org->organization,
									'jobholder' => $pernr,
									'jobgrade' => $this->input->post('jobgrade'),
									'flight_risk' => $this->input->post('flightrisk'),
									'keyjobs_desc' => $this->input->post('keyjobs_desc'),
									'successors' => 0,
									'status' => $this->input->post('status'),
									'last_updated' => date('Y-m-d H:i:s'),
									'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
								);
								$arr_input = $this->konfigurasi_model->insert_keyjobs($data_, $arr_jt, $arr_jf, $arr_talent_class, $arr_readiness);
								if($arr_input['status']){
									$this->auditrail_model->add_log('Konfigurasi', 'Insert Keyjobs');
									$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
									unset($_POST);
								}else{
									$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
								}
						}
						else{
							$data['message'] = $this->libs->generate_message('danger','Data job holder sudah ada.');
						}
					}else{
						$data['message'] = $this->libs->generate_message('danger','Personal number yang Anda masukkan tidak valid.');
					}
				}
				else{
					$data['message'] = $this->libs->generate_message('danger','Organization yang Anda masukkan tidak valid.');
				}
				
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}

		$data['opt_flightrisk'] = $this->option_model->opt_flightrisk();
		$data['opt_jobgrade'] = $this->option_model->opt_jobgrade();
		$data['opt_status'] = $this->option_model->opt_status();
		$data['opt_hav'] = $this->option_model->opt_hav();
		$data['opt_readiness'] = $this->option_model->opt_readiness();

		$this->load->view('konfigurasi/form_add_keyjobs', $data);
	}
	
	public function ubah_keyjobs(){
		$data = array();
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		if($this->input->post('save')){
			$this->form_validation->set_rules('jobgrade', 'Jobgrade', 'trim|required');
			$this->form_validation->set_rules('flightrisk', 'Flight Risk', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			$this->form_validation->set_rules('jf', 'Job Family', 'required');
			$this->form_validation->set_rules('jt', 'Job Technicality', 'required');
			
			if($this->form_validation->run()==TRUE){
				
				//$arr_org = explode('-', $this->input->post('organization'));
				//$org = $this->db->get_where('mst_organization' , array('organization' => trim($arr_org[0])))->row();
				
				//if(isset($org->organization)){
					$job_holder = $this->input->post('jobholder');
					$arr_pekerja = explode('/', $this->input->post('jobholder'));
					$pernr = $this->libs->correctDigit(8,$arr_pekerja[0]);
					$param[] = $this->libs->arrWhere('AND','PERNR',$pernr);
					$pekerja = $this->general_model->mysql_get_data_with_connection(false,'portalsdm','pa0001_eof','',$param,'PERNR ASC',0,1);
					
					if(count($pekerja)>0 || $job_holder == ''){
						$hasil = $this->db->get_where('mst_keyjobs' , array('jobholder' => $pernr, 'status' => 1, 'keyjobs <>' => $filter['keyjobs']))->row();
						if(!isset($hasil->jobholder) || $job_holder == ''){
								if($job_holder == '')
									$pernr = '';
								
								$arr_jt = array_unique($this->input->post('kode_jf'));
								$arr_jf = array_unique($this->input->post('kode_jt'));
								$arr_talent_class = array_unique($this->input->post('talent_class'));
								$arr_readiness = array_unique($this->input->post('readiness'));
								$data_ = array(
									'jobholder' => $pernr,
									'jobgrade' => $this->input->post('jobgrade'),
									'flight_risk' => $this->input->post('flightrisk'),
									'keyjobs_desc' => $this->input->post('keyjobs_desc'),
									'status' => $this->input->post('status'),
									'last_updated' => date('Y-m-d H:i:s'),
									'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
								);
								$arr_input = $this->konfigurasi_model->update_keyjobs($data_, $arr_jt, $arr_jf, $filter, $arr_talent_class, $arr_readiness);
								if($arr_input['status']){
									$this->auditrail_model->add_log('Konfigurasi', 'Update Keyjobs');
									$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
									unset($_POST);
								}else{
									$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
								}
						}
						else{
							$data['message'] = $this->libs->generate_message('danger','Data job holder sudah ada.');
						}
					}else{
						$data['message'] = $this->libs->generate_message('danger','Personal number yang Anda masukkan tidak valid.');
					}
				//}
				//else{
				//	$data['message'] = $this->libs->generate_message('danger','Organization yang Anda masukkan tidak valid.');
				//}
				
			}else{
				$data['message'] = $this->libs->generate_message('danger','Terdapat beberapa kesalahan dalam mengisi data.');
			}
		}

		$data['opt_flightrisk'] = $this->option_model->opt_flightrisk();
		$data['opt_jobgrade'] = $this->option_model->opt_jobgrade();
		$data['opt_status'] = $this->option_model->opt_status();
		$data['opt_hav'] = $this->option_model->opt_hav();
		$data['opt_readiness'] = $this->option_model->opt_readiness();
		$data['param'] = $filter;
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs a inner join mst_organization b on a.organization = b.organization', array('keyjobs' => $filter['keyjobs']))->row();
		$data['jobfamily'] = $this->talent_model->get_jobfamily($filter['keyjobs']);
		$data['jobtechnicality'] = $this->talent_model->get_jobtechnicality($filter['keyjobs']);
		$data['selected_talent_class'] = $this->talent_model->get_talent_class($filter['keyjobs']);
		$data['selected_readiness'] = $this->talent_model->get_readiness($filter['keyjobs']);
		$this->load->view('konfigurasi/form_update_keyjobs', $data);
	}
	
	public function analyse_keyjobs(){
		$data = array();
		$data['orgeh'] = $this->input->get_post('orgeh');
		$data['hilfm'] = $this->input->get_post('hilfm');
		$data['corp_title_id'] = $this->input->get_post('corp_title_id');
		$this->load->view('konfigurasi/analyse_keyjobs', $data);
	}
	
	public function analyse_hav_matrix(){
		$data = array();
		$this->load->view('konfigurasi/analyse_hav_matrix', $data);
	}
	
	public function run_analyse()
	{ 
	    $id_process = $this->input->get_post('id_process');
		$is_process_done = $this->konfigurasi_model->check_process_analyze($id_process);
		
		if($is_process_done){
			if($id_process == 2){
				$orgeh = $this->input->get_post('orgeh');
				$hilfm = $this->input->get_post('hilfm');
				$corp_title_id = $this->input->get_post('corp_title_id');
				$param = array( 
					'token' => $_SESSION[$this->config->item('session_prefix')]['token'],
					'orgeh' => $orgeh,
					'hilfm' => $hilfm,
					'corp_title_id' => $corp_title_id,
					'searched_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'],
					'date_modified' => date('Y-m-d H:i:s')
				);
				
	  			$set_param = $this->konfigurasi_model->set_parameter($param);
			}

			set_include_path(get_include_path().PATH_SEPARATOR.APPPATH.'third_party/phpseclib');

			include(APPPATH.'/third_party/phpseclib/Net/SSH2.php');

			$ssh = new Net_SSH2('10.35.65.113');

			if (!$ssh->login('bripsb', 'P@ssw0rd113')) {
				exit('Login Failed');
			}

			$ssh->write("sudo -s\n");
			$ssh->write("P@ssw0rd113\n");
			  
			if($id_process == 1)
				$ssh->exec("/usr/local/java/sh/generate_hav_matrix_brihc.sh >> /home/administrator/backup_log/generate_hav_matrix_brihc.log &");
			else if($id_process == 2)
				$ssh->exec("/usr/local/java/sh/generate_succession_plan_brihc.sh >> /home/administrator/backup_log/generate_succession_plan_brihc.log &");

			sleep(1);
			
			$analyze = 'Succession Plan';
			if($id_process == 1)
				$analyze = 'HAV Matrix';

			$this->auditrail_model->add_log('Pencarian', 'Analyze ' . $analyze);            
			$process_log   = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM talent_pencarian_processlog where id_process =  {$id_process} LIMIT 0,1");
			//$error_log     = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_errorlogs LIMIT 0,1");

			$today = date('Y-m-d H:i:s');
			$data['now'] = $today;
			$date_start = new DateTime($process_log->row()->start);
				 
			if($process_log->row()->text == 'Process DONE!' && $process_log->row()->id_process == $id_process) 
			{
				$date_end = new DateTime($process_log->row()->end);
				$diff = date_diff($date_end, $date_start);
			} 
			else 
			{
				$date_now = new DateTime($today);   
				$diff = date_diff($date_now, $date_start);
			}
				 
			$elapse = $diff->format('%H:%I:%S');
			 
			if(count($process_log->row()) > 0){
				$progress_text = $process_log->row()->text;
				$mst_progress  = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM talent_pencarian_progress WHERE id_process =  {$id_process} AND progress LIKE '%{$progress_text}%' LIMIT 0,1");

				$arrProgress = array('progress_text' => $progress_text,
									  'prosentase'    => $mst_progress->row()->prosentase,
									  'start_process' => $process_log->row()->start,
									  'end_process'   => $process_log->row()->end,
									  'elapse_time'   => $elapse,
									  'error_log'     => '');
			}
			else{
				$arrProgress = array('progress_text' => '',
									  'prosentase'    => 100,
									  'start_process' => '',
									  'end_process'   => '',
									  'elapse_time'   => $elapse,
									  'error_log'     => '');
			}
		}
		else{
			$elapse = 0;
			$arrProgress = array('progress_text' => '',
								  'prosentase'    => 100,
								  'start_process' => '',
								  'end_process'   => '',
								  'elapse_time'   => $elapse,
								  'error_log'     => '1',
								  'error_msg'	  => 'Analyse Process Already Run.');
		}
			 
		echo json_encode($arrProgress);
	}
   
	public function analyze_progress_refresh()
	{
		$id_process = $this->input->post('id_process');
		$process_log   = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM talent_pencarian_processlog where id_process =  {$id_process} LIMIT 0,1");
      //$error_log     = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_errorlogs LIMIT 0,1");

		$today = date('Y-m-d H:i:s');
		$data['now'] = $today;
		$date_start = new DateTime($process_log->row()->start);
         
		if($process_log->row()->text == 'Process DONE!' && $process_log->row()->id_process == $id_process) 
        {
			$date_end = new DateTime($process_log->row()->end);
			$diff = date_diff($date_end, $date_start);
		} 
		else 
        {
			$date_now = new DateTime($today);   
			$diff = date_diff($date_now, $date_start);
        }
         
		$elapse = $diff->format('%H:%I:%S');
        if(count($process_log->row()) > 0) 
        {
			$progress_text = $process_log->row()->text;
            $mst_progress  = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM talent_pencarian_progress WHERE id_process =  {$id_process} AND progress LIKE '%{$progress_text}%' LIMIT 0,1");

            $arrProgress = array('progress_text' => $progress_text,
                                 'prosentase'    => $mst_progress->row()->prosentase,
                                 'start_process' => $process_log->row()->start,
                                 'end_process'   => $process_log->row()->end,
                                 'elapse_time'   => $elapse,
                                 'error_log'     => '');
        }
         else
        {
            $arrProgress = array('progress_text' => '',
                                 'prosentase'    => 100,
                                 'start_process' => '',
                                 'end_process'   => '',
                                 'elapse_time'   => $elapse,
                                 'error_log'     => '');
        }

         echo json_encode($arrProgress);
	}

	public function filter_param_keyjobs(){
		$keyjobs = $this->input->get_post('keyjobs');
		$data['opt_mk_jabatan_uker'] 	= $this->option_model->opt_mk_jabatan_uker();
   		$data['opt_mk_jg_pg'] 			= $this->option_model->opt_mk_jg_pg();
   		$data['opt_jabatan'] 			= $this->option_model->opt_jabatan();
		$data['opt_program_masuk'] 		= $this->option_model->opt_program_masuk();
        $data['opt_job_grade']        	= $this->option_model->opt_job_grade();
        $data['opt_person_grade']     	= $this->option_model->opt_person_grade();
        $data['opt_agama']            	= $this->option_model->opt_agama();
        $data['opt_rekomendasi_asesmen']    = $this->option_model->opt_rekomendasi_asesmen();
        $data['opt_jenis_klaim']            = $this->option_model->opt_jenis_klaim();
        $data['opt_insus']            		= $this->option_model->opt_get_insus();
		$data['id_template'] = 0;
		$data['template'] = $this->konfigurasi_model->get_template_keyjobs($keyjobs);
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs a inner join mst_organization b on a.organization = b.organization', array('keyjobs' => $keyjobs))->row();
		if(isset($data['template']->t_text)){
			$id = isset($data['template']->id)?$data['template']->id:'';
			$data['id_template'] = $id;
			$data['filter'] = $this->template_model->get_template_filter($id);
			if(count($data['filter']) > 0){
				$data['status_template'] = 'update';
			}
			else{
				$data['status_template'] = 'insert';
				//$data['message'] = $this->libs->generate_message('danger','Filter Tidak Ditemukan.');
			}
		}
		else{
			$data['status_template'] = 'insert';
			//$data['message'] = $this->libs->generate_message('danger','Filter Tidak Ditemukan.');
		}
		
   		$this->load->view('konfigurasi/filter_param_keyjobs',$data);
   }

   public function simpan_filter_pencarian_keyjobs(){
	   	$data = array();
		$param = $this->generate_template();
		$id_template = $this->input->post('id_template');
		$keyjobs = $this->input->post('keyjobs');
		$keyjobs_desc = $this->input->post('keyjobs_desc');
		$org_desc = $this->input->post('org_desc');
		$status_template = $this->input->post('status_template');
		if($status_template == 'insert' && $id_template == 0){
			$param_tree = array(
				't_text' => $keyjobs_desc . ' (' . $org_desc.  ')',
				'level' => $this->config->item('master_keyjobs_level'),
				'parent' => $this->config->item('master_keyjobs_parent'),
				'status' => 1,
				'is_search' => 0,
				'area' => $_SESSION[$this->config->item('session_prefix')]['pa'],	
				'subarea' => $_SESSION[$this->config->item('session_prefix')]['psa'],
				'tipe_uker' => $_SESSION[$this->config->item('session_prefix')]['tipe_uker'],
				'periode' => date('m') . date('Y'),
				'keyjobs' => $keyjobs,
				'last_updated' => date('Y-m-d H:i:s'),
				'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			);
			$param_search = array(	
							'id_key'	=> '1',
							'key_search' 		=> $param['ALLArray'],
							'last_updated' 		=> date('Y-m-d H:i:s'),
							'updated_by' 		=> $_SESSION[$this->config->item('session_prefix')]['pernr'].'|'.$_SESSION[$this->config->item('session_prefix')]['nama'].'|'.$_SESSION[$this->config->item('session_prefix')]['stell_tx'],
							'token'           	=> $_SESSION[$this->config->item('session_prefix')]['token']);
		
			$proses = $this->konfigurasi_model->insert_filter_pencarian_keyjobs($param_tree, $param_search);
		}
		else{
			$param_tree = array(
				't_text' => $keyjobs_desc . ' (' . $org_desc.  ')',
				'last_updated' => date('Y-m-d H:i:s'),
				'updated_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'] . '|' . $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			);
			$param_search = array(	'id_key'	=> '1',
							'key_search' 		=> $param['ALLArray'],
							'last_updated' 		=> date('Y-m-d H:i:s'),
							'updated_by' 		=> $_SESSION[$this->config->item('session_prefix')]['pernr'].'|'.$_SESSION[$this->config->item('session_prefix')]['nama'].'|'.$_SESSION[$this->config->item('session_prefix')]['stell_tx'],
							'token'           	=> $_SESSION[$this->config->item('session_prefix')]['token']);
		
			$proses = $this->konfigurasi_model->update_filter_pencarian_keyjobs($param_tree, $param_search, $id_template);
		}	
		if($proses['status']){
			$this->auditrail_model->add_log('Simpan Filter Keyjobs', 'Melakukan Simpan Filter Keyjobs = ' . $keyjobs);
			$message = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$message = $this->libs->generate_message('danger',$proses['message']);
		}

		$data = array(
			'opt_flightrisk' => $this->option_model->opt_flightrisk(),
			'opt_jobgrade' => $this->option_model->opt_jobgrade(),
			'opt_status' => $this->option_model->opt_status(),
			'message' => $message
        );
		$data['result'] = $this->keyjobs(true);
		$this->load->view('konfigurasi/filter_keyjobs', $data);
	}

	public function generate_template(){
		// Data Utama SDM
		$data['f_pernr'] 			     = $this->input->post('f_pernr');
		$data['f_pa']                = $this->input->post('f_pa');
		$data['f_psa']               = $this->input->post('f_psa');
		$data['f_jenis_kelamin'] 	  = $this->input->post('f_jenis_kelamin');
		$data['f_jg_min']            = $this->input->post('f_jg_min');
		$data['f_jg_max']            = $this->input->post('f_jg_max');
		$data['f_pg_min']            = $this->input->post('f_pg_min');
		$data['f_pg_max']            = $this->input->post('f_pg_max');
		$data['f_usia_min'] 			  = $this->input->post('f_usia_min');
		$data['f_usia_max']          = $this->input->post('f_usia_max');
		$data['f_agama'] 			     = $this->input->post('f_agama');
		$data['f_jabatan'] 			  = $this->input->post('f_jabatan');
		$data['f_program_masuk']     = $this->input->post('f_program_masuk');
		$data['f_mk_jabatan'] 		  = $this->input->post('f_mk_jabatan');
		$data['f_mk_jg'] 			     = $this->input->post('f_mk_jg');
		$data['f_mk_pg'] 			     = $this->input->post('f_mk_pg');
		$data['f_mk_uker'] 			  = $this->input->post('f_mk_uker');

	// Data Pendidikan
		$data['f_universitas']     = $this->input->post('f_universitas');
		$data['f_jurusan']         = $this->input->post('f_jurusan');
		$data['f_ipk_min']         = $this->input->post('f_ipk_min');
		$data['f_ipk_max']         = $this->input->post('f_ipk_max');
		$data['f_training']        = $this->input->post('f_training');


	// Data Pengembangan Karir
		$data['f_histori_jabatan'] = $this->input->post('f_histori_jabatan');
		$data['f_histori_uker']    = $this->input->post('f_histori_uker');

	// Data Alamat
		$data['f_homebase'] = $this->input->post('f_homebase');
		$data['f_domisili'] = $this->input->post('f_domisili');
		
		// Data Assessment
		$data['f_rekomendasi_asesmen'] = $this->input->post('f_rekomendasi_asesmen');
		$data['f_judul_assesment'] = $this->input->post('f_judul_assesment');
		
		// Data SMK
		$data['f_sko_min']            = $this->input->post('f_sko_min');
		$data['f_sko_max']            = $this->input->post('f_sko_max');
		$data['f_skk_min']            = $this->input->post('f_skk_min');
		$data['f_skk_max']            = $this->input->post('f_skk_max');
		$data['f_smk_min']            = $this->input->post('f_smk_min');
		$data['f_smk_max']            = $this->input->post('f_smk_max');
		$data['f_tahun_smk']            = $this->input->post('f_tahun_smk');
		
		// Data Kesehatan
		$data['f_jenis_klaim'] = $this->input->post('f_jenis_klaim');
		
	// Data ITP
			$data['f_itp_min']            = $this->input->post('f_itp_min');
			$data['f_itp_max']            = $this->input->post('f_itp_max');
			
		// Data Insus
		$data['f_insus']            = $this->input->post('f_insus');
		
		$ALLArray = array();
		$SDMArray = array();
		$PendidikanArray = array();
		$KarirArray = array();
		$AlamatArray = array();
		$AsesmenArray = array();
		$SMKArray = array();
		$KesehatanArray = array();
		$ITPArray = array();
		$HBIArray = array();

		if($data['f_pernr']!='')
			{
			$enter   = nl2br($data['f_pernr']);
			$arr     = explode('<br />', $enter);
			$cln     = array();

			foreach ($arr as $row) 
			{
			$row = trim($row);

			if($row!='')
				{
				$cln[$row] = $this->db->escape($row);
				}  
			}

			if(count($cln) > 0)
			{
			$data['f_pernr']    = implode(',', $cln);
			}

			$val        = array('value' => $data['f_pernr']);
			$obj        = array('PERNR' => $val);
			$SDMArray   = array_merge($SDMArray, $obj);
			}

		if($data['f_pa']!='')
			{
			$enter   = nl2br($data['f_pa']);
			$arr     = explode('<br />', $enter);
			$cln     = array();

			foreach ($arr as $row) 
			{
			$row = trim($row);

			if($row!='')
				{
				$cln[$row] = $this->db->escape($row);
				}  
			}

			if(count($cln) > 0)
			{
			$data['f_pa']    = implode(',', $cln);
			}

			$val        = array('value' => $data['f_pa']);
			$obj        = array('PA'   => $val);
			$SDMArray   = array_merge($SDMArray, $obj);
			}

		// User App KW -> PA
		if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KW'){
			$val        = array('value' => $this->db->escape($_SESSION[$this->config->item('session_prefix')]['pa']));
			$obj        = array('PA'   => $val);
			$SDMArray   = array_merge($SDMArray, $obj);
		}
		
		if($data['f_psa']!='')
			{
			$enter   = nl2br($data['f_psa']);
			$arr     = explode('<br />', $enter);
			$cln     = array();

			foreach ($arr as $row) 
			{
			$row = trim($row);

			if($row!='')
				{
				$cln[$row] = $this->db->escape($row);
				}  
			}

			if(count($cln) > 0)
			{
			$data['f_psa']    = implode(',', $cln);
			}

			$val           = array('value'   => $data['f_psa']);
			$obj           = array('PSA'     => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}
		
		// User App KC, KN, SD -> PSA
		if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KC' || $_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KN' || 	$_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'SD'){
			$val           = array('value'   => $this->db->escape($_SESSION[$this->config->item('session_prefix')]['psa']));
			$obj           = array('PSA'     => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
		}

		if($data['f_jenis_kelamin']!='')
			{
			$val 	         = array('value'    => $this->db->escape($data['f_jenis_kelamin']));
			$obj 	         = array('JK' 	    => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_jg_min']!='')
			{
			$val           = array('value'    => $data['f_jg_min']);
			$obj           = array('JG_MIN'   => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_jg_max']!='')
			{
			$val           = array('value'    => $data['f_jg_max']);
			$obj           = array('JG_MAX'   => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_pg_min']!='')
			{
			$val           = array('value'    => $data['f_pg_min']);
			$obj           = array('PG_MIN'   => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_pg_max']!='')
			{
			$val           = array('value'    => $data['f_pg_max']);
			$obj           = array('PG_MAX'   => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_usia_min']!='')
			{
			$val 	         = array('value'      => $data['f_usia_min']);
			$obj 	         = array('USIA_MIN' 	=> $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_usia_max']!='')
			{
			$val           = array('value'      => $data['f_usia_max']);
			$obj           = array('USIA_MAX'   => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_agama']!='')
			{
			$val 	         = array('value'      => $data['f_agama']);
			$obj 	         = array('AGAMA'      => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_jabatan']!='')
			{
			$jabatan 	   = implode("','", $data['f_jabatan']);
			$jabatan  	   = "'".$jabatan."'";
			$val 		      = array('value'     => $jabatan);
			$obj 		      = array('HILFM'     => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_program_masuk']!='')
			{
			$prog          = implode("','", $data['f_program_masuk']);
			$prog          = "'".$prog."'";
			$val           = array('value'         => $prog);
			$obj           = array('PROGRAM_MASUK' => $val);
			$SDMArray      = array_merge($SDMArray, $obj);
			}

		if($data['f_mk_jabatan']!='')
			{
			$mk_jabatan    = implode("','", $data['f_mk_jabatan']);
			$mk_jabatan    = "'".$mk_jabatan."'";
			$val 		      = array('value' 		   => $mk_jabatan);
			$obj 		      = array('MK_JABATAN' 	=> $val);
			$SDMArray 	   = array_merge($SDMArray, $obj);
			}

		if($data['f_mk_jg']!='')
			{
			$mk_jg 		   = implode("','", $data['f_mk_jg']);
			$mk_jg 		   = "'".$mk_jg."'";
			$val 		      = array('value'        => $mk_jg);
			$obj 		      = array('MK_JG'        => $val);
			$SDMArray 	   = array_merge($SDMArray, $obj);
			}

		if($data['f_mk_pg']!='')
			{
			$mk_pg 		   = implode("','", $data['f_mk_pg']);
			$mk_pg 		   = "'".$mk_pg."'";
			$val 		      = array('value'     => $mk_pg);
			$obj 		      = array('MK_PG'     => $val);
			$SDMArray 	   = array_merge($SDMArray, $obj);
			}

		if($data['f_mk_uker']!='')
			{
			$mk_uker 	   = implode("','", $data['f_mk_uker']);
			$mk_uker 	   = "'".$mk_uker."'";
			$val 	   	   = array('value'     => $mk_uker);
			$obj 		      = array('MK_UKER'   => $val);
			$SDMArray 	   = array_merge($SDMArray, $obj);
			}

	// Filter Data Pendidikan
		if($data['f_universitas']!='')
			{
			$enter   = nl2br($data['f_universitas']);
			$arr     = explode('<br />', $enter);
			$cln     = array();

			foreach ($arr as $row) 
			{
			$row = trim($row);

			if($row!='')
				{
				$cln[$row] = $this->db->escape_str($row);
				}  
			}

			if(count($cln) > 0)
			{
			$data['f_universitas']    = implode(',', $cln);
			}

			$val        = array('value' => $data['f_universitas']);
			$obj        = array('UNIVERSITAS' => $val);
			$PendidikanArray   = array_merge($PendidikanArray, $obj);
			}



		if($data['f_jurusan']!='')
			{
			$enter   = nl2br($data['f_jurusan']);
			$arr     = explode('<br />', $enter);
			$cln     = array();

			foreach ($arr as $row) 
			{
			$row = trim($row);

			if($row!='')
				{
				$cln[$row] = $this->db->escape_str($row);
				}  
			}

			if(count($cln) > 0)
			{
			$data['f_jurusan']    = implode(',', $cln);
			}
			
			$val        = array('value' => $data['f_jurusan']);
			$obj        = array('JURUSAN' => $val);
			$PendidikanArray   = array_merge($PendidikanArray, $obj);
			}

		if($data['f_ipk_min']!='')
			{
			$val                  = array('value'    => $data['f_ipk_min']);
			$obj                  = array('IPK_MIN'   => $val);
			$PendidikanArray      = array_merge($PendidikanArray, $obj);
			}

		if($data['f_ipk_max']!='')
			{
			$val                  = array('value'    => $data['f_ipk_max']);
			$obj                  = array('IPK_MAX'   => $val);
			$PendidikanArray      = array_merge($PendidikanArray, $obj);
			}
			
		if($data['f_training']!='')
			{
			$enter   = nl2br($data['f_training']);
			$arr     = explode('<br />', $enter);
			$cln     = array();

			foreach ($arr as $row) 
			{
			$row = trim($row);

			if($row!='')
				{
				$cln[$row] = $this->db->escape_str($row);
				}  
			}

			if(count($cln) > 0)
			{
			$data['f_training']    = implode(',', $cln);
			}
			$val                  = array('value'    => $data['f_training']);
			$obj                  = array('TRAINING'   => $val);
			$PendidikanArray      = array_merge($PendidikanArray, $obj);
			}

		// Filter Pengembangan Karir
		if($data['f_histori_jabatan']!='')
		{
			$enter   = nl2br($data['f_histori_jabatan']);
			$arr     = explode('<br />', $enter);
			$cln     = array();

			foreach ($arr as $row) 
			{
			$row = trim($row);

			if($row!='')
				{
				$cln[$row] = $this->db->escape_str($row);
				}  
			}

			if(count($cln) > 0)
			{
			$data['f_histori_jabatan']    = implode(',', $cln);
			}

			$val        = array('value' => $data['f_histori_jabatan']);
			$obj        = array('HISTORI_JABATAN' => $val);
			$KarirArray    = array_merge($KarirArray, $obj);
			
		}

		if($data['f_histori_uker']!='')
		{
			$enter   = nl2br($data['f_histori_uker']);
			$arr     = explode('<br />', $enter);
			$cln     = array();

			foreach ($arr as $row) 
			{
			$row = trim($row);

			if($row!='')
				{
				$cln[$row] = $this->db->escape_str($row);
				}  
			}

			if(count($cln) > 0)
			{
			$data['f_histori_uker']    = implode(',', $cln);
			}

			$val        = array('value' => $data['f_histori_uker']);
			$obj        = array('HISTORI_UKER' => $val);
			$KarirArray    = array_merge($KarirArray, $obj);
		}


	// Filter Alamat
		if($data['f_homebase']!='')
				{
				$val           = array('value'     => $data['f_homebase']);
				$obj           = array('HOMEBASE'  => $val);
				$AlamatArray   = array_merge($AlamatArray, $obj);
				}

		if($data['f_domisili']!='')
				{
				$val           = array('value'     => $data['f_domisili']);
				$obj           = array('DOMISILI'  => $val);
				$AlamatArray   = array_merge($AlamatArray, $obj);
				}

			
		// Filter Assessment
		if($data['f_rekomendasi_asesmen']!='')
			{
			$prog          = implode("','", $data['f_rekomendasi_asesmen']);
			$prog          = "'".$prog."'";
			$val           = array('value'         => $prog);
			$obj           = array('REKOMENDASI' => $val);
			$AsesmenArray      = array_merge($AsesmenArray, $obj);
			}
			
		if($data['f_judul_assesment']!='')
			{
			$val 	         = array('value'    => $data['f_judul_assesment']);
			$obj 	         = array('JUDUL' 	    => $val);
			$AsesmenArray      = array_merge($AsesmenArray, $obj);
			}
			
		// Filter SMK
		if($data['f_sko_min']!='')
			{
			$val           = array('value'    => $data['f_sko_min']);
			$obj           = array('SKO_MIN'   => $val);
			$SMKArray      = array_merge($SMKArray, $obj);
			}
		if($data['f_sko_max']!='')
			{
			$val           = array('value'    => $data['f_sko_max']);
			$obj           = array('SKO_MAX'   => $val);
			$SMKArray      = array_merge($SMKArray, $obj);
			}
		if($data['f_skk_min']!='')
			{
			$val           = array('value'    => $data['f_skk_min']);
			$obj           = array('SKK_MIN'   => $val);
			$SMKArray      = array_merge($SMKArray, $obj);
			}
		if($data['f_skk_max']!='')
			{
			$val           = array('value'    => $data['f_skk_max']);
			$obj           = array('SKK_MAX'   => $val);
			$SMKArray      = array_merge($SMKArray, $obj);
			}
		if($data['f_smk_min']!='')
			{
			$val           = array('value'    => $data['f_smk_min']);
			$obj           = array('SMK_MIN'   => $val);
			$SMKArray      = array_merge($SMKArray, $obj);
			}
		if($data['f_smk_max']!='')
			{
			$val           = array('value'    => $data['f_smk_max']);
			$obj           = array('SMK_MAX'   => $val);
			$SMKArray      = array_merge($SMKArray, $obj);
			}
			if($data['f_tahun_smk']!='')
			{
			$val           = array('value'    => $data['f_tahun_smk']);
			$obj           = array('TAHUN_SMK'   => $val);
			$SMKArray      = array_merge($SMKArray, $obj);
			}
				
			//  Filter Kesehatan
		if($data['f_jenis_klaim']!='')
			{
			$prog          = implode("','", $data['f_jenis_klaim']);
			$prog          = "'".$prog."'";
			$val           = array('value'         => $prog);
			$obj           = array('JENIS_KLAIM' => $val);
			$KesehatanArray      = array_merge($KesehatanArray, $obj);
			}
				
		// Filter ITP 
		if($data['f_itp_min']!='')
		{
		$val           = array('value'    => $data['f_itp_min']);
		$obj           = array('ITP_MIN'   => $val);
		$ITPArray      = array_merge($ITPArray, $obj);
		}
		if($data['f_itp_max']!='')
		{
		$val           = array('value'    => $data['f_itp_max']);
		$obj           = array('ITP_MAX'   => $val);
		$ITPArray      = array_merge($ITPArray, $obj);
		}
		
		// Filter Insus
		if($data['f_insus']!='')
		{
		$prog          = implode("','", $data['f_insus']);
		$prog          = "'".$prog."'";
		$val           = array('value'         => $prog);
		$obj           = array('INSUS' => $val);
		$HBIArray      = array_merge($HBIArray, $obj);
		}
				
				
		if(!empty($SDMArray))
			{
			$SDMObj 		   = array('SDM' => $SDMArray);
			$ALLArray 		= array_merge($ALLArray,$SDMObj);	
			}

		if(!empty($PendidikanArray))
			{
			$PendidikanObj = array('PENDIDIKAN' => $PendidikanArray);
			$ALLArray      = array_merge($ALLArray,$PendidikanObj);   
			}

		if(!empty($KarirArray))
			{
			$KarirObj      = array('MUTASI' => $KarirArray);
			$ALLArray      = array_merge($ALLArray,$KarirObj);   
			}

		if(!empty($AlamatArray))
			{
			$AlamatObj     = array('ALAMAT' => $AlamatArray);
			$ALLArray      = array_merge($ALLArray,$AlamatObj);   
			}
		
		if(!empty($AsesmenArray))
			{
			$AsesmenObj 		   = array('ASSESSMENT' => $AsesmenArray);
			$ALLArray 		= array_merge($ALLArray,$AsesmenObj);	
			}
		if(!empty($SMKArray))
			{
			$SMKObj 		   = array('SMK' => $SMKArray);
			$ALLArray 		= array_merge($ALLArray,$SMKObj);	
			}
		if(!empty($KesehatanArray))
			{
			$KesehatanObj 		   = array('KESEHATAN' => $KesehatanArray);
			$ALLArray 		= array_merge($ALLArray,$KesehatanObj);	
			}
		if(!empty($ITPArray))
			{
			$ITPObj 		   = array('ITP' => $ITPArray);
			$ALLArray 		= array_merge($ALLArray,$ITPObj);	
			}
		if(!empty($HBIArray))
			{
			$HBIObj 		   = array('HBI' => $HBIArray);
			$ALLArray 		= array_merge($ALLArray,$HBIObj);	
			}
		if(!empty($ALLArray))
			{
			$ALLArray  		    = json_encode($ALLArray);
			$data['ALLArray'] = $ALLArray;
			$data['AllString'] = base64_encode($ALLArray);	
			}
		else
			{
			$data['ALLArray'] = '';	
			$data['AllString'] = '';	
			}
		return $data;
	}

	public function filter_aspirasi(){
		$data = array();
		$data['result'] = $this->aspirasi(true);
		$this->load->view('konfigurasi/filter_aspirasi', $data);
	}
	
	public function aspirasi($string=false)
	{
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.KeyJobDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrganizationDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrganizationAbr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.sname',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','a.StatusData',1,'1','=');
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/aspirasi/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_aspirasi(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['aspirasi'] = $this->konfigurasi_model->get_aspirasi(false,$param,'a.KeyJob, a.Organization',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('konfigurasi/aspirasi',$data,true); 
		}else{
			$this->load->view('konfigurasi/aspirasi',$data);
		}
	}

	function aspirasi_pdf(){
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.KeyJobDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrganizationDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrganizationAbr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.sname',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','a.StatusData',1,'1','=');
		
		$data['aspirasi'] = $this->konfigurasi_model->get_aspirasi(false,$param,'a.KeyJob, a.Organization');
		$data['no'] = 1;
		$data['content'] = $this->load->view('konfigurasi/aspirasi_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Aspirasi', 'A4', 'Landscape');
	}

	function aspirasi_excel(){
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.KeyJobDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrganizationDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrganizationAbr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.sname',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','a.StatusData',1,'1','=');
		
		$data['aspirasi'] = $this->konfigurasi_model->get_aspirasi(false,$param,'a.KeyJob, a.Organization');
		$data['no'] = 1;
		$data['content'] = $this->load->view('konfigurasi/aspirasi_pdf', $data, true);
        $data['file_name'] = 'Aspirasi';
        $this->load->view('theme/excel_template', $data);
	}

	public function filter_hav_matrix(){
		$data = array(
			'opt_corp_title' => $this->option_model->opt_corp_title()
			, 'opt_hilfm' => $this->option_model->opt_hilfm()
			, 'opt_category' => $this->option_model->opt_category()
			, 'opt_talent_class' => $this->option_model->opt_talent_class_v()
			, 'opt_type' => $this->option_model->opt_type()
			, 'opt_jenis_asesmen' => $this->option_model->opt_jenis_asesmen()
        );
		$data['result'] = $this->load->view('talent/empty_hav', $data, true);
		$this->load->view('konfigurasi/filter_hav_matrix', $data);
	}

	public function get_selected_asesmen($jenis_asesmen){
		$selected_asesmen = '';
		$opt_jenis_asesmen = $this->option_model->opt_jenis_asesmen();
		foreach($opt_jenis_asesmen as $idx => $item){
			if($jenis_asesmen == $idx){
				$selected_asesmen = $item;
			}
		}
		return $selected_asesmen;
	}
	
	public function hav_matrix(){
		$data = array();
		$corp_title = $this->input->post('f_corp_title');
		$job = $this->input->post('f_job');
        $method = $this->input->post('f_category');
        $talent_class = $this->input->post('f_talent_class');
		$type = $this->input->post('f_type');
		$jenis_asesmen = $this->input->post('f_jenis_asesmen');
		$pekerja = $this->input->post('pekerja');
		
		$param['corp_title'] = $data['corp_title'] = implode(',',$corp_title);
		$param['job'] = $data['job'] = implode(',',$job);
		$param['method'] = $data['method'] = implode(',',$method);
		$param['talent_class'] = $data['talent_class'] = $talent_class;
		$param['type'] = $data['type'] = implode(',',$type);
		$param['jenis_asesmen'] = $data['jenis_asesmen'] = $jenis_asesmen;
		$param['pekerja'] = $data['pekerja'] = $pekerja;
		$data['param'] = $param;
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		
		if(is_array($method) && $talent_class != '' && $jenis_asesmen != ''){
			$condition[] = $this->libs->arrWhere('AND','corp_title',$corp_title,0,'IN');
			$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
			$condition[] = $this->libs->arrWhere('AND','method',$method,0,'IN');
			$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
			
			if($pekerja != "")
				$condition[] = $this->libs->arrWhere('AND','pernr',$pekerja,1,'=');
			
			if($type == array("1", "2")){
				$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
			}
			else if($type == array("1")){
				$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
			}
			else if($type == array("2")){
				$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
			}
			else{
				$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
			}
			
			if($talent_class == 1){
				$data['Q1'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q1', 'Q2'");
				$data['Q2'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q3','Q4'");
				$data['Q3'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q5','Q6'");
				$data['Q4'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q7','Q8'");
				$data['Q5'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q9'");
				$this->load->view('konfigurasi/five_talent_class', $data);
			}
			else{
				$data['Q1'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q1'");
				$data['Q2'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q2'");
				$data['Q3'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q3'");
				$data['Q4'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q4'");
				$data['Q5'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q5'");
				$data['Q6'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q6'");
				$data['Q7'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q7'");
				$data['Q8'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q8'");
				$data['Q9'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q9'");
				$this->load->view('konfigurasi/nine_talent_class', $data);
			}
			
		}
		else{
			$this->load->view('talent/empty_hav', $data);
		}
	}

	public function detail_nine_talent_class(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = explode(',', $this->input->get_post('job'));
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = explode(',', $this->input->get_post('talent_class'));
		$filter['type'] = explode(',', $this->input->get_post('type'));
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['pekerja'] = $this->input->get_post('pekerja');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}

		if($filter['pekerja'] != ""){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['pekerja'],0,'=');
		}

		if(count($filter['job']) > 0){
			$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.hilfm',$this->input->get_post('job'),1,'IN');
			$filter['job'] = $this->input->get_post('job');
		}
		
		if(count($filter['talent_class']) > 0){
			$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.talent_class',$this->input->get_post('talent_class'),1,'IN');
			$filter['talent_class'] = $this->input->get_post('talent_class');
		}
		
		
		if(count($filter['type']) > 0){
			if($filter['type'] == array("1", "2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
			}
			else if($filter['type'] == array("1")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
			}
			else if($filter['type'] == array("2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
			}
		}
		else{
			$filter['type'] = $this->input->get_post('type');
			if($filter['type'] == array("1", "2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
			}
			else if($filter['type'] == array("1")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
			}
			else if($filter['type'] == array("2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
			}
			
		}
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/detail_nine_talent_class/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_detail_nine_talent_class(true,$param);
		$config['per_page'] = 20;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['opt_direktorat'] = $this->option_model->opt_direktorat();
		//$data['hav'] = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'talent_class_before, avg_score desc, tanggallahir',$rowpos,$limits);
		//$data['hav'] = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'talent_class_before, corp_title asc, sum_avg desc, tanggallahir',$rowpos,$limits);
		$data['hav'] = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir',$rowpos,$limits);
		
		$this->load->view('konfigurasi/detail_nine_talent_class',$data);
	}
	
	public function detail_nine_talent_class_back(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['pekerja'] = $this->input->get_post('pekerja');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}

		if($filter['pekerja'] != ""){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['pekerja'],0,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/detail_nine_talent_class/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_detail_nine_talent_class(true,$param);
		$config['per_page'] = 20;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['opt_direktorat'] = $this->option_model->opt_direktorat();
		//$data['hav'] = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'talent_class_before, corp_title asc, sum_avg desc, tanggallahir',$rowpos,$limits);
		$data['hav'] = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir',$rowpos,$limits);
		
		$this->load->view('konfigurasi/detail_nine_talent_class',$data);
	}
	
	public function detail_five_talent_class(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = explode(',', $this->input->get_post('job'));
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = explode(',', $this->input->get_post('talent_class'));
		$filter['type'] = explode(',', $this->input->get_post('type'));
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['pekerja'] = $this->input->get_post('pekerja');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','corp_title','('.$filter['corp_title'].')',0,'IN');
		
		$param[] = $this->libs->arrWhere('AND','method','('.$filter['method'].')',0,'IN');

		$param[] = $this->libs->arrWhere('AND','jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['pekerja'] != ""){
			$param[] = $this->libs->arrWhere('AND','pernr',$filter['pekerja'],0,'=');
		}
		
		if(count($filter['job']) > 0){
			$param[] = $this->libs->arrWhere('AND','hilfm',$filter['job'],1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','hilfm',$this->input->get_post('job'),1,'IN');
			$filter['job'] = $this->input->get_post('job');
		}
		
		if(count($filter['talent_class']) > 0){
			$param[] = $this->libs->arrWhere('AND','talent_class',$filter['talent_class'],1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','talent_class',$this->input->get_post('talent_class'),1,'IN');
			$filter['talent_class'] = $this->input->get_post('talent_class');
		}
		
		if(count($filter['type']) > 0){
			if($filter['type'] == array("1", "2")){
				$param[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
			}
			else if($filter['type'] == array("1")){
				$param[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
			}
			else if($filter['type'] == array("2")){
				$param[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
			}
		}
		else{
			$filter['type'] = $this->input->get_post('type');
			if($filter['type'] == '1,2'){
				$param[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
			}
			else if($filter['type'] == '1'){
				$param[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
			}
			else if($filter['type'] == '2'){
				$param[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
			}
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/detail_five_talent_class/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_detail_five_talent_class(true,$param);
		$config['per_page'] = 20;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['hav'] = $this->konfigurasi_model->get_detail_five_talent_class(false,$param,'talent_class, avg_score desc, tanggallahir',$rowpos,$limits);
		
		$this->load->view('konfigurasi/detail_five_talent_class',$data);
	}
	
	public function detail_five_talent_class_back(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['pekerja'] = $this->input->get_post('pekerja');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['pekerja'] != ""){
			$param[] = $this->libs->arrWhere('AND','pernr',$filter['pekerja'],0,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/detail_five_talent_class/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_detail_five_talent_class(true,$param);
		$config['per_page'] = 20;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['hav'] = $this->konfigurasi_model->get_detail_five_talent_class(false,$param,'talent_class, avg_score desc, tanggallahir',$rowpos,$limits);
		
		$this->load->view('konfigurasi/detail_five_talent_class',$data);
	}
	
	function nine_talent_class_pdf() {
		$corp_title = $this->input->get_post('corp_title');
		$job = explode(',',$this->input->get_post('job'));
        $method = $this->input->get_post('method');
		$type = explode(',', $this->input->get_post('type'));
		$jenis_asesmen = $this->input->get_post('jenis_asesmen');
		
		if($type == array("1", "2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($type == array("1")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($type == array("2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$condition[] = $this->libs->arrWhere('AND','corp_title','('.$corp_title.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
		$condition[] = $this->libs->arrWhere('AND','method','('.$method.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
		
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		$data['Q1'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q1'");
		$data['Q2'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q2'");
		$data['Q3'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q3'");
		$data['Q4'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q4'");
		$data['Q5'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q5'");
		$data['Q6'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q6'");
		$data['Q7'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q7'");
		$data['Q8'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q8'");
		$data['Q9'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q9'");
		
		$data['content'] = $this->load->view('konfigurasi/nine_talent_class_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Nine_Talent_Class_HAV_Matrix', 'A4', 'Landscape');
    }
	
	function nine_talent_class_excel() {
		$corp_title = $this->input->get_post('corp_title');
		$job = explode(',',$this->input->get_post('job'));
        $method = $this->input->get_post('method');
		$type = explode(',', $this->input->get_post('type'));
		$jenis_asesmen = $this->input->get_post('jenis_asesmen');
		
		if($type == array("1", "2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($type == array("1")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($type == array("2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$condition[] = $this->libs->arrWhere('AND','corp_title','('.$corp_title.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
		$condition[] = $this->libs->arrWhere('AND','method','('.$method.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		$data['Q1'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q1'");
		$data['Q2'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q2'");
		$data['Q3'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q3'");
		$data['Q4'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q4'");
		$data['Q5'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q5'");
		$data['Q6'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q6'");
		$data['Q7'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q7'");
		$data['Q8'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q8'");
		$data['Q9'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q9'");
		
		$data['content'] = $this->load->view('konfigurasi/nine_talent_class_pdf', $data, true);
        $data['file_name'] = 'Nine_Talent_Class_HAV_Matrix';
        $this->load->view('theme/excel_template', $data);
    }
	
	function five_talent_class_pdf() {
		$corp_title = $this->input->get_post('corp_title');
		$job = explode(',',$this->input->get_post('job'));
        $method = $this->input->get_post('method');
		$type = explode(',', $this->input->get_post('type'));
		$jenis_asesmen = $this->input->get_post('jenis_asesmen');
		
		if($type == array("1", "2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($type == array("1")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($type == array("2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$condition[] = $this->libs->arrWhere('AND','corp_title','('.$corp_title.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
		$condition[] = $this->libs->arrWhere('AND','method','('.$method.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		$data['Q1'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q1'");
		$data['Q2'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q2','Q3','Q4'");
		$data['Q3'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q5','Q7'");
		$data['Q4'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q6','Q8'");
		$data['Q5'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q9'");
		
		$data['content'] = $this->load->view('konfigurasi/five_talent_class_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Five_Talent_Class_HAV_Matrix', 'A4', 'Landscape');
    }
	
	function five_talent_class_excel() {
		$corp_title = $this->input->get_post('corp_title');
		$job = explode(',',$this->input->get_post('job'));
        $method = $this->input->get_post('method');
		$type = explode(',', $this->input->get_post('type'));
		$jenis_asesmen = $this->input->get_post('jenis_asesmen');
		
		if($type == array("1", "2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($type == array("1")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($type == array("2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$condition[] = $this->libs->arrWhere('AND','corp_title','('.$corp_title.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
		$condition[] = $this->libs->arrWhere('AND','method','('.$method.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		$data['Q1'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q1'");
		$data['Q2'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q2','Q3','Q4'");
		$data['Q3'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q5','Q7'");
		$data['Q4'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q6','Q8'");
		$data['Q5'] = $this->konfigurasi_model->get_mapping_hav_matrix($condition, "'Q9'");
		
		$data['content'] = $this->load->view('konfigurasi/five_talent_class_excel', $data, true);
        $data['file_name'] = 'Five_Talent_Class_HAV_Matrix';
        $this->load->view('theme/excel_template', $data);
    }
	
	function detail_nine_talent_class_pdf(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');
		
		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}
		
		$data['hav'] = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir');
		$data['filter'] = $filter;
		$data['content'] = $this->load->view('konfigurasi/detail_nine_talent_class_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Detail_Nine_Talent_Class_HAV_Matrix', 'A4', 'Landscape');
	}
	
	function detail_nine_talent_class_excel(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');
		
		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}
		
		$data['hav'] = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir');
		$data['filter'] = $filter;
		$data['content'] = $this->load->view('konfigurasi/detail_nine_talent_class_pdf', $data, true);
        $data['file_name'] = 'Detail_Nine_Talent_Class_HAV_Matrix';
        $this->load->view('theme/excel_template', $data);
	}
	
	function detail_five_talent_class_pdf(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','talent_class',$filter['talent_class'],1,'IN');
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$data['hav'] = $this->konfigurasi_model->get_detail_five_talent_class(false,$param,'talent_class, avg_score desc, tanggallahir');
		$data['filter'] = $filter;
		$data['content'] = $this->load->view('konfigurasi/detail_five_talent_class_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Detail_Five_Talent_Class_HAV_Matrix', 'A4', 'Landscape');
	}
	
	function detail_five_talent_class_excel(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','talent_class',$filter['talent_class'],1,'IN');
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$data['hav'] = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'talent_class, avg_score desc, tanggallahir');
		$data['filter'] = $filter;
		$data['content'] = $this->load->view('konfigurasi/detail_five_talent_class_pdf', $data, true);
        $data['file_name'] = 'Detail_Five_Talent_Class_HAV_Matrix';
        $this->load->view('theme/excel_template', $data);
	}

	public function detail_pekerja()
	{
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['compare_pernr'] = $this->input->get_post('compare_pernr');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['source'] = $this->input->get_post('source');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		
		
		$data['pekerja'] 		= $this->talent_model->data_personal($filter['pernr']);
		$data['file_image'] 	= $this->hasil_model->get_foto($filter['pernr']);

		$data['alamat_domisili'] = $this->hasil_model->get_domisili($filter['pernr']);
		$data['keluarga'] 		= $this->hasil_model->get_data_keluarga($filter['pernr']);
		$data['pendidikan'] 	= $this->hasil_model->get_data_pendidikan($filter['pernr']);
		$data['riwayat'] 		= $this->hasil_model->get_riwayat_jabatan($filter['pernr']);
		$data['smk'] 			= $this->hasil_model->get_history_smk($filter['pernr']);
		$data['itp'] 			= $this->hasil_model->get_history_itp($filter['pernr']);
		$data['training'] 		= $this->hasil_model->get_data_training($filter['pernr']);
		$data['asesmen'] 		= $this->hasil_model->get_history_asesmen($filter['pernr']);
		$data['klaim'] 			= $this->hasil_model->get_history_kesehatan($filter['pernr']);
		$data['insus'] 			= $this->hasil_model->get_history_insus($filter['pernr']);
		
		$data['filter'] = $filter;
		
		$data['detail_profile'] = $this->load->view('talent/detail_profile',$data,TRUE);
		$this->load->view('konfigurasi/detail_pekerja',$data);
	}

	public function move_kuadran(){
		$data = array();
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['compare_pernr'] = $this->input->get_post('compare_pernr');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['source'] = $this->input->get_post('source');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');

		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],1,'=');
		$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['pernr'],1,'=');

		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}

		$pekerja = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'');
		$data['pekerja'] = isset($pekerja[0])?$pekerja[0]:array();
		$data['filter'] = $filter;
		$data['opt_hav'] = $this->option_model->opt_hav();
		$this->load->view('konfigurasi/move_kuadran',$data);
	}

	public function save_kuadran(){
		$data = array();
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['compare_pernr'] = $this->input->get_post('compare_pernr');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['source'] = $this->input->get_post('source');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');

		$talent_class_before = $this->libs->detail_talent_class($this->input->get_post('talent_class_before'));
		$talent_class_after = $this->libs->detail_talent_class($this->input->get_post('talent_class_after'));
		
		$data_update = array(
			'talent_class' => $talent_class_after["talent_class"]
			, 'talent_score' => $talent_class_after["talent_score"]
			, 'talent_class_desc' => $talent_class_after["talent_class_desc"]
			, 'talent_class_before' => $talent_class_before["talent_class"]
			, 'talent_score_before' => $talent_class_before["talent_score"]
			, 'talent_class_desc_before' => $talent_class_before["talent_class_desc"]
		);

		$condition = array(
			'pernr' => $this->input->get_post('hid_pernr')
			, 'method' => $this->input->get_post('hid_method')
			, 'type' => $this->input->get_post('hid_type')
			, 'jenis_asesmen' => $this->input->get_post('hid_jenis_asesmen')
		);
 
		$proses = $this->konfigurasi_model->save_kuadran($data_update, $condition);

		if($proses['status']){
			//$this->konfigurasi_model->run_succession_plan_by_pernr($condition['pernr']);
			$this->auditrail_model->add_log('Konfigurasi', 'Adjust HAV Matrix, PN = ' . $condition["pernr"] . ", BEFORE : " . $talent_class_before["talent_class"] . ", AFTER : " . $talent_class_after["talent_class"]);
			$data['message'] = $this->libs->generate_message('success', $proses['message']);
		}else{
			$data['message'] = $this->libs->generate_message('danger', $proses['message']);
		}

		$param[] = $this->libs->arrWhere('AND','a.pernr',$condition["pernr"],1,'=');
		$param[] = $this->libs->arrWhere('AND','a.method',$condition["method"],1,'=');
		$param[] = $this->libs->arrWhere('AND','a.type',$condition["type"],1,'=');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$condition["jenis_asesmen"],1,'=');
		
		$pekerja = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'');
		$data['pekerja'] = isset($pekerja[0])?$pekerja[0]:array();
		$data['filter'] = $filter;
		$data['opt_hav'] = $this->option_model->opt_hav();
		$this->load->view('konfigurasi/move_kuadran',$data);
	}

	public function filter_bucket_hav(){
		$data = array(
			'opt_status' => array(''=>'- Semua status -') + $this->libs->arrStatusPublish()
        );
		$data['result'] = $this->bucket_hav(true);
		$this->load->view('konfigurasi/filter_bucket_hav', $data);
	}
	
	public function bucket_hav($string=false)
	{
		$filter['f_status'] = trim($this->input->post('f_status'));
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_status']!=''){
			$param[] = $this->libs->arrWhere('AND','status',"{$filter['f_status']}",'1','=');
		}
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(talent_class',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','bucket_name',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','talent_class_desc',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','modifier',$_SESSION[$this->config->item('session_prefix')]['pernr'],'1','=');
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/bucket_hav/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_bucket_hav(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		$data['bucket_hav'] = $this->konfigurasi_model->get_bucket_hav(false,$param,'modified_date desc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('konfigurasi/bucket_hav',$data,true); 
		}else{
			$this->load->view('konfigurasi/bucket_hav',$data);
		}
	}

	public function save_hav_bucket(){
		$data = array();
		$talent_class =  $this->libs->detail_talent_class($this->input->get_post('hid_talent_class'));

		$param_ins = array(
			'talent_class' => $talent_class["talent_class"]
			, 'talent_class_desc' => $talent_class["talent_class_desc"]
			, 'bucket_name' => $this->input->get_post('bucket_name')
			, 'modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			, 'modified_by' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			, 'modified_date' => date('Y-m-d H:i:s')
			, 'status' => 0
		);

		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['compare_pernr'] = $this->input->get_post('compare_pernr');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['source'] = $this->input->get_post('source');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');

		$param[] = $this->libs->arrWhere('AND','corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','method','('.$filter['method'].')',0,'IN');
		//$param[] = $this->libs->arrWhere('AND','talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','type',$filter['type'],1,'=');
		$param[] = $this->libs->arrWhere('AND','jenis_asesmen',$filter['jenis_asesmen'],1,'=');
		$param[] = $this->libs->arrWhere('AND','is_checked',1,1,'=');

		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}

		$list_pekerja = $this->konfigurasi_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir');

		$arr_input = $this->konfigurasi_model->insert_hav_bucket($param_ins, $list_pekerja);
		if($arr_input['status']){
			$this->auditrail_model->add_log('Konfigurasi', 'Insert HAV Bucket');
			$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
			unset($_POST);
		}else{
			$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
		}
		
		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusPublish();

		$data['result'] = $this->bucket_hav(true);
		$this->load->view('konfigurasi/filter_bucket_hav', $data);
	}

	function detail_bucket_vote(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		
		$data['filter'] = $filter;

		$data['hav_bucket'] = $this->db->get_where('hav_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$this->db->order_by('urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$data['hav_voters'] = $this->db->get_where('hav_bucket_voters', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();

		$data['content'] = $this->load->view('konfigurasi/hav_content_vote',$data,true); 
		$this->load->view('konfigurasi/detail_bucket',$data); 
	}

	function refresh_bucket_vote(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		
		$data['filter'] = $filter;

		$data['hav_bucket'] = $this->db->get_where('hav_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$this->db->order_by('urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$data['hav_voters'] = $this->db->get_where('hav_bucket_voters', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		
		//update bobot
		$update_bobot = $this->konfigurasi_model->update_bobot_voters($data['hav_detail']);
		// update urutan
		$this->db->order_by('count_voter desc, urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$update_urutan = $this->konfigurasi_model->update_urutan_voters($data['hav_detail']);

		$this->db->order_by('urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$data['message'] = $this->libs->generate_message('success','Data berhasil diperbarui.');
		$this->load->view('konfigurasi/hav_content_vote',$data);
	}

	function unpublish_bucket(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$param = array(
			'modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			, 'modified_by' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			, 'modified_date' => date('Y-m-d H:i:s')
			, 'status' => 0
		);
		$proses = $this->db->update('hav_bucket', $param, array('id_bucket' => $filter['id_bucket']));

		if($proses){
			$this->auditrail_model->add_log('Konfigurasi', 'Unpublish Hav Bucket. Id Bucket = '. $filter['id_bucket']);
			$data['message'] = $this->libs->generate_message('success','Data berhasil disimpan.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Data gagal disimpan.');
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusPublish();

		$data['result'] = $this->bucket_hav(true);
		$this->load->view('konfigurasi/filter_bucket_hav', $data);
	}

	function delete_bucket_hav(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
	
		$proses = $this->db->delete('hav_bucket', array('id_bucket' => $filter['id_bucket']));

		if($proses){
			$this->db->delete('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']));
			$this->auditrail_model->add_log('Konfigurasi', 'Delete Hav Bucket. Id Bucket = '. $filter['id_bucket']);
			$data['message'] = $this->libs->generate_message('success','Data berhasil dihapus.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Data gagal dihapus.');
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusPublish();

		$data['result'] = $this->bucket_hav(true);
		$this->load->view('konfigurasi/filter_bucket_hav', $data);
	}

	function save_hav_bucket_vote(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$param = array(
			'modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			, 'modified_by' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			, 'modified_date' => date('Y-m-d H:i:s')
			, 'status' => 1
		);

		$arr_data['arr_cs'] = $this->input->get_post('cs');
		$arr_data['arr_text_cs'] = $this->input->get_post('text_cs');

		$proses = $this->konfigurasi_model->publish_hav_bucket($filter, $param, $arr_data);

		if($proses['status']){
			$this->auditrail_model->add_log('Konfigurasi', 'Publish Hav Bucket. Id Bucket = '. $filter['id_bucket']);
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusPublish();

		$data['result'] = $this->bucket_hav(true);
		$this->load->view('konfigurasi/filter_bucket_hav', $data);
	}

	public function filter_bucket_hav_vote(){
		$data = array();
		$data['result'] = $this->bucket_hav_vote(true);
		$this->load->view('konfigurasi/filter_bucket_hav_vote', $data);
	}
	
	public function bucket_hav_vote($string=false)
	{
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.talent_class',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.bucket_name',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.talent_class_desc',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','b.pernr',$_SESSION[$this->config->item('session_prefix')]['pernr'],'1','=');
		$param[] = $this->libs->arrWhere('AND','a.status',1,'1','=');
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/bucket_hav_vote/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_bucket_hav_vote(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		$data['bucket_hav'] = $this->konfigurasi_model->get_bucket_hav_vote(false,$param,'modified_date desc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('konfigurasi/bucket_hav_vote',$data,true); 
		}else{
			$this->load->view('konfigurasi/bucket_hav_vote',$data);
		}
	}

	function detail_bucket_to_vote(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		
		$data['filter'] = $filter;

		$data['hav_bucket'] = $this->db->get_where('hav_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$this->db->order_by('urutan');
		//$data['hav_detail'] = $this->db->get_where('hav_bucket_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$data['hav_detail'] = $this->konfigurasi_model->get_hav_bucket_vote_result($filter);
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		$data['content'] = $this->load->view('konfigurasi/hav_content_to_vote',$data,true); 
		$this->load->view('konfigurasi/detail_bucket_to_vote',$data); 
	}

	function vote_bsm(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['nama'] = $this->input->get_post('nama');
		$filter['method'] = $this->input->get_post('method');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');

		$data['hav_bucket'] = $this->db->get_where('hav_bucket', array('id_bucket' => $filter['id_bucket']))->row();

		if($data['hav_bucket']->status == 1){

			$proses = $this->konfigurasi_model->vote_bsm($filter);

			if($proses['status']){
				$this->auditrail_model->add_log('BSM Vote', 'Vote PN = ' . $filter['pernr'] . ', Talent Class = ' . $filter['talent_class']  . ', Id Bucket = ' . $filter['id_bucket']);
				$data['message'] = $this->libs->generate_message('success',$proses['message']);
			}
			else{
				$data['message'] = $this->libs->generate_message('danger',$proses['message']);
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Vote is closed.');
		}

		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();

		$this->db->order_by('urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$this->load->view('konfigurasi/hav_content_to_vote',$data); 
	}

	function unvote_bsm(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['nama'] = $this->input->get_post('nama');
		$filter['method'] = $this->input->get_post('method');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');

		$data['hav_bucket'] = $this->db->get_where('hav_bucket', array('id_bucket' => $filter['id_bucket']))->row();

		if($data['hav_bucket']->status == 1){

			$proses = $this->konfigurasi_model->unvote_bsm($filter);

			if($proses['status']){
				$this->auditrail_model->add_log('BSM Vote', 'Unvote PN = ' . $filter['pernr'] . ', Talent Class = ' . $filter['talent_class']  . ', Id Bucket = ' . $filter['id_bucket']);
				$data['message'] = $this->libs->generate_message('success',$proses['message']);
			}
			else{
				$data['message'] = $this->libs->generate_message('danger',$proses['message']);
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Vote is closed.');
		}

		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();

		$this->db->order_by('urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$this->load->view('konfigurasi/hav_content_to_vote',$data); 
	}
	

	function detail_bucket_sort(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		
		$data['filter'] = $filter;

		$data['hav_bucket'] = $this->db->get_where('hav_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$this->db->order_by('urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$data['hav_voters'] = $this->db->get_where('hav_bucket_voters', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();

		$data['content'] = $this->load->view('konfigurasi/hav_content_sort',$data,true); 
		$this->load->view('konfigurasi/detail_bucket_sort',$data); 
	}

	function update_hav_detail_ordered_list(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		//$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['method'] = $this->input->get_post('method');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$new_urutan = $this->input->get_post('urutan');

		$proses = $this->konfigurasi_model->update_hav_detail_ordered_list($filter, $new_urutan);

		if($proses['status']){
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}

		$data['hav_bucket'] = $this->db->get_where('hav_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$this->db->order_by('urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$data['hav_voters'] = $this->db->get_where('hav_bucket_voters', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		$this->load->view('konfigurasi/hav_content_sort',$data); 
	}

	function export_to_hav(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		
		//update bobot
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$update_bobot = $this->konfigurasi_model->update_bobot_voters($data['hav_detail']);
		// update urutan
		$this->db->order_by('count_voter desc, urutan');
		$data['hav_detail'] = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$update_urutan = $this->konfigurasi_model->update_urutan_voters($data['hav_detail']);

		$hav_detail = $this->db->get_where('hav_bucket_aspirasi_detail', array('id_bucket' => $filter['id_bucket']))->result();
		$proses = $this->konfigurasi_model->export_to_hav($hav_detail);

		if($proses['status']){
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusPublish();

		$data['result'] = $this->bucket_hav(true);
		$this->load->view('konfigurasi/filter_bucket_hav', $data);
	}

	public function get_pekerja() {
		$term = $this->db->escape_str(trim($this->input->get_post('searchTerm')));

		$cs = $this->konfigurasi_model->get_pekerja($term);
		if($cs->num_rows() > 0) {
			foreach($cs->result() as $idx=>$row){
				$result[$idx] = array('id'=>$row->PERNR, 'text'=>$row->PERNR ."/". $row->SNAME ."/".$row->STELL_TX ."/".$row->KOSTL_TX); 
			}
		} else {
			$result = array(0=>array('id'=>'','text'=>'- Data Tidak Ditemukan -'));
		}
		
		echo json_encode($result);
	}

	public function check_sp(){
		$this->konfigurasi_model->run_succession_plan_by_pernr('00053328');
		die;
	}

	function update_hav_detail_result_ordered_list(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['voter'] = $_SESSION[$this->config->item('session_prefix')]['pernr'];
		//$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['method'] = $this->input->get_post('method');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$new_urutan = $this->input->get_post('urutan');

		$proses = $this->konfigurasi_model->update_hav_detail_result_ordered_list($filter, $new_urutan);

		if($proses['status']){
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}

		$data['hav_bucket'] = $this->db->get_where('hav_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$this->db->order_by('urutan');
		//$data['hav_detail'] = $this->db->get_where('hav_bucket_detail', array('id_bucket' => $filter['id_bucket']))->result();
		//$data['hav_voters'] = $this->db->get_where('hav_bucket_voters', array('id_bucket' => $filter['id_bucket']))->result();
		$data['hav_detail'] = $this->konfigurasi_model->get_hav_bucket_vote_result($filter);
		$update_bobot = $this->konfigurasi_model->update_bobot_vote($filter);
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		$this->load->view('konfigurasi/hav_content_to_vote',$data); 
	}

	public function filter_exclude_candidates(){
		$data = array();
		$data['result'] = $this->exclude_candidates(true);
		$this->load->view('konfigurasi/filter_exclude_candidates', $data);
	}
	
	public function exclude_candidates($string=false)
	{
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		$param[] = $this->libs->arrWhere('AND','(a.keyjobs',"%{$filter['f_keyword']}%",'1','LIKE');
		$param[] = $this->libs->arrWhere('OR','a.pernr',"%{$filter['f_keyword']}%",'1','LIKE');
		$param[] = $this->libs->arrWhere('OR','b.keyjobs_desc',"%{$filter['f_keyword']}%",'1','LIKE');
		$param[] = $this->libs->arrWhere('OR','c.organization',"%{$filter['f_keyword']}%",'1','LIKE');
		$param[] = $this->libs->arrWhere('OR','c.organization_desc',"%{$filter['f_keyword']}%",'1','LIKE');
		$param[] = $this->libs->arrWhere('OR','d.sname',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		
		/* Paginatian */
		$config['base_url'] = site_url('konfigurasi/exclude_candidates/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->konfigurasi_model->get_exclude_candidates(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['user'] = $this->konfigurasi_model->get_exclude_candidates(false,$param,'a.pernr asc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('konfigurasi/exclude_candidates',$data,true); 
		}else{
			$this->load->view('konfigurasi/exclude_candidates',$data);
		}
	}

	public function delete_exclude_candidates()
	{
		if($this->input->post('delete')){
			$this->form_validation->set_rules('pernr', 'PERNR', 'trim|required');
			$this->form_validation->set_rules('keyjobs', 'PERNR', 'trim|required');
			if($this->form_validation->run()==TRUE){
				$this->auditrail_model->add_log('Konfigurasi', 'Delete Exclude Candidates');
				if($this->konfigurasi_model->delete_exclude_candidates($this->input->post('keyjobs'), $this->input->post('pernr'))){
					$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('success','Data berhasil dihapus.');
				}else{
					$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('danger','Data gagal dihapus.');
				}
			}else{
				$_SESSION[$this->config->item('session_prefix')]['message'] = $this->libs->generate_message('danger','Parameter tidak valid.');
			}
		}
		$this->exclude_candidates(false);
	}
}

/* End of file konfigurasi.php */
/* Location: ./application/controllers/konfigurasi.php */