<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Template extends CI_Controller {
	
	public function __construct()
   	{
		parent::__construct();
		// Your own constructor code
		$this->mysession->check_no_session();
		$this->mysession->check_session_expired();
      $this->load->library(array('pagination'));
		$this->load->model(array('user_model','option_model','template_model', 'konfigurasi_model','hasil_model'));
   	}



      public function autocomp_pekerja()
      {
         $term = $this->input->get('term');
         $res  = $this->template_model->autocomp_pekerja($term);
         if($res->num_rows() > 0)
            {
            $ret = array();
            foreach($res->result() as $row)
               {
               $ret[] = array('pernr'=>$row->PERNR, 'label'=> ($row->PERNR . '/' . $row->SNAME));
               }
            echo json_encode($ret);
            } 
         else
            {
            echo json_encode(array('0'=>array('id'=>'', 'label'=>'-Data tidak ditemukan-')));
         }
      }



      public function autocomp_pa()
      {
         $term = $this->input->get('term');
         $res  = $this->template_model->autocomp_pa($term);
         if($res->num_rows() > 0)
            {
            $ret = array();
            foreach($res->result() as $row)
               {
               $ret[] = array('pernr'=>$row->PERNR, 'label'=> ($row->WERKS . '/' . $row->WERKS_TX));
               }
            echo json_encode($ret);
            } 
         else
            {
            echo json_encode(array('0'=>array('id'=>'', 'label'=>'-Data tidak ditemukan-')));
         }
      }



      public function autocomp_psa()
      {
         $term = $this->input->get('term');
         $res  = $this->template_model->autocomp_psa($term);
         if($res->num_rows() > 0)
            {
            $ret = array();
            foreach($res->result() as $row)
               {
               $ret[] = array('pernr'=>$row->PERNR, 'label'=> ($row->BTRTL . '/' . $row->BTRTL_TX));
               }
            echo json_encode($ret);
            } 
         else
            {
            echo json_encode(array('0'=>array('id'=>'', 'label'=>'-Data tidak ditemukan-')));
         }
      }



      public function autocomp_histori_jabatan()
      {
         $term = $this->input->get('term');
         $res  = $this->template_model->autocomp_histori_jabatan($term);
         if($res->num_rows() > 0)
            {
            $ret = array();
            foreach($res->result() as $row)
               {
               $ret[] = array('jabatan'=>$row->JABATAN, 'label'=> ($row->JABATAN));
               }
            echo json_encode($ret);
            } 
         else
            {
            echo json_encode(array('0'=>array('jabatan'=>'', 'label'=>'-Data tidak ditemukan-')));
         }
      }



      public function autocomp_histori_uker()
      {
         $term = $this->input->get('term');
         $res  = $this->template_model->autocomp_histori_uker($term);
         if($res->num_rows() > 0)
            {
            $ret = array();
            foreach($res->result() as $row)
               {
               $ret[] = array('uker'=>$row->UKER, 'label'=> trim($row->UKER));
               }
            echo json_encode($ret);
            } 
         else
            {
            echo json_encode(array('0'=>array('uker'=>'', 'label'=>'-Data tidak ditemukan-')));
         }
      }



      public function autocomp_jurusan()
      {
         $term = $this->input->get('term');
         $res  = $this->template_model->autocomp_jurusan($term);
         if($res->num_rows() > 0)
            {
            $ret = array();
            foreach($res->result() as $row)
               {
               $ret[] = array('major'=>$row->MAJOR, 'label'=> ($row->MAJOR . '/' . $row->TEXT));
               }
            echo json_encode($ret);
            } 
         else
            {
            echo json_encode(array('0'=>array('major'=>'', 'label'=>'-Data tidak ditemukan-')));
         }
      }



      public function autocomp_universitas()
      {
         $term = $this->input->get('term');
         $res  = $this->template_model->autocomp_universitas($term);
         if($res->num_rows() > 0)
            {
            $ret = array();
            foreach($res->result() as $row)
               {
               $ret[] = array('institution'=>$row->INSTITUTION, 'label'=> trim($row->INSTITUTION));
               }
            echo json_encode($ret);
            } 
         else
            {
            echo json_encode(array('0'=>array('institution'=>'', 'label'=>'-Data tidak ditemukan-')));
         }
      }



      public function autocomp_training()
      {
         $term = $this->input->get('term');
         $res  = $this->template_model->autocomp_training($term);
         if($res->num_rows() > 0)
            {
            $ret = array();
            foreach($res->result() as $row)
               {
               $ret[] = array('program_pendidikan'=>$row->program_pendidikan, 'label'=> trim($row->program_pendidikan));
               }
            echo json_encode($ret);
            } 
         else
            {
            echo json_encode(array('0'=>array('program_pendidikan'=>'', 'label'=>'-Data tidak ditemukan-')));
         }
      }


   	public function pencarian_pekerja()
   	{
   		$data['opt_mk_jabatan_uker'] 	= $this->option_model->opt_mk_jabatan_uker();
   		$data['opt_mk_jg_pg'] 			= $this->option_model->opt_mk_jg_pg();
   		$data['opt_jabatan'] 			= $this->option_model->opt_jabatan();
   		$data['opt_program_masuk'] 	= $this->option_model->opt_program_masuk();
         $data['opt_job_grade']        = $this->option_model->opt_job_grade();
         $data['opt_person_grade']     = $this->option_model->opt_person_grade();
         $data['opt_agama']            = $this->option_model->opt_agama();
         $data['opt_rekomendasi_asesmen']            = $this->option_model->opt_rekomendasi_asesmen();
         $data['opt_jenis_klaim']            = $this->option_model->opt_jenis_klaim();
         $data['opt_insus']            = $this->option_model->opt_get_insus();
   		$this->load->view('template/pencarian_pekerja',$data);
   	}

	public function generate_template(){
			// Data Utama SDM
			$data['f_pernr'] 			     = $this->input->post('f_pernr');
			 $data['f_pa']                = $this->input->post('f_pa');
			 $data['f_psa']               = $this->input->post('f_psa');
			$data['f_jenis_kelamin'] 	  = $this->input->post('f_jenis_kelamin');
			 $data['f_jg_min']            = $this->input->post('f_jg_min');
			 $data['f_jg_max']            = $this->input->post('f_jg_max');
			 $data['f_pg_min']            = $this->input->post('f_pg_min');
			 $data['f_pg_max']            = $this->input->post('f_pg_max');
			$data['f_usia_min'] 			  = $this->input->post('f_usia_min');
			 $data['f_usia_max']          = $this->input->post('f_usia_max');
			$data['f_agama'] 			     = $this->input->post('f_agama');
			$data['f_jabatan'] 			  = $this->input->post('f_jabatan');
			 $data['f_program_masuk']     = $this->input->post('f_program_masuk');
			$data['f_mk_jabatan'] 		  = $this->input->post('f_mk_jabatan');
			$data['f_mk_jg'] 			     = $this->input->post('f_mk_jg');
			$data['f_mk_pg'] 			     = $this->input->post('f_mk_pg');
			$data['f_mk_uker'] 			  = $this->input->post('f_mk_uker');

		  // Data Pendidikan
			 $data['f_universitas']     = $this->input->post('f_universitas');
			 $data['f_jurusan']         = $this->input->post('f_jurusan');
			 $data['f_ipk_min']         = $this->input->post('f_ipk_min');
			 $data['f_ipk_max']         = $this->input->post('f_ipk_max');
			 $data['f_training']        = $this->input->post('f_training');


		  // Data Pengembangan Karir
			 $data['f_histori_jabatan'] = $this->input->post('f_histori_jabatan');
			 $data['f_histori_uker']    = $this->input->post('f_histori_uker');

		   // Data Alamat
			 $data['f_homebase'] = $this->input->post('f_homebase');
			 $data['f_domisili'] = $this->input->post('f_domisili');
			
			// Data Assessment
			$data['f_rekomendasi_asesmen'] = $this->input->post('f_rekomendasi_asesmen');
			$data['f_judul_assesment'] = $this->input->post('f_judul_assesment');
			
			// Data SMK
			$data['f_sko_min']            = $this->input->post('f_sko_min');
			$data['f_sko_max']            = $this->input->post('f_sko_max');
			$data['f_skk_min']            = $this->input->post('f_skk_min');
			$data['f_skk_max']            = $this->input->post('f_skk_max');
			$data['f_smk_min']            = $this->input->post('f_smk_min');
			$data['f_smk_max']            = $this->input->post('f_smk_max');
			$data['f_tahun_smk']            = $this->input->post('f_tahun_smk');
			
			// Data Kesehatan
			   $data['f_jenis_klaim'] = $this->input->post('f_jenis_klaim');
			   
		   // Data ITP
				$data['f_itp_min']            = $this->input->post('f_itp_min');
				$data['f_itp_max']            = $this->input->post('f_itp_max');
				
			// Data Insus
			$data['f_insus']            = $this->input->post('f_insus');
			
			$ALLArray = array();
			$SDMArray = array();
			 $PendidikanArray = array();
			 $KarirArray = array();
			 $AlamatArray = array();
			$AsesmenArray = array();
			$SMKArray = array();
			$KesehatanArray = array();
			$ITPArray = array();
			$HBIArray = array();

			if($data['f_pernr']!='')
				{
				$enter   = nl2br($data['f_pernr']);
				$arr     = explode('<br />', $enter);
				$cln     = array();

				foreach ($arr as $row) 
				   {
				   $row = trim($row);

				   if($row!='')
					  {
					  $cln[$row] = $this->db->escape($row);
					  }  
				   }

				if(count($cln) > 0)
				   {
				   $data['f_pernr']    = implode(',', $cln);
				   }

				$val        = array('value' => $data['f_pernr']);
				$obj        = array('PERNR' => $val);
				$SDMArray   = array_merge($SDMArray, $obj);
				}

			 if($data['f_pa']!='')
				{
				$enter   = nl2br($data['f_pa']);
				$arr     = explode('<br />', $enter);
				$cln     = array();

				foreach ($arr as $row) 
				   {
				   $row = trim($row);

				   if($row!='')
					  {
					  $cln[$row] = $this->db->escape($row);
					  }  
				   }

				if(count($cln) > 0)
				   {
				   $data['f_pa']    = implode(',', $cln);
				   }

				$val        = array('value' => $data['f_pa']);
				$obj        = array('PA'   => $val);
				$SDMArray   = array_merge($SDMArray, $obj);
				}

			// User App KW -> PA
			if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KW'){
				$val        = array('value' => $this->db->escape($_SESSION[$this->config->item('session_prefix')]['pa']));
				$obj        = array('PA'   => $val);
				$SDMArray   = array_merge($SDMArray, $obj);
			}
			
			 if($data['f_psa']!='')
				{
				$enter   = nl2br($data['f_psa']);
				$arr     = explode('<br />', $enter);
				$cln     = array();

				foreach ($arr as $row) 
				   {
				   $row = trim($row);

				   if($row!='')
					  {
					  $cln[$row] = $this->db->escape($row);
					  }  
				   }

				if(count($cln) > 0)
				   {
				   $data['f_psa']    = implode(',', $cln);
				   }

				$val           = array('value'   => $data['f_psa']);
				$obj           = array('PSA'     => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}
			
			// User App KC, KN, SD -> PSA
			if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KC' || $_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KN' || 	$_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'SD'){
				$val           = array('value'   => $this->db->escape($_SESSION[$this->config->item('session_prefix')]['psa']));
				$obj           = array('PSA'     => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
			}

			if($data['f_jenis_kelamin']!='')
				{
				$val 	         = array('value'    => $this->db->escape($data['f_jenis_kelamin']));
				$obj 	         = array('JK' 	    => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			 if($data['f_jg_min']!='')
				{
				$val           = array('value'    => $data['f_jg_min']);
				$obj           = array('JG_MIN'   => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			 if($data['f_jg_max']!='')
				{
				$val           = array('value'    => $data['f_jg_max']);
				$obj           = array('JG_MAX'   => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			 if($data['f_pg_min']!='')
				{
				$val           = array('value'    => $data['f_pg_min']);
				$obj           = array('PG_MIN'   => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			 if($data['f_pg_max']!='')
				{
				$val           = array('value'    => $data['f_pg_max']);
				$obj           = array('PG_MAX'   => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			if($data['f_usia_min']!='')
				{
				$val 	         = array('value'      => $data['f_usia_min']);
				$obj 	         = array('USIA_MIN' 	=> $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			 if($data['f_usia_max']!='')
				{
				$val           = array('value'      => $data['f_usia_max']);
				$obj           = array('USIA_MAX'   => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			if($data['f_agama']!='')
				{
				$val 	         = array('value'      => $data['f_agama']);
				$obj 	         = array('AGAMA'      => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			if($data['f_jabatan']!='')
				{
				$jabatan 	   = implode("','", $data['f_jabatan']);
				$jabatan  	   = "'".$jabatan."'";
				$val 		      = array('value'     => $jabatan);
				$obj 		      = array('HILFM'     => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			 if($data['f_program_masuk']!='')
				{
				$prog          = implode("','", $data['f_program_masuk']);
				$prog          = "'".$prog."'";
				$val           = array('value'         => $prog);
				$obj           = array('PROGRAM_MASUK' => $val);
				$SDMArray      = array_merge($SDMArray, $obj);
				}

			if($data['f_mk_jabatan']!='')
				{
				$mk_jabatan    = implode("','", $data['f_mk_jabatan']);
				$mk_jabatan    = "'".$mk_jabatan."'";
				$val 		      = array('value' 		   => $mk_jabatan);
				$obj 		      = array('MK_JABATAN' 	=> $val);
				$SDMArray 	   = array_merge($SDMArray, $obj);
				}

			if($data['f_mk_jg']!='')
				{
				$mk_jg 		   = implode("','", $data['f_mk_jg']);
				$mk_jg 		   = "'".$mk_jg."'";
				$val 		      = array('value'        => $mk_jg);
				$obj 		      = array('MK_JG'        => $val);
				$SDMArray 	   = array_merge($SDMArray, $obj);
				}

			if($data['f_mk_pg']!='')
				{
				$mk_pg 		   = implode("','", $data['f_mk_pg']);
				$mk_pg 		   = "'".$mk_pg."'";
				$val 		      = array('value'     => $mk_pg);
				$obj 		      = array('MK_PG'     => $val);
				$SDMArray 	   = array_merge($SDMArray, $obj);
				}

			if($data['f_mk_uker']!='')
				{
				$mk_uker 	   = implode("','", $data['f_mk_uker']);
				$mk_uker 	   = "'".$mk_uker."'";
				$val 	   	   = array('value'     => $mk_uker);
				$obj 		      = array('MK_UKER'   => $val);
				$SDMArray 	   = array_merge($SDMArray, $obj);
				}

		  // Filter Data Pendidikan
			 if($data['f_universitas']!='')
				{
				$enter   = nl2br($data['f_universitas']);
				$arr     = explode('<br />', $enter);
				$cln     = array();

				foreach ($arr as $row) 
				   {
				   $row = trim($row);

				   if($row!='')
					  {
					  $cln[$row] = $this->db->escape_str($row);
					  }  
				   }

				if(count($cln) > 0)
				   {
				   $data['f_universitas']    = implode(',', $cln);
				   }

				$val        = array('value' => $data['f_universitas']);
				$obj        = array('UNIVERSITAS' => $val);
				$PendidikanArray   = array_merge($PendidikanArray, $obj);
				}



			 if($data['f_jurusan']!='')
				{
				$enter   = nl2br($data['f_jurusan']);
				$arr     = explode('<br />', $enter);
				$cln     = array();

				foreach ($arr as $row) 
				   {
				   $row = trim($row);

				   if($row!='')
					  {
					  $cln[$row] = $this->db->escape_str($row);
					  }  
				   }

				if(count($cln) > 0)
				   {
				   $data['f_jurusan']    = implode(',', $cln);
				   }
				
				$val        = array('value' => $data['f_jurusan']);
				$obj        = array('JURUSAN' => $val);
				$PendidikanArray   = array_merge($PendidikanArray, $obj);
				}

			 if($data['f_ipk_min']!='')
				{
				$val                  = array('value'    => $data['f_ipk_min']);
				$obj                  = array('IPK_MIN'   => $val);
				$PendidikanArray      = array_merge($PendidikanArray, $obj);
				}

			 if($data['f_ipk_max']!='')
				{
				$val                  = array('value'    => $data['f_ipk_max']);
				$obj                  = array('IPK_MAX'   => $val);
				$PendidikanArray      = array_merge($PendidikanArray, $obj);
				}
				
			if($data['f_training']!='')
				{
				$enter   = nl2br($data['f_training']);
				$arr     = explode('<br />', $enter);
				$cln     = array();

				foreach ($arr as $row) 
				   {
				   $row = trim($row);

				   if($row!='')
					  {
					  $cln[$row] = $this->db->escape_str($row);
					  }  
				   }

				if(count($cln) > 0)
				   {
				   $data['f_training']    = implode(',', $cln);
				   }
				$val                  = array('value'    => $data['f_training']);
				$obj                  = array('TRAINING'   => $val);
				$PendidikanArray      = array_merge($PendidikanArray, $obj);
				}




		  // Filter Pengembangan Karir
			 if($data['f_histori_jabatan']!='')
			{
				$enter   = nl2br($data['f_histori_jabatan']);
				$arr     = explode('<br />', $enter);
				$cln     = array();

				foreach ($arr as $row) 
				   {
				   $row = trim($row);

				   if($row!='')
					  {
					  $cln[$row] = $this->db->escape_str($row);
					  }  
				   }

				if(count($cln) > 0)
				   {
				   $data['f_histori_jabatan']    = implode(',', $cln);
				   }

				$val        = array('value' => $data['f_histori_jabatan']);
				$obj        = array('HISTORI_JABATAN' => $val);
				$KarirArray    = array_merge($KarirArray, $obj);
				
			}

			 if($data['f_histori_uker']!='')
			{
				$enter   = nl2br($data['f_histori_uker']);
				$arr     = explode('<br />', $enter);
				$cln     = array();

				foreach ($arr as $row) 
				   {
				   $row = trim($row);

				   if($row!='')
					  {
					  $cln[$row] = $this->db->escape_str($row);
					  }  
				   }

				if(count($cln) > 0)
				   {
				   $data['f_histori_uker']    = implode(',', $cln);
				   }

				$val        = array('value' => $data['f_histori_uker']);
				$obj        = array('HISTORI_UKER' => $val);
				$KarirArray    = array_merge($KarirArray, $obj);
			}


		  // Filter Alamat
			 if($data['f_homebase']!='')
					{
					$val           = array('value'     => $data['f_homebase']);
					$obj           = array('HOMEBASE'  => $val);
					$AlamatArray   = array_merge($AlamatArray, $obj);
					}

			 if($data['f_domisili']!='')
					{
					$val           = array('value'     => $data['f_domisili']);
					$obj           = array('DOMISILI'  => $val);
					$AlamatArray   = array_merge($AlamatArray, $obj);
					}

				
			// Filter Assessment
			   if($data['f_rekomendasi_asesmen']!='')
				{
				$prog          = implode("','", $data['f_rekomendasi_asesmen']);
				$prog          = "'".$prog."'";
				$val           = array('value'         => $prog);
				$obj           = array('REKOMENDASI' => $val);
				$AsesmenArray      = array_merge($AsesmenArray, $obj);
				}
				
			   if($data['f_judul_assesment']!='')
				{
				$val 	         = array('value'    => $data['f_judul_assesment']);
				$obj 	         = array('JUDUL' 	    => $val);
				$AsesmenArray      = array_merge($AsesmenArray, $obj);
				}
			
			// Filter SMK
			   if($data['f_sko_min']!='')
				{
				$val           = array('value'    => $data['f_sko_min']);
				$obj           = array('SKO_MIN'   => $val);
				$SMKArray      = array_merge($SMKArray, $obj);
				}
			   if($data['f_sko_max']!='')
				{
				$val           = array('value'    => $data['f_sko_max']);
				$obj           = array('SKO_MAX'   => $val);
				$SMKArray      = array_merge($SMKArray, $obj);
				}
			   if($data['f_skk_min']!='')
				{
				$val           = array('value'    => $data['f_skk_min']);
				$obj           = array('SKK_MIN'   => $val);
				$SMKArray      = array_merge($SMKArray, $obj);
				}
			   if($data['f_skk_max']!='')
				{
				$val           = array('value'    => $data['f_skk_max']);
				$obj           = array('SKK_MAX'   => $val);
				$SMKArray      = array_merge($SMKArray, $obj);
				}
			   if($data['f_smk_min']!='')
				{
				$val           = array('value'    => $data['f_smk_min']);
				$obj           = array('SMK_MIN'   => $val);
				$SMKArray      = array_merge($SMKArray, $obj);
				}
			   if($data['f_smk_max']!='')
				{
				$val           = array('value'    => $data['f_smk_max']);
				$obj           = array('SMK_MAX'   => $val);
				$SMKArray      = array_merge($SMKArray, $obj);
				}
				if($data['f_tahun_smk']!='')
				{
				$val           = array('value'    => $data['f_tahun_smk']);
				$obj           = array('TAHUN_SMK'   => $val);
				$SMKArray      = array_merge($SMKArray, $obj);
				}
				
			//  Filter Kesehatan
			   if($data['f_jenis_klaim']!='')
				{
				$prog          = implode("','", $data['f_jenis_klaim']);
				$prog          = "'".$prog."'";
				$val           = array('value'         => $prog);
				$obj           = array('JENIS_KLAIM' => $val);
				$KesehatanArray      = array_merge($KesehatanArray, $obj);
				}
				
			// Filter ITP 
				if($data['f_itp_min']!='')
				{
				$val           = array('value'    => $data['f_itp_min']);
				$obj           = array('ITP_MIN'   => $val);
				$ITPArray      = array_merge($ITPArray, $obj);
				}
			   if($data['f_itp_max']!='')
				{
				$val           = array('value'    => $data['f_itp_max']);
				$obj           = array('ITP_MAX'   => $val);
				$ITPArray      = array_merge($ITPArray, $obj);
				}
				
				// Filter Insus
				if($data['f_insus']!='')
				{
				$prog          = implode("','", $data['f_insus']);
				$prog          = "'".$prog."'";
				$val           = array('value'         => $prog);
				$obj           = array('INSUS' => $val);
				$HBIArray      = array_merge($HBIArray, $obj);
				}
				
				
		   if(!empty($SDMArray))
				{
				$SDMObj 		   = array('SDM' => $SDMArray);
				$ALLArray 		= array_merge($ALLArray,$SDMObj);	
				}

		   if(!empty($PendidikanArray))
				 {
				 $PendidikanObj = array('PENDIDIKAN' => $PendidikanArray);
				 $ALLArray      = array_merge($ALLArray,$PendidikanObj);   
				 }

		   if(!empty($KarirArray))
				 {
				 $KarirObj      = array('MUTASI' => $KarirArray);
				 $ALLArray      = array_merge($ALLArray,$KarirObj);   
				 }

		   if(!empty($AlamatArray))
				 {
				 $AlamatObj     = array('ALAMAT' => $AlamatArray);
				 $ALLArray      = array_merge($ALLArray,$AlamatObj);   
				 }
			
			if(!empty($AsesmenArray))
				{
				$AsesmenObj 		   = array('ASSESSMENT' => $AsesmenArray);
				$ALLArray 		= array_merge($ALLArray,$AsesmenObj);	
				}
			if(!empty($SMKArray))
				{
				$SMKObj 		   = array('SMK' => $SMKArray);
				$ALLArray 		= array_merge($ALLArray,$SMKObj);	
				}
			if(!empty($KesehatanArray))
				{
				$KesehatanObj 		   = array('KESEHATAN' => $KesehatanArray);
				$ALLArray 		= array_merge($ALLArray,$KesehatanObj);	
				}
			if(!empty($ITPArray))
				{
				$ITPObj 		   = array('ITP' => $ITPArray);
				$ALLArray 		= array_merge($ALLArray,$ITPObj);	
				}
			if(!empty($HBIArray))
				{
				$HBIObj 		   = array('HBI' => $HBIArray);
				$ALLArray 		= array_merge($ALLArray,$HBIObj);	
				}
			if(!empty($ALLArray))
				{
				$ALLArray  		    = json_encode($ALLArray);
				$data['ALLArray'] = $ALLArray;
				$data['AllString'] = base64_encode($ALLArray);	
				}
			else
				{
				$data['ALLArray'] = '';	
				$data['AllString'] = '';	
				}
		return $data;
	}

   	public function validasi_template()
   	{
		$data = $this->generate_template();
   		$this->load->view('template/modal_refer_template',$data);
   	}



      public function check_duplikat_template()
      {
         $refer_template   = trim($this->input->post('refer_template'));
         $arr_template     = explode('/', $refer_template);
         if(isset($arr_template[1]))
            {
            if($this->template_model->cek_existing_tree(trim($arr_template[0])))
               {
               if($this->template_model->cek_duplikat_template(trim($arr_template[0])))
                  {
                  echo 1;
                  }
               else
                  {
                  echo 0;
                  }
               }
            else
               {
               echo 2;
               }
            }
         else
            {
            echo 2;   
            }
      }



   	public function simpan_template()
   	{
	   	$data['AllString'] 		= trim($this->input->post('AllString'));
	   	$data['refer_template']	= trim($this->input->post('refer_template'));
	   	$data['AllString'] 		= base64_decode($data['AllString']);
	   	$refer_template 		   = explode('/', $data['refer_template']);

	   	if(isset($refer_template[1]))
	   		{
	   		if($this->template_model->cek_existing_tree(trim($refer_template[0])))
	   			{
	   			$arrSimpan = array(	'id_template'		=> trim($refer_template[0]),
	   					   	   		'id_key'		 	   => '1',
	   					   	   		'key_search' 		=> $data['AllString'],
									'last_updated' 	=> date('Y-m-d H:i:s'),
	   					   	   		'updated_by' 		=> $_SESSION[$this->config->item('session_prefix')]['pernr'].'|'.$_SESSION[$this->config->item('session_prefix')]['nama'].'|'.$_SESSION[$this->config->item('session_prefix')]['stell_tx'],
                                    'token'           => $_SESSION[$this->config->item('session_prefix')]['token']);
				
		   		if($this->template_model->insert_template_pencarian($arrSimpan))
		   			{
		   			echo '<div class="alert alert-success" role="alert"> <strong> Berhasil Disimpan !</strong></div>';
		   			}
		   		else
		   			{
		   			echo '<div class="alert alert-danger" role="alert"> <strong> Gagal Disimpan !</strong></div>';
		   			}
	   			}
	   		else
	   			{
	   			echo '<div class="alert alert-danger" role="alert"><strong> Gagal Disimpan !</strong></div>';
	   			}
	   		}
	   	else
	   		{
	   		echo '<div class="alert alert-danger" role="alert"><strong> Gagal Disimpan !</strong></div>';
	   		}
   	}
	
	public function filter_template_pencarian()
	{
		$data = array();
		$this->load->view('template/filter_template_pencarian',$data);
	}
	
	public function template_pencarian() {         
		$this->form_validation->set_rules('f_keyword', 'Kata Kunci', 'trim');
		if($this->form_validation->run() == TRUE) {
			$filter['f_keyword'] 	= $this->input->post('f_keyword');
			if($filter['f_keyword'] != '') {
				$arr_term = explode('/',$filter['f_keyword']);
				$id = isset($arr_term[0])?trim($arr_term[0]):'';
				$param["a.id"] = array('AND',1,$id);
			}
			else{
				$param["a.id"] = array('AND',1,1);
			}
			$data['template'] = $this->konfigurasi_model->get_parent_template($param);
			if(count($data['template']) > 0)
				$this->load->view('template/template_pencarian',$data);
			else
				echo $this->libs->generate_message('danger','Data Tidak Ditemukan.');
		} else {
			echo '<center class="error message" style="cursor:pointer;">Parameter tidak valid.</center>';
		}
	}
	
	// public function get_child_template()
	// {
	// 	$id = $this->input->post('id');
	// 	$child = $this->konfigurasi_model->get_child_template($id);
	// 	$count = count($child);
	// 	if( $count > 0){
	// 		echo '<ul class="jstree-children" role="group">';
	// 		$last = '';
	// 		foreach($child as $idx => $ch){
	// 			$last = ($count == ($idx+1)) ? 'jstree-last' : '';
	// 			$li_id = "j" . $idx . '_' . rand();
	// 			echo '<li id="'.$li_id.'" class="jstree-node '.($ch->is_search == 0 ? "jstree-closed" : "jstree-leaf").' '.$last.'" role="treeitem" aria-selected="false" aria-level="2" aria-labelledby="'.$li_id.'_anchor" aria-expanded="false"><i class="jstree-icon jstree-ocl" role="presentation"></i>';
	// 			echo '<a class="jstree-anchor" href="#" tabindex="-1" id="'.$li_id.'_anchor"><i class="jstree-icon jstree-themeicon" role="presentation"></i><span class="ch_template to_child" rel="'.$ch->id.'" level="'.$ch->level.'" is_search="'.$ch->is_search.'">'.$ch->t_text.'</span>';
	// 			if($ch->is_search == 0)
	// 				echo '<table style="float:right;border-collapse:collapse;margin:-25px;" cellspacing="0px" cellpadding="0px" border="0"><tbody><tr><td width="360px" valign="top" align="right"><input value="Open" class="btn btn-xs btn-primary open" type="button">&nbsp;<input type="button" value="Edit" class="btn btn-xs btn-warning edit">&nbsp;</td></tr></tbody></table>';
				
	// 			echo '</a></li>';
	// 		}
	// 		echo '</ul>';
	// 	}
	// }
	
	public function show_filter_pencarian(){
		$id = $this->input->post('id');
		$data['template'] 				    = $this->konfigurasi_model->get_template($id);
		$data['filter'] 				       = $this->template_model->get_template_filter($id);
		$data['opt_mk_jabatan_uker'] 	    = $this->option_model->opt_mk_jabatan_uker();
   	$data['opt_mk_jg_pg'] 			    = $this->option_model->opt_mk_jg_pg();
   	$data['opt_jabatan'] 			    = $this->option_model->opt_jabatan();
   	$data['opt_program_masuk'] 		 = $this->option_model->opt_program_masuk();
		$data['opt_job_grade']        	 = $this->option_model->opt_job_grade();
      $data['opt_person_grade']     	 = $this->option_model->opt_person_grade();
		
		$is_process_done = $this->konfigurasi_model->check_process($id);
		
		if($is_process_done){
			if(isset($data['template']->t_text)){
				if(count($data['filter']) > 0){
					$data['status_template'] = true;
				}
				else{
					$data['status_template'] = false;
					$data['message'] = $this->libs->generate_message('danger','Filter Template Tidak Ditemukan.');
				}
			}
			else{
				$data['status_template'] = false;
				$data['message'] = $this->libs->generate_message('danger','Template Tidak Ditemukan.');
			}
		}
		else{
			$data['status_template'] = false;
			$data['message'] = $this->libs->generate_message('danger','Pencarian On Progress.');
		}
		$this->load->view('template/show_filter_pencarian',$data);
			
	}
	
// -----------------------------

	// function proses_pencarian(){
	// 	$data = array();
		
	// 	set_include_path(get_include_path().PATH_SEPARATOR.APPPATH.'third_party/phpseclib');

	// 	include(APPPATH.'/third_party/phpseclib/Net/SSH2.php');

	// 	$ssh = new Net_SSH2('10.35.65.113');

	// 	if (!$ssh->login('bripsb', 'awdx')) {
	// 		exit('Login Failed');
	// 	}

	// 	//echo $ssh->read('bripsb@PSB:~$');
	// 	$ssh->write("sudo -s\n");
	// 	//echo $ssh->read('[sudo] password for bripsb:');
	// 	$ssh->write("awdx\n");
	// 	//echo $ssh->read('root@PSB:~#');
	// 	//$ssh->exec("/usr/local/java/jdk1.8.0_25/bin/java -jar /usr/local/java/jar/pencarian_pekerja.jar 4 00136134_2016_09_29_10_10_59 00136134 >> /home/administrator/backup_log/pencarian_pekerja.log");
	// 	//$ssh->exec("/usr/local/java/sh/exec_jar_sipo_payroll.sh");
	// 	$ssh->exec("/usr/local/java/sh/pencarian_pekerja.sh >> /home/administrator/backup_log/pencarian_pekerja.log &");
		
	// 	//die;
	// 	sleep(3);
		
	// 	//$this->auditrail_model->add_log("Run Payroll", $data['periode_time'] . ' - ' . $data['vendor_run']);
	// 	$this->auditrail_model->add_log('Pencarian', 'Melakukan Pencarian');
	// 	//$data['check_variable'] = $this->payroll_model->get_payroll_run(1);
				
	// 	$process_log = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_processlog LIMIT 0,1");
	// 	$error_log = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_errorlogs LIMIT 0,1");

	// 	if(count($process_log->row()) > 0) {
	// 		$data['process_log'] = $process_log->row()->text;
	// 		$data['time_start_payroll'] = $process_log->row()->start;
	// 		$data['time_end_payroll'] = $process_log->row()->end;
			
	// 		//get diff time
	// 		$today = date('Y-m-d H:i:s');
	// 		$data['now'] = $today;
	// 		$date_start = new DateTime($process_log->row()->start);
			
	// 		if($process_log->row()->text == 'Pencarian DONE!' || $error_log->row()->text != '') {
	// 			$date_end = new DateTime($process_log->row()->end);
	// 			$diff = date_diff($date_end, $date_start);
	// 		} else {
	// 			$date_now = new DateTime($today);	
	// 			$diff = date_diff($date_now, $date_start);
	// 		}
			
	// 		$data['diff'] = $diff->format('%H:%I:%S');
			
	// 		$q_progress = $this->general_model->exec_general_query_with_connection("default", "SELECT prosentase FROM pencarian_progress WHERE progress = '". trim($process_log->row()->text) ."'");

	// 		if(count($q_progress->row()) > 0) {
	// 			$data['progress_done'] = $q_progress->row()->prosentase;
	// 		} else {
	// 			$data['progress_done'] = 0;
	// 		}
	// 	}
		
	// 	if(count($error_log->row()) > 0) {
	// 		$data['error_log'] = $error_log->row()->text;
	// 	}
		
	// 	$data['pencarian_exist'] = true;
	// 	$data['message'] = $this->libs->generate_message('success','Pencarian Dijalankan.');
	// 	$this->load->view('template/run_pencarian', $data);
				
	// }
	
	// function pencarian_progress_refresh(){
				
	// 	$process_log = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_processlog LIMIT 0,1");
	// 	$error_log = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_errorlogs LIMIT 0,1");

	// 	if(count($process_log->row()) > 0) {
	// 		$data['process_log'] = $process_log->row()->text;
	// 		$data['time_start_payroll'] = $process_log->row()->start;
	// 		$data['time_end_payroll'] = $process_log->row()->end;
			
	// 		//get diff time
	// 		$today = date('Y-m-d H:i:s');
	// 		$data['now'] = $today;
	// 		$date_start = new DateTime($process_log->row()->start);
			
	// 		if($process_log->row()->text == 'Payroll DONE!' || $error_log->row()->text != '') {
	// 			$date_end = new DateTime($process_log->row()->end);
	// 			$diff = date_diff($date_end, $date_start);
	// 		} else {
	// 			$date_now = new DateTime($today);	
	// 			$diff = date_diff($date_now, $date_start);
	// 		}
			
	// 		$data['diff'] = $diff->format('%H:%I:%S');
			
	// 		$q_progress = $this->general_model->exec_general_query_with_connection("default", "SELECT prosentase FROM pencarian_progress WHERE progress = '". trim($process_log->row()->text) ."'");

	// 		if(count($q_progress->row()) > 0) {
	// 			$data['progress_done'] = $q_progress->row()->prosentase.' %';
	// 		} else {
	// 			$data['progress_done'] = '0 %';
	// 		}
	// 	}
		
	// 	if(count($error_log->row()) > 0) {
	// 		$data['error_log'] = $error_log->row()->text;
	// 	}
	// 	$data['pencarian_exist'] = true;
	// 	$data['message'] = $this->libs->generate_message('success','Pencarian Dijalankan.');
	// 	$this->load->view('template/run_pencarian_refresh', $data);
	// }


//-------------------------------------------


   public function proses_pencarian()
   {
		$id_template = $this->input->post('id_template');
		$is_process_done = $this->konfigurasi_model->check_process($id_template);
		
		if($is_process_done){
			  $param = array(
							'token' => $_SESSION[$this->config->item('session_prefix')]['token'],
							'id_template' => $id_template,
							'searched_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'],
							'date_modified' => date('Y-m-d H:i:s'),
							'periode' => (date('m') . date('Y'))
						);
						
			  $set_param = $this->template_model->set_parameter($param);
			  
			  if($set_param){
					  set_include_path(get_include_path().PATH_SEPARATOR.APPPATH.'third_party/phpseclib');

					  include(APPPATH.'/third_party/phpseclib/Net/SSH2.php');

					  $ssh = new Net_SSH2('10.35.65.113');

					  if (!$ssh->login('bripsb', 'P@ssw0rd113')) {
						 exit('Login Failed');
					  }

					  $ssh->write("sudo -s\n");
					  $ssh->write("P@ssw0rd113\n");
					  $ssh->exec("/usr/local/java/sh/pencarian_pekerja_explore.sh >> /home/administrator/backup_log/pencarian_pekerja.log &");

					  sleep(2);

					  $this->auditrail_model->add_log('Pencarian', 'Melakukan Pencarian');            
					  $process_log   = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_processlog where id_template =  {$id_template} LIMIT 0,1");
					  $error_log     = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_errorlogs LIMIT 0,1");


					  $today = date('Y-m-d H:i:s');
					  $data['now'] = $today;
					  $date_start = new DateTime($process_log->row()->start);
						 
					  if($process_log->row()->text == 'Payroll DONE!' || $error_log->row()->text != '') 
						 {
						 $date_end = new DateTime($process_log->row()->end);
						 $diff = date_diff($date_end, $date_start);
						 } 
					  else 
						 {
						 $date_now = new DateTime($today);   
						 $diff = date_diff($date_now, $date_start);
						 }
						 
					  $elapse = $diff->format('%H:%I:%S');
					 

					  if(count($process_log->row()) > 0){
						 $progress_text = $process_log->row()->text;
						 $mst_progress  = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_progress WHERE progress LIKE '%{$progress_text}%' LIMIT 0,1");

						 $arrProgress = array('progress_text' => $progress_text,
											  'prosentase'    => $mst_progress->row()->prosentase,
											  'start_process' => $process_log->row()->start,
											  'end_process'   => $process_log->row()->end,
											  'elapse_time'   => $elapse,
											  'error_log'     => $error_log->row()->text);
					  }
					  else{
						 $arrProgress = array('progress_text' => '',
											  'prosentase'    => 100,
											  'start_process' => '',
											  'end_process'   => '',
											  'elapse_time'   => $elapse,
											  'error_log'     => '');
					 }
				 }
				 else{
					$arrProgress = array('progress_text' => '',
										  'prosentase'    => 100,
										  'start_process' => '',
										  'end_process'   => '',
										  'elapse_time'   => $elapse,
										  'error_log'     => '1',
										  'error_msg'	  => 'Gagal Set Parameter.');
				 }
				 
			 }
			 else{
				$arrProgress = array('progress_text' => '',
										  'prosentase'    => 100,
										  'start_process' => '',
										  'end_process'   => '',
										  'elapse_time'   => $elapse,
										  'error_log'     => '1',
										  'error_msg'	  => 'Template Pencarian Sedang Digunakan.');
			 }
			 
			 echo json_encode($arrProgress);
   }

   public function proses_pencarian_go()
   {
		$data = $this->generate_template();
		$ALLArray = $data['ALLArray'];
		$arrSimpan = array(	'id_template'		=> 0,
							'id_key'		 	   => '1',
							'key_search' 		=> $ALLArray,
							'last_updated' 	=> date('Y-m-d H:i:s'),
							'updated_by' 		=> $_SESSION[$this->config->item('session_prefix')]['pernr'].'|'.$_SESSION[$this->config->item('session_prefix')]['nama'].'|'.$_SESSION[$this->config->item('session_prefix')]['stell_tx'],
							'token'           => $_SESSION[$this->config->item('session_prefix')]['token']);
	
		if($this->template_model->insert_template_pencarian_go($arrSimpan)){
		
			$id_template = 0;
			$token = $_SESSION[$this->config->item('session_prefix')]['token'];
			
			$is_process_done = $this->konfigurasi_model->check_process_go($id_template, $token);
			
			if($is_process_done){
				  $param = array(
								'token' => $token,
								'id_template' => $id_template,
								'searched_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'],
								'date_modified' => date('Y-m-d H:i:s'),
								'periode' => (date('m') . date('Y'))
							);
							
				  $set_param = $this->template_model->set_parameter_go($param);
				  
				  if($set_param){
						  set_include_path(get_include_path().PATH_SEPARATOR.APPPATH.'third_party/phpseclib');

						  include(APPPATH.'/third_party/phpseclib/Net/SSH2.php');

						  $ssh = new Net_SSH2('10.35.65.113');

						  if (!$ssh->login('bripsb', 'P@ssw0rd113')) {
							 exit('Login Failed');
						  }

						  $ssh->write("sudo -s\n");
						  $ssh->write("P@ssw0rd113\n");
						  $ssh->exec("/usr/local/java/sh/pencarian_pekerja_go_explore.sh >> /home/administrator/backup_log/pencarian_pekerja_go.log &");

						  sleep(2);

						  $this->auditrail_model->add_log('Pencarian', 'Melakukan Pencarian Go');            
						  $process_log   = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_processlog where id_template = {$id_template} and token = '{$token}' LIMIT 0,1");
						  $error_log     = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_errorlogs LIMIT 0,1");


						  $today = date('Y-m-d H:i:s');
						  $data['now'] = $today;
						  $date_start = new DateTime($process_log->row()->start);
							 
						  if($process_log->row()->text == 'Payroll DONE!' || $error_log->row()->text != '') 
							 {
							 $date_end = new DateTime($process_log->row()->end);
							 $diff = date_diff($date_end, $date_start);
							 } 
						  else 
							 {
							 $date_now = new DateTime($today);   
							 $diff = date_diff($date_now, $date_start);
							 }
							 
						  $elapse = $diff->format('%H:%I:%S');
						 

						  if(count($process_log->row()) > 0){
							 $progress_text = $process_log->row()->text;
							 $mst_progress  = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_progress WHERE progress LIKE '%{$progress_text}%' LIMIT 0,1");

							 $arrProgress = array('progress_text' => $progress_text,
												  'prosentase'    => $mst_progress->row()->prosentase,
												  'start_process' => $process_log->row()->start,
												  'end_process'   => $process_log->row()->end,
												  'elapse_time'   => $elapse,
												  'error_log'     => $error_log->row()->text);
						  }
						  else{
							 $arrProgress = array('progress_text' => '',
												  'prosentase'    => 100,
												  'start_process' => '',
												  'end_process'   => '',
												  'elapse_time'   => $elapse,
												  'error_log'     => '');
						 }
					 }
					 else{
						$arrProgress = array('progress_text' => '',
											  'prosentase'    => 100,
											  'start_process' => '',
											  'end_process'   => '',
											  'elapse_time'   => $elapse,
											  'error_log'     => '1',
											  'error_msg'	  => 'Gagal Set Parameter.');
					 }
					 
				 }
				 else{
					$arrProgress = array('progress_text' => '',
											  'prosentase'    => 100,
											  'start_process' => '',
											  'end_process'   => '',
											  'elapse_time'   => $elapse,
											  'error_log'     => '1',
											  'error_msg'	  => 'Template Pencarian Sedang Digunakan.');
				 }
		 }
		 else{
			$arrProgress = array('progress_text' => '',
											  'prosentase'    => 100,
											  'start_process' => '',
											  'end_process'   => '',
											  'elapse_time'   => 0,
											  'error_log'     => '1',
											  'error_msg'	  => 'Terdapat Kesalahan dalam Pengisian Parameter.');
		 }
		 echo json_encode($arrProgress);
   }

	/*public function proses_pencarian(){
			$error = false;
			$is_process_done = $this->konfigurasi_model->check_process();
			$param = array(
						'token' => $_SESSION[$this->config->item('session_prefix')]['token'],
						'id_template' => $this->input->post('id_template'),
						'searched_by' => $_SESSION[$this->config->item('session_prefix')]['pernr'],
						'date_modified' => date('Y-m-d H:i:s')
					);
					
			$data['template'] 	= $this->konfigurasi_model->get_template($param['id_template']);
			$data['filter'] 	= $this->template_model->get_template_filter($param['id_template']);
			$data['status_template'] = true;
			$set_param = $this->template_model->set_parameter($param);
		  
		  if($set_param){
				  $this->auditrail_model->add_log('Pencarian', 'Melakukan Pencarian');
				  set_include_path(get_include_path().PATH_SEPARATOR.APPPATH.'third_party/phpseclib');

				  include(APPPATH.'/third_party/phpseclib/Net/SSH2.php');

				  $ssh = new Net_SSH2('10.35.65.113');

				  if (!$ssh->login('bripsb', 'awdx')) {
					 exit('Login Failed');
				  }

				  $ssh->write("sudo -s\n");
				  $ssh->write("awdx\n");
				  $ssh->exec("/usr/local/java/sh/pencarian_pekerja.sh >> /home/administrator/backup_log/pencarian_pekerja.log &");
			 }
			 else{
				$data['status_template'] = false;
				$data['message'] = $this->libs->generate_message('danger','Gagal Set Parameter.');
			 }
			 
			$this->load->view('template/run_pencarian', $data);
   }*/

   public function pencarian_progress_refresh()
   {
		$id_template = $this->input->post('id_template');
      $process_log   = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_processlog where id_template =  {$id_template} and token = '{$_SESSION[$this->config->item('session_prefix')]['token']}' LIMIT 0,1");
      $error_log     = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_errorlogs LIMIT 0,1");

      $today = date('Y-m-d H:i:s');
      $data['now'] = $today;
      $date_start = new DateTime($process_log->row()->start);
         
      if($process_log->row()->text == 'Payroll DONE!' || $error_log->row()->text != '') 
         {
         $date_end = new DateTime($process_log->row()->end);
         $diff = date_diff($date_end, $date_start);
         } 
      else 
         {
         $date_now = new DateTime($today);   
         $diff = date_diff($date_now, $date_start);
         }
         
      $elapse = $diff->format('%H:%I:%S');
         if(count($process_log->row()) > 0) 
            {
            $progress_text = $process_log->row()->text;
            $mst_progress  = $this->general_model->exec_general_query_with_connection("default", "SELECT * FROM pencarian_progress WHERE progress LIKE '%{$progress_text}%' LIMIT 0,1");

            $arrProgress = array('progress_text' => $progress_text,
                                 'prosentase'    => $mst_progress->row()->prosentase,
                                 'start_process' => $process_log->row()->start,
                                 'end_process'   => $process_log->row()->end,
                                 'elapse_time'   => $elapse,
                                 'error_log'     => $error_log->row()->text);
            }
         else
            {
            $arrProgress = array('progress_text' => '',
                                 'prosentase'    => 100,
                                 'start_process' => '',
                                 'end_process'   => '',
                                 'elapse_time'   => $elapse,
                                 'error_log'     => '');
            }

         echo json_encode($arrProgress);
   }

	


	public function get_str_sort($data){
		$sort_by = '';
		if($data['f_sort_pernr'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_pernr'] == 1)
				$sort_by .= ' pernr asc';
			else
				$sort_by .= ' pernr desc';
		}
		if($data['f_sort_jabatan'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_jabatan'] == 1)
				$sort_by .= ' htext asc';
			else
				$sort_by .= ' htext desc';
		}
		if($data['f_sort_jg'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_jg'] == 1)
				$sort_by .= ' jg desc';
			else
				$sort_by .= ' jg asc';
		}
		if($data['f_sort_pg'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_pg'] == 1)
				$sort_by .= ' pg desc';
			else
				$sort_by .= ' pg asc';
		}
		if($data['f_sort_usia'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_usia'] == 1)
				$sort_by .= ' FLOOR(DATEDIFF(searched_date,STR_TO_DATE(TANGGALLAHIR, "%Y-%m-%d"))/365) desc';
			else
				$sort_by .= ' FLOOR(DATEDIFF(searched_date,STR_TO_DATE(TANGGALLAHIR, "%Y-%m-%d"))/365) asc';
		}
		if($data['f_sort_mke'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_mke'] == 1)
				$sort_by .= ' BULAN_MKE desc';
			else
				$sort_by .= ' BULAN_MKE asc';
		}
		if($data['f_sort_mkj'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_mkj'] == 1)
				$sort_by .= ' BULAN_MKJ desc';
			else
				$sort_by .= ' BULAN_MKJ asc';
		}
		if($data['f_sort_mkjg'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_mkjg'] == 1)
				$sort_by .= ' BULAN_MKJG desc';
			else
				$sort_by .= ' BULAN_MKJG asc';
		}
		if($data['f_sort_mkpg'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_mkpg'] == 1)
				$sort_by .= ' BULAN_MKPG desc';
			else
				$sort_by .= ' BULAN_MKPG asc';
		}
		if($data['f_sort_mku'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_mku'] == 1)
				$sort_by .= ' BULAN_MKU desc';
			else
				$sort_by .= ' BULAN_MKU asc';
		}
		if($data['f_sort_ipk'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_ipk'] == 1)
				$sort_by .= ' ipk_last desc';
			else
				$sort_by .= ' ipk_last asc';
		}
		if($data['f_sort_itp'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_itp'] == 1)
				$sort_by .= ' itp_last desc';
			else
				$sort_by .= ' itp_last asc';
		}
		if($data['f_sort_smk'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_smk'] == 1)
				$sort_by .= ' nilai_smk_last desc';
			else
				$sort_by .= ' nilai_smk_last asc';
		}
		if($data['f_sort_sko'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_sko'] == 1)
				$sort_by .= ' nilai_sko_last desc';
			else
				$sort_by .= ' nilai_sko_last asc';
		}
		if($data['f_sort_skk'] <> ''){
			if($sort_by <> '')
				$sort_by .= ', ';
			if($data['f_sort_skk'] == 1)
				$sort_by .= ' nilai_skk_last desc';
			else
				$sort_by .= ' nilai_skk_last asc';
		}
		return $sort_by;
	}
	
   public function show_hasil_pencarian()
   {
		$data['f_sort_pernr'] 		= trim($this->input->post('f_sort_pernr'));
		$data['f_sort_jabatan'] 	= trim($this->input->post('f_sort_jabatan'));
		$data['f_sort_jg'] 			= trim($this->input->post('f_sort_jg'));
		$data['f_sort_pg'] 			= trim($this->input->post('f_sort_pg'));
		$data['f_sort_usia'] 		= trim($this->input->post('f_sort_usia'));
		$data['f_sort_mke'] 		= trim($this->input->post('f_sort_mke'));
		$data['f_sort_mkj'] 		= trim($this->input->post('f_sort_mkj'));
		$data['f_sort_mkjg'] 		= trim($this->input->post('f_sort_mkjg'));
		$data['f_sort_mkpg'] 		= trim($this->input->post('f_sort_mkpg'));
		$data['f_sort_mku'] 		= trim($this->input->post('f_sort_mku'));
		$data['f_sort_ipk'] 		= trim($this->input->post('f_sort_ipk'));
		$data['f_sort_itp'] 		= trim($this->input->post('f_sort_itp'));
		$data['f_sort_smk'] 		= trim($this->input->post('f_sort_smk'));
		$data['f_sort_sko'] 		= trim($this->input->post('f_sort_sko'));
		$data['f_sort_skk'] 		= trim($this->input->post('f_sort_skk'));
		$data['f_rekomendasi_asesmen'] 		= $this->input->post('f_rekomendasi_asesmen');
		
		$data['opt_rekomendasi_asesmen']            = $this->option_model->opt_rekomendasi_asesmen();
		
		$param = array();
		$param[] = $this->libs->arrWhere('AND','token',"{$_SESSION[$this->config->item('session_prefix')]['token']}",'1','=');
		$param[] = $this->libs->arrWhere('AND','id_template',"0",'1','=');

		if($data['f_rekomendasi_asesmen'] <> ''){
			$param[] = $this->libs->arrWhere('AND','rekomendasi_last',$data['f_rekomendasi_asesmen'],'1','IN');
			$_SESSION[$this->config->item('session_prefix')]['f_rekom'] = $this->libs->arrWhere('AND','rekomendasi_last',$data['f_rekomendasi_asesmen'],'1','IN');
		}
		
		$sort_by = $this->get_str_sort($data);
		
      /****Paging****/  
      $config['base_url']           = site_url('template/show_hasil_pencarian');
      $config['uri_segment']        = 3;
      $config['total_rows']         = $this->template_model->get_hasil_pencarian(TRUE,$param);
      $config['per_page']           = 15;
      $config['first_page']         = 'First';  
      $config['last_page']          = 'Last';
      $config['next_page']          = '&laquo;';
      $config['prev_page']          = '&raquo;';
      $config['use_page_numbers']   = TRUE;

      $config['full_tag_open']      = "<ul class='pagination'>";
      $config['full_tag_close']     = "</ul>";
      $config['num_tag_open']       = "<li class='page'>";
      $config['num_tag_close']      = "</li>";
      $config['cur_tag_open']       = "<li class='disabled'><li class='active'><a href='#'>";
      $config['cur_tag_close']      = "<span class='sr-only'></span></a></li>";
      $config['next_tag_open']      = "<li class='page'>";
      $config['next_tagl_close']    = "</li>";
      $config['prev_tag_open']      = "<li class='page'>";
      $config['prev_tagl_close']    = "</li>";
      $config['first_tag_open']     = "<li class='page'>";
      $config['first_tagl_close']   = "</li>";
      $config['last_tag_open']      = "<li class='page'>";
      $config['last_tagl_close']    = "</li>";

      $config['suffix']          = (http_build_query($_GET)==''?'':'?'.http_build_query($_GET));
      $config['first_url']       = $config['base_url'].$config['suffix'];
      $subdata['jml_hal']        = ceil($config['total_rows']/$config['per_page']);

      if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) 
         {$rowpos = 0;} 
      else 
         {
         $rowpos = ($this->uri->segment($config['uri_segment']) > $subdata['jml_hal'])?$subdata['jml_hal']:$this->uri->segment($config['uri_segment']);
         $rowpos = (($rowpos-1) * $config['per_page']);
         }

      $limits  = $config['per_page'];
      $rowpos = $rowpos<0?0:$rowpos;
      $this->pagination->initialize($config);
      $data['paging'] = $this->pagination->create_links();
      /*******end of style paging ********/

      $data['no'] = $rowpos+1;
	  
		$data['hasil_pencarian'] = $this->template_model->get_hasil_pencarian(false,$param,$sort_by,$rowpos,$limits);
	  
		$this->load->view('template/hasil_template_pencarian',$data);
   }



   public function load_form_simpan_hasil_pencarian()
   {
      $this->load->view('template/form_simpan_hasil_pencarian');
   }

	public function load_form_simpan_non_template()
   {
      $this->load->view('template/form_simpan_non_template');
   }

   public function cek_duplikat_hasil_pencarian()
   {
      $data['judul']          = trim($this->input->post('judul'));
      $data['id_template']    = trim($this->input->post('id_template'));

      $today = date('d-m-Y');
      $judul = $data['judul'].' ('.$today.')';

      $duplikat = $this->template_model->cek_duplikat_hasil_pencarian($data['id_template'],$judul);

      if($duplikat->num_rows>0)
         {
         echo 1;
         }
      else
         {
         echo 0;
         }
   }



   public function simpan_hasil_pencarian()
   {
      $data['judul']          = trim($this->input->post('judul'));
      $data['id_template']    = trim($this->input->post('id_template'));

      $today = date('d-m-Y');
      $judul = $data['judul'].' ('.$today.')';

      $id_parent = explode("/", $data['id_template']);
	  $id_parent = isset($id_parent[0]) ? trim($id_parent[0]) : '1';
      $tree    = $this->template_model->get_tree_template_by_id($id_parent);

      $arrTree = array('t_text'        => $judul,
                       'level'         => $tree->level+1,
                       'parent'        => $id_parent,
                       'status'        => '1',
                       'is_search'     => '1',
					   'area' => $_SESSION[$this->config->item('session_prefix')]['pa'],	
					   'subarea' => $_SESSION[$this->config->item('session_prefix')]['psa'],
					   'tipe_uker' => $_SESSION[$this->config->item('session_prefix')]['tipe_uker'],
                       'last_updated'  => date('Y-m-d H:i:s'),
                       'updated_by'    => $_SESSION[$this->config->item('session_prefix')]['pernr'].'|'.$_SESSION[$this->config->item('session_prefix')]['nama'].'|'.$_SESSION[$this->config->item('session_prefix')]['stell_tx'],
					   'periode' => (date('m') . date('Y'))
					   );
  

      if($this->template_model->simpan_hasil_pencarian($arrTree))
         {
         $data['message'] = $this->libs->generate_message('success','Berhasil Disimpan.');
         }
      else
         {
         $data['message'] = $this->libs->generate_message('danger','Gagal Disimpan.');
         }

      echo $data['message'];
   }



   public function csv($array) {
      $csv = implode(',', $array);
      $newline = "\n";
      return $newline.$csv;
   }




   public function create_csv_hasil_pencarian()
   {
      $file_name  = 'Untitled';

      header("Pragma: no-cache");
      header("Expires: 0");
      header('Content-Type: application/csv');
      header('Content-disposition: attachment; filename='.$file_name.'.csv');

      $param = array();
      $param[] = $this->libs->arrWhere('AND','id_template',"0",'1','=');
      $param[] = $this->libs->arrWhere('AND','token',"{$_SESSION[$this->config->item('session_prefix')]['token']}",'1','=');
	  if(isset($_SESSION[$this->config->item('session_prefix')]['f_rekom'])){
			$param[] = $_SESSION[$this->config->item('session_prefix')]['f_rekom'];
		}
		$sort_by = $_SESSION[$this->config->item('session_prefix')]['sort_by'];
       $hasil_pencarian = $this->template_model->get_hasil_pencarian(false,$param,$sort_by);


       $data_array   = array("NO", "PERNR", "NIP", "NAMA", "JENIS KELAMIN", "TEMPAT LAHIR", "TANGGAL LAHIR", "USIA", "AGAMA", "TGL MASUK BRI", "PROGRAM MASUK", "JABATAN" , "KELOMPOK JABATAN", "JGPG", "STATUS PEKERJA", "PERSONNEL SUBAREA", "PERSONNEL AREA", "TMT PT/PS", "MKE", "MKJ", "MKPG", "MKJG", "MKU", "NILAI SMK LAST", "NILAI SKO LAST", "NILAI SKK LAST", "REKOMENDASI LAST", "IPK LAST", "ITP LAST");
      echo $this->csv($data_array);
       $no=1;
       foreach ($hasil_pencarian as $row) 
         {
         $jk = $row->JK == 'P' ? 'Perempuan' : 'Laki-laki' ;
         $tanggal_lahir =  date("Y-m-d", strtotime($row->TANGGALLAHIR));
         $usia = $this->libs->get_age($row->TANGGALLAHIR);
         $tmt_masuk = date("Y-m-d", strtotime($row->TMT_MASUK));
         $tmt_pt = date("Y-m-d", strtotime($row->TMT_PT));

         $data_array    = array($no, str_replace(',',' ', $row->PERNR), str_replace(',',' ', $row->NIP),str_replace(',', ' ', $row->SNAME) ,$jk ,str_replace(',', ' ', $row->TEMPATLAHIR), $tanggal_lahir, $usia, $row->AGAMA, $tmt_masuk, str_replace(',',' ', $row->PROGRAM_MASUK),  str_replace(',',' ', $row->STELL_TX), str_replace(',',' ', $row->HTEXT), $row->JGPG, str_replace(',',' ', $row->STATUS),str_replace(',',' ', $row->BTRTL_TX) ,str_replace(',',' ', $row->WERKS_TX) , $tmt_pt, str_replace(',',' ', $row->MK_MKE), str_replace(',',' ', $row->MK_MKJ), str_replace(',',' ', $row->MK_MKPG), str_replace(',',' ', $row->MK_MKJG), str_replace(',',' ', $row->MK_MKU), str_replace(',',' ', $row->nilai_smk_last), str_replace(',',' ', $row->nilai_sko_last), str_replace(',',' ', $row->nilai_skk_last), str_replace(',',' ', $row->rekomendasi_last), str_replace(',',' ', $row->ipk_last), str_replace(',',' ', $row->itp_last));
         echo $this->csv($data_array);
         $no++;
         }
       
   }
   
   public function edit_template_pencarian(){
		$data['opt_mk_jabatan_uker'] 	= $this->option_model->opt_mk_jabatan_uker();
   		$data['opt_mk_jg_pg'] 			= $this->option_model->opt_mk_jg_pg();
   		$data['opt_jabatan'] 			= $this->option_model->opt_jabatan();
		$data['opt_program_masuk'] 		= $this->option_model->opt_program_masuk();
        $data['opt_job_grade']        	= $this->option_model->opt_job_grade();
        $data['opt_person_grade']     	= $this->option_model->opt_person_grade();
        $data['opt_agama']            	= $this->option_model->opt_agama();
        $data['opt_rekomendasi_asesmen']    = $this->option_model->opt_rekomendasi_asesmen();
        $data['opt_jenis_klaim']            = $this->option_model->opt_jenis_klaim();
        $data['opt_insus']            		= $this->option_model->opt_get_insus();
		
		$id = $this->input->post('id');
		$data['template'] 				    = $this->konfigurasi_model->get_template($id);
		$data['filter'] 				    = $this->template_model->get_template_filter($id);
		 
		 
		if(isset($data['template']->t_text)){
			if(count($data['filter']) > 0){
				$data['status_template'] = true;
			}
			else{
				$data['status_template'] = false;
				$data['message'] = $this->libs->generate_message('danger','Filter Template Tidak Ditemukan.');
			}
		}
		else{
			$data['status_template'] = false;
			$data['message'] = $this->libs->generate_message('danger','Template Tidak Ditemukan.');
		}
		
   		$this->load->view('template/edit_pencarian_pekerja',$data);
   }
   
   public function update_template_pencarian(){
		$data = $this->generate_template();
		$filter_id = $this->input->post('filter_id');
		$condition = array('id' => $filter_id);
		$parameter = array(	'id_key'			=> '1',
							'key_search' 		=> $data['ALLArray'],
							'last_updated' 		=> date('Y-m-d H:i:s'),
							'updated_by' 		=> $_SESSION[$this->config->item('session_prefix')]['pernr'].'|'.$_SESSION[$this->config->item('session_prefix')]['nama'].'|'.$_SESSION[$this->config->item('session_prefix')]['stell_tx'],
							'token'           	=> $_SESSION[$this->config->item('session_prefix')]['token']);
		
		$update = $this->template_model->update_template_pencarian($parameter, $condition);
		if($update){
			$this->auditrail_model->add_log('Update Filter Template', 'Melakukan Update Template Filter ID = ' . $filter_id);
			echo $this->libs->generate_message('success','Data Berhasil Disimpan.');
		}
		else{
			echo $this->libs->generate_message('danger','Data Gagal Disimpan.');
		}
   }
}
