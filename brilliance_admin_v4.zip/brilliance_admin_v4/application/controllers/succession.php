<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Succession extends CI_Controller {
	public function __construct()
   	{
		parent::__construct();
		// Your own constructor code
		
		$this->mysession->check_no_session();
		$this->mysession->check_session_expired();
		$this->load->model(array('access_menu_model', 'user_model', 'succession_model', 'setting_model', 'pegawai_model', 'hasil_model', 'talent_model', 'option_model'));
   	}
	
	public function succession_plan(){
		$filter['f_orgunit'] = trim($this->input->post('f_orgunit'));
		if(strpos($filter['f_orgunit'],'/')!==FALSE){
			$arr_term = explode('/',$filter['f_orgunit']);
			$kode = isset($arr_term[0])?trim($arr_term[0]):'';
		}else{
			$kode = $filter['f_orgunit'];
		}
		
		$data['filter'] = $filter;
		$data['title'] = "Struktur Organisasi BRI";
		if($kode!=''){
			$param[] = $this->libs->arrWhere('AND','a.CHILD',$kode);
		}else{
			$param[] = $this->libs->arrWhere('AND','a.LEVEL',array(0,1,2),0,'IN');
		}
		$param[] = $this->libs->arrWhere('AND','CURDATE()','a.STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','a.ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','a.FLAG',1);
		$tree = $this->setting_model->get_filled_os(false, $param, 'a.LEVEL ASC, a.CHILD ASC');
		$data['arr_tree'] = array();
		$smallest_level = $parent = '';
		foreach($tree as $row){
			if($smallest_level!=$row->LEVEL && $smallest_level==''){
				$smallest_level = $row->LEVEL;
			}
			if($parent!=$row->PARENT && $parent==''){
				$parent = $row->PARENT;
			}
			$data['arr_tree'][$row->LEVEL][$row->PARENT][$row->CHILD] = array('STARTDATE'=>$row->STARTDATE, 'ENDDATE'=>$row->ENDDATE,'MYNAME'=>$row->MYNAME,'PARENTNAME'=>$row->PARENTNAME,'LEVEL'=>$row->LEVEL,'CHILD'=>$row->CHILD,'PARENT'=>$row->PARENT);
		}
		
		if(!empty($data['arr_tree'])){
			$smallest_level = $smallest_level!=''?$smallest_level:0;
			$parent = $parent!=''?$parent:'00000001';
			$data['tree'] = $this->generate_tree_so($data['arr_tree'],$parent,0,$smallest_level);
		}
		$this->load->view('succession/succession_plan', $data);
	}

	private function generate_tree_so($arr_tree,$parent,$counter,$level)
	{
		$html = '';
		if(isset($arr_tree[$level])){
			if(isset($arr_tree[$level][$parent])){
				if(is_array($arr_tree[$level][$parent])){
					if($counter=='' || $counter=='0'){
						$html .= '<ul id="organization">';
					}else{
						$html .= '<ul id="child">';
					}
					$tmp_arr = $arr_tree[$level][$parent];
					$counter++;
					$level++;
					foreach($tmp_arr as $id=>$val){
						$kode_parent = isset($val['PARENT'])?trim($val['PARENT']):'';
						$kode_org_unit = isset($val['CHILD'])?trim($val['CHILD']):'';
						$nama_orgunit = trim($val['MYNAME']);
						$level_curr = isset($val['LEVEL'])?trim($val['LEVEL']):'';
						if($level_curr > 8){
							$level_curr = 8;
						}
						$title = base64_encode('('.$kode_org_unit.') '.$nama_orgunit);
						if(isset($arr_tree[$level][$id])){
							$html .= '<li id="'.$kode_org_unit.'" title="'.$kode_org_unit.'" class="level-'.$level_curr.'">'.$nama_orgunit;
							$html .= $this->generate_tree_so($arr_tree,$id,$counter,$level);
							$html .= '</li>';
						}else{
							$html .= '<li id="'.$kode_org_unit.'" title="'.$kode_org_unit.'" class="level-'.$level_curr.'">'.$nama_orgunit.'<ul></ul></li>';
						}
					}
					$html .= '</ul>';
				}
			}
		}else{
			$html .= '<ul id="organization"></ul>';
		}
		return $html;
	}

	public function show_keyjobs(){
		$data = array();
		$param = array();
		$orgeh = trim($this->input->post('organization'));
		$param[] = $this->libs->arrWhere('AND','CURDATE()','a.startdate',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','a.enddate',0,'<=');
		$param[] = $this->libs->arrWhere('AND','a.orgeh',$orgeh,'1','=');
		$param[] = $this->libs->arrWhere('AND','a.jumlah',1,0,'>=');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$this->config->item('hilfm_pimpinan'),0,'IN');
		$param[] = $this->libs->arrWhere('AND','c.kode_corp_title',$this->config->item('corp_title_pimpinan'),1,'IN');

		$data['keyjobs'] = $this->setting_model->getKeyjobs(false,$param,'d.urutan DESC, d.corp_title ASC');

		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$orgeh,'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$data['organization'] = isset($organization[0])?$organization[0]:'';

		$this->load->view('succession/show_keyjobs', $data);
	}

	public function successor_detail(){
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['organization'] = $filter['orgeh'];
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['type'] = $this->input->get_post('type');

		$param_sort['sort'] = $this->input->get_post('sort');
		$param_sort['sort_column'] = $this->input->get_post('sort_column');
		$param_sort['direction'] = $this->input->get_post('direction');

		if($param_sort['sort'] == '' && $param_sort['sort_column'] == ''){
			$param_sort['sort_column'] = 'OverallCompabilityScore';
			$param_sort['sort'] = 'desc';
			$param_sort['direction'] = 'up';
		}

		$s_sort = 'asc';
		if($param_sort['sort'] == 'asc')
			$s_sort = 'desc';


		$sort_by = ($param_sort['sort_column'] . ' ' . $param_sort['sort'] .', TanggalLahir ' . $s_sort);
		
		$this->load->library(array('pagination'));

		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','OrgUnit',$filter['orgeh'],1,'=');
		$param[] = $this->libs->arrWhere('AND','Hilfm',$filter['hilfm'],1,'=');
		$param[] = $this->libs->arrWhere('AND','CorpTitleId',$filter['corp_title_id'],1,'=');
		if($filter['f_pekerja'] != '')
			$param[] = $this->libs->arrWhere('AND','Pernr',$filter['f_pekerja'],1,'=');
		
		/* Paginatian */
		$config['base_url'] = site_url('succession/successor_detail/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->succession_model->get_successors(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];
		$data['filter'] = $filter;
		$data['param_sort'] = $param_sort;
		
		$data['keyjobs'] = $this->setting_model->getMstKeyjobs($filter['orgeh'], $filter['hilfm'], $filter['corp_title_id']);
		$data['hilfm'] = $this->db->get_where('master_hilfm', array('hilfm'=>$filter['hilfm']))->row();
		$data['ct'] = $this->db->get_where('corporate_title_aspirasi', array('id'=>$filter['corp_title_id']))->row();

		$data['successors'] = $this->succession_model->get_successors(false,$param,$sort_by,$rowpos,$limits);
		
		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$filter['orgeh'],'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$data['organization'] = isset($organization[0])?$organization[0]:'';

		$this->load->view('succession/successor_detail',$data);
	}

	function checked_talent(){
		$data_upd = array('IsChecked' => $this->input->get_post('checked'));
		$dcondition = array('OrgUnit' => $this->input->get_post('orgeh'), 'Hilfm' => $this->input->get_post('hilfm'), 'CorpTitleId' => $this->input->get_post('corp_title_id'), 'pernr' => $this->input->get_post('pernr'));
		if($this->db->update('SuccessionPlanOverallCompability', $data_upd, $dcondition))
			echo 'ok';
		else
			echo 'failed';
	}

	function successors_compare(){
		$data = array();
		$filter['compare_pernr'] = $this->input->get_post('compare_pernr');
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['bucket'] = $this->input->get_post('bucket');
		$filter['source'] = $this->input->get_post('source');
		$filter['type'] = $this->input->get_post('type');

		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$filter['orgeh'],'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$data['organization'] = isset($organization[0])?$organization[0]:'';
		$data['keyjobs'] = $this->setting_model->getMstKeyjobs($filter['orgeh'], $filter['hilfm'], $filter['corp_title_id']);
		$data['hilfm'] = $this->db->get_where('master_hilfm', array('hilfm'=>$filter['hilfm']))->row();
		$data['ct'] = $this->db->get_where('corporate_title_aspirasi', array('id'=>$filter['corp_title_id']))->row();

		
		if($filter['type'] == 'normal' || $filter['type'] == 'bucket'){
			$param = array();
			$param[] = $this->libs->arrWhere('AND','OrgUnit',$filter['orgeh'],1,'=');
			$param[] = $this->libs->arrWhere('AND','Hilfm',$filter['hilfm'],1,'=');
			$param[] = $this->libs->arrWhere('AND','CorpTitleId',$filter['corp_title_id'],1,'=');
			$param[] = $this->libs->arrWhere('AND','IsChecked',1,1,'=');
			if(isset($filter['bucket'])){
				if($filter['bucket'] != '' && $filter['bucket'] != 0){
					$param[] = $this->libs->arrWhere('AND','IdBucket',$filter['bucket'],1,'=');
					$data['successors'] = $this->succession_model->get_bucket_successors(false,$param,'Urutan asc, tanggallahir');
				}
				else{
					$data['successors'] = $this->succession_model->get_successors(false,$param,'OverallCompabilityScore desc, tanggallahir');
				}
			}
			else{
				$data['successors'] = $this->succession_model->get_successors(false,$param,'OverallCompabilityScore desc, tanggallahir');
			}
		}
		else{
			$filter['jenis_aspirasi'] = $this->input->get_post('jenis_aspirasi');
			$param = array();
			$order  = 'a.OcsScore desc';
			if($filter['jenis_aspirasi'] == 1){
				$param[] = $this->libs->arrWhere('AND','a.OrgUnit',$filter['orgeh'],1,'=');
				$param[] = $this->libs->arrWhere('AND','a.Hilfm',$filter['hilfm'],1,'=');

				if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',array('SM', 'AVP'),1,'IN');
				}
				elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id'] == 'DIR'){
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',array('SEVP', 'DIR'),1,'IN');
				}
				else{
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',$filter['corp_title_id'],1,'=');
				}
				$param[] = $this->libs->arrWhere('AND','a.StatusData',1,1,'=');
				$order = 'b.OverallCompabilityScore desc';
			}
			elseif($filter['jenis_aspirasi'] == 2){
				$param[] = $this->libs->arrWhere('AND','a.OrgUnit',$filter['orgeh'],1,'=');
				$param[] = $this->libs->arrWhere('AND','a.Hilfm',$filter['hilfm'],1,'=');
				
				if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',array('SM', 'AVP'),1,'IN');
				}
				elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id'] == 'DIR'){
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',array('SEVP', 'DIR'),1,'IN');
				}
				else{
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',$filter['corp_title_id'],1,'=');
				}

			}
			elseif($filter['jenis_aspirasi'] == 3){
				$param[] = $this->libs->arrWhere('AND','a.OrgUnitAction',$filter['orgeh'],1,'=');
				$param[] = $this->libs->arrWhere('AND','a.HilfmAction',$filter['hilfm'],1,'=');

				if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleIdAction',array('SM', 'AVP'),1,'IN');
				}
				elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id'] == 'DIR'){
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleIdAction',array('SEVP', 'DIR'),1,'IN');
				}
				else{
					$param[] = $this->libs->arrWhere('AND','a.CorporateTitleIdAction',$filter['corp_title_id'],1,'=');
				}
			}
			$data['successors'] = $this->succession_model->get_successors_aspiration(false,$param,$filter,$order);
		}

		$data['filter'] = $filter;
		$this->load->view('succession/successors_compare',$data);
		
	}

	function save_candidates(){
		$data = array();
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['bucket'] = $this->input->get_post('bucket');

		$data['filter'] = $filter;

		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$filter['orgeh'],'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$organization = isset($organization[0])?$organization[0]:'';
		$hilfm = $this->db->get_where('master_hilfm', array('hilfm'=>$filter['hilfm']))->row();
		$ct = $this->db->get_where('corporate_title_aspirasi', array('id'=>$filter['corp_title_id']))->row();
		
		$param_ins = array(
			'OrgUnit' => $filter['orgeh']
			, 'Hilfm' => $filter['hilfm']
			, 'CorpTitleId' => $filter['corp_title_id']
			, 'OrgUnitDesc' => isset($organization->MYNAME)?$organization->MYNAME:''
			, 'Htext' => isset($hilfm->htext)?$hilfm->htext:''
			, 'CorpTitleDesc' => isset($ct->corp_title)?$ct->corp_title:''
			, 'BucketName' => $this->input->get_post('bucket_name')
			, 'Modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			, 'ModifiedBy' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			, 'ModifiedDate' => date('Y-m-d H:i:s')
			, 'Status' => 0
		);

		if(isset($filter['bucket'])){
			if($filter['bucket'] != '' && $filter['bucket'] != ''){
				$arr_input = false;//$this->succession_model->insert_new_candidates_bucket($param_ins, $filter);
			}
			else{
				$arr_input = $this->succession_model->insert_candidates_bucket($param_ins, $filter);
			}
		}
		else{
			$arr_input = $this->succession_model->insert_candidates_bucket($param_ins, $filter);
		}

		if($arr_input['status']){
			$this->auditrail_model->add_log('Talent', 'Insert Candidates Bucket');
			$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
			unset($_POST);
		}else{
			$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
		}
		
		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusApprover();

		$data['result'] = $this->candidates(true);
		$this->load->view('succession/filter_candidates', $data);
	}

	public function filter_candidates(){
		$data = array(
			'opt_status' => array(''=>'- Semua status -') + $this->libs->arrStatusApprover()
        );
		$data['result'] = $this->candidates(true);
		$this->load->view('succession/filter_candidates', $data);
	}
	
	public function candidates($string=false)
	{
		$filter['f_status'] = trim($this->input->post('f_status'));
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_status']!=''){
			$param[] = $this->libs->arrWhere('AND','a.Status',"{$filter['f_status']}",'1','=');
		}
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.OrgUnit',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrgUnitDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Hilfm',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Htext',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.BucketName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','a.Modifier',$_SESSION[$this->config->item('session_prefix')]['pernr'],'1','=');
		
		/* Paginatian */
		$config['base_url'] = site_url('succession/candidates/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->succession_model->get_candidates(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$data['candidates'] = $this->succession_model->get_candidates(false,$param,'a.ModifiedDate desc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('succession/candidates',$data,true); 
		}else{
			$this->load->view('succession/candidates',$data);
		}
	}

	function detail_bucket(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');
		$filter['organization'] = $this->input->get_post('orgeh');
		$filter['source'] = $this->input->get_post('source');

		if($filter['source'] == 'candidates')
			$filter['urlBack'] = 'succession/filter_candidates';
		elseif($filter['source'] == 'monitoring')
			$filter['urlBack'] = 'setting/filter_logs_monitoring';
		else
			$filter['urlBack'] = 'home';
			
		$data['filter'] = $filter;

		$data['talent_bucket'] = $this->db->get_where('TalentBucket', array('IdBucket' => $filter['id_bucket']))->row();
		
		$this->db->order_by('Urutan');
		$data['candidates'] = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$data['content'] = $this->load->view('succession/candidates_content',$data,true); 
		$this->load->view('succession/detail_candidates',$data); 
	}

	function update_ordered_list(){
		$data = array();
		$filter['IdBucket'] = $this->input->get_post('id_bucket');
		$filter['OrgUnit'] = $this->input->get_post('orgeh');
		$filter['Hilfm'] = $this->input->get_post('hilfm');
		$filter['CorpTitleId'] = $this->input->get_post('corp_title_id');
		$filter['Pernr'] = $this->input->get_post('pernr');
		$new_urutan = $this->input->get_post('urutan');

		$proses = $this->succession_model->update_ordered_list($filter, $new_urutan);

		if($proses['status']){
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}

		$data['talent_bucket'] = $this->db->get_where('TalentBucket', array('IdBucket' => $filter['IdBucket']))->row();
		$this->db->order_by('Urutan');
		$data['candidates'] = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $filter['IdBucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$this->load->view('succession/candidates_content',$data); 
	}

	function delete_candidates(){
		$data = array();
		$filter['IdBucket'] = $this->input->get_post('id_bucket');
		$filter['OrgUnit'] = $this->input->get_post('orgeh');
		$filter['Hilfm'] = $this->input->get_post('hilfm');
		$filter['CorpTitleId'] = $this->input->get_post('corp_title_id');
		$filter['Pernr'] = $this->input->get_post('pernr');

		$proses = $this->succession_model->delete_candidates($filter);

		if($proses['status']){
			$this->auditrail_model->add_log('Talent', 'Delete Candidates PN = ' . $filter['Pernr'] . ', OrgUnit = ' . $filter['OrgUnit']  . ', Hilfm = ' . $filter['Hilfm'] . ' , Id Bucket = ' . $filter['IdBucket']);
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}
	
		$data['talent_bucket'] = $this->db->get_where('TalentBucket', array('IdBucket' => $filter['IdBucket']))->row();
		$this->db->order_by('Urutan');
		$data['candidates'] = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $filter['IdBucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$this->load->view('succession/candidates_content',$data); 
	}

	function add_new_candidates(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');

		$data['filter'] = $filter;

		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$filter['orgeh'],'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$data['organization'] = isset($organization[0])?$organization[0]:'';
		$data['keyjobs'] = $this->setting_model->getMstKeyjobs($filter['orgeh'], $filter['hilfm'], $filter['corp_title_id']);
		$data['hilfm'] = $this->db->get_where('master_hilfm', array('hilfm'=>$filter['hilfm']))->row();
		$data['ct'] = $this->db->get_where('corporate_title_aspirasi', array('id'=>$filter['corp_title_id']))->row();

		$this->load->view('succession/form_add_candidates',$data); 
	}

	function save_new_candidates(){
		$data = array();
		$filter['IdBucket'] = $this->input->get_post('id_bucket');
		$filter['OrgUnit'] = $this->input->get_post('orgeh');
		$filter['Hilfm'] = $this->input->get_post('hilfm');
		$filter['CorpTitleId'] = $this->input->get_post('corp_title_id');
		$filter['candidates'] = $this->input->get_post('candidates');

		$candidates = $this->talent_model->get_selected_pekerja($filter['candidates']);

		$is_exist = $this->succession_model->is_candidates_exist($filter);
		if(!$is_exist){
			if(isset($candidates->PERNR)){
				$keyjobs = $this->setting_model->getMstKeyjobs($filter['OrgUnit'], $filter['Hilfm'], $filter['CorpTitleId']);
				$proses = $this->succession_model->save_new_candidates($filter, $candidates, $keyjobs);
				if($proses['status']){
					$this->auditrail_model->add_log('Talent', 'Add New Candidates PN = ' . $filter['candidates'] . ', OrgUnit = ' . $filter['OrgUnit']  . ', Hilfm = '. $filter['Hilfm'] .', Id Bucket = ' . $filter['IdBucket']);
					$data['message'] = $this->libs->generate_message('success',$proses['message']);
				}
				else{
					$data['message'] = $this->libs->generate_message('danger',$proses['message']);
				}
			}
			else{
				$data['message'] = $this->libs->generate_message('danger','Data Pekerja Tidak Ditemukan.');
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Data Pekerja Sudah Ada.');
		}

		$data['talent_bucket'] = $this->db->get_where('TalentBucket', array('IdBucket' => $filter['IdBucket']))->row();
		$this->db->order_by('Urutan');
		$data['candidates'] = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $filter['IdBucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$this->load->view('succession/candidates_content',$data); 
	}

	function save_candidates_to_bucket(){
		$data = array();
		$filter['IdBucket'] = $this->input->get_post('id_bucket');
		$filter['OrgUnit'] = $this->input->get_post('orgeh');
		$filter['Hilfm'] = $this->input->get_post('hilfm');
		$filter['CorpTitleId'] = $this->input->get_post('corp_title_id');
		$filter['candidates'] = $this->input->get_post('candidates');

		$candidates = $this->talent_model->get_selected_pekerja($filter['candidates']);

		$is_exist = $this->succession_model->is_candidates_exist($filter);
		if(!$is_exist){
			if(isset($candidates->PERNR)){
				$keyjobs = $this->setting_model->getMstKeyjobs($filter['OrgUnit'], $filter['Hilfm'], $filter['CorpTitleId']);
				$proses = $this->succession_model->save_new_candidates($filter, $candidates, $keyjobs);
				if($proses['status']){
					$this->auditrail_model->add_log('Talent', 'Add New Candidates PN = ' . $filter['candidates'] . ', OrgUnit = ' . $filter['OrgUnit']  . ', Hilfm = '. $filter['Hilfm'] .', Id Bucket = ' . $filter['IdBucket']);
					$data['message'] = $this->libs->generate_message('success',$proses['message']);
				}
				else{
					$data['message'] = $this->libs->generate_message('danger',$proses['message']);
				}
			}
			else{
				$data['message'] = $this->libs->generate_message('danger','Data Pekerja Tidak Ditemukan.');
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Data Pekerja Sudah Ada.');
		}
		
		$param = array();
		$orgeh = $filter['OrgUnit'];
		$param[] = $this->libs->arrWhere('AND','CURDATE()','a.startdate',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','a.enddate',0,'<=');
		$param[] = $this->libs->arrWhere('AND','a.orgeh',$orgeh,'1','=');
		$param[] = $this->libs->arrWhere('AND','a.jumlah',1,0,'>=');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$this->config->item('hilfm_pimpinan'),0,'IN');
		$param[] = $this->libs->arrWhere('AND','c.kode_corp_title',$this->config->item('corp_title_pimpinan'),1,'IN');

		$data['keyjobs'] = $this->setting_model->getKeyjobs(false,$param,'htext ASC');

		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$orgeh,'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$data['organization'] = isset($organization[0])?$organization[0]:'';

		$this->load->view('succession/show_keyjobs', $data);
		
	}

	function delete_candidates_from_bucket(){
		$data = array();
		$filter['IdBucket'] = $this->input->get_post('id_bucket');
		$filter['OrgUnit'] = $this->input->get_post('orgeh');
		$filter['Hilfm'] = $this->input->get_post('hilfm');
		$filter['CorpTitleId'] = $this->input->get_post('corp_title_id');
		$filter['Pernr'] = $this->input->get_post('pernr');

		$proses = $this->succession_model->delete_candidates($filter);

		if($proses['status']){
			$this->auditrail_model->add_log('Talent', 'Delete Candidates PN = ' . $filter['Pernr'] . ', OrgUnit = ' . $filter['OrgUnit']  . ', Hilfm = ' . $filter['Hilfm'] . ' , Id Bucket = ' . $filter['IdBucket']);
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}
	
		$param = array();
		$orgeh = $filter['OrgUnit'];
		$param[] = $this->libs->arrWhere('AND','CURDATE()','a.startdate',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','a.enddate',0,'<=');
		$param[] = $this->libs->arrWhere('AND','a.orgeh',$orgeh,'1','=');
		$param[] = $this->libs->arrWhere('AND','a.jumlah',1,0,'>=');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$this->config->item('hilfm_pimpinan'),0,'IN');
		$param[] = $this->libs->arrWhere('AND','c.kode_corp_title',$this->config->item('corp_title_pimpinan'),1,'IN');

		$data['keyjobs'] = $this->setting_model->getKeyjobs(false,$param,'d.urutan DESC, d.corp_title ASC');

		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$orgeh,'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$data['organization'] = isset($organization[0])?$organization[0]:'';

		$this->load->view('succession/show_keyjobs', $data);
	}

	function batalkan_pengajuan(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$param = array(
			'Modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			, 'ModifiedBy' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			, 'ModifiedDate' => date('Y-m-d H:i:s')
			, 'Status' => 4
		);
		$proses = $this->db->update('TalentBucket', $param, array('IdBucket' => $filter['id_bucket']));

		if($proses){
			$this->auditrail_model->add_log('Talent', 'Membatalkan Pengajuan. Id Bucket = '. $filter['id_bucket']);
			$data['message'] = $this->libs->generate_message('success','Pengajuan berhasil dibatalkan.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Pengajuan gagal dibatalkan.');
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusApprover();
		$data['result'] = $this->candidates(true);
		$this->load->view('succession/filter_candidates', $data);
	}

	function hapus_pengajuan(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		
		$proses = $this->db->delete('TalentBucket', array('IdBucket' => $filter['id_bucket']));

		if($proses){
			$this->db->delete('TalentCandidatesResults', array('IdBucket' => $filter['id_bucket'])); // add this too
			$this->auditrail_model->add_log('Talent', 'Hapus Bucket. Id Bucket = '. $filter['id_bucket']);
			$data['message'] = $this->libs->generate_message('success','Bucket berhasil dihapus.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Bucket gagal dihapus.');
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusApprover();
		$data['result'] = $this->candidates(true);
		$this->load->view('succession/filter_candidates', $data);
	}

	function kirim_candidates(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$arr_data['arr_cs'] = $this->input->get_post('cs');
		$arr_data['arr_text_cs'] = $this->input->get_post('text_cs');
		$posisi = '';
		$signers = array();
		$valid_cs = true;
		$desc_approver = array();
		foreach($arr_data['arr_cs'] as $idx=>$row) {
			if($posisi == '') {
				$posisi = $row;
			}

			if(isset($arr_data['arr_text_cs'][$idx])){
				
				$desc_approver[$idx] = str_replace('/','|',$arr_data['arr_text_cs'][$idx]);
				$signers[$idx] = $row;
			}
			else{
				$valid_cs = false;
				break;
			}
		}

		$arr_data['arr_cs_via'] = $this->input->get_post('cs_via');
		$arr_data['arr_text_cs_via'] = $this->input->get_post('text_cs_via');
		$posisi_via = '';
		$signers_via = array();
		$valid_cs_via = true;
		$desc_approver_via = array();
		foreach($arr_data['arr_cs_via'] as $idx=>$row) {
			if($posisi_via == '') {
				$posisi_via = $row;
			}

			if(isset($arr_data['arr_text_cs_via'][$idx])){
				$desc_approver_via[$idx] = str_replace('/','|',$arr_data['arr_text_cs_via'][$idx]);
				$signers_via[$idx] = $row;
			}
			else{
				$valid_cs_via = false;
				break;
			}
		}

		$arr_data['arr_cs_paralel'] = $this->input->get_post('cs_paralel');
		$arr_data['arr_text_cs_paralel'] = $this->input->get_post('text_cs_paralel');
		$posisi_paralel = '';
		$signers_paralel = array();
		$valid_cs_paralel = true;
		$desc_approver_paralel = array();
		foreach($arr_data['arr_cs_paralel'] as $idx=>$row) {

			if(isset($arr_data['arr_text_cs_paralel'][$idx])){
				
				$desc_approver_paralel[$idx] = str_replace('/','|',$arr_data['arr_text_cs_paralel'][$idx]);
				$signers_paralel[$idx] = $row;
			}
			else{
				$valid_cs_paralel = false;
				break;
			}
		}

		if($valid_cs){
			$param = array(
				'Modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
				, 'ModifiedBy' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
				, 'ModifiedDate' => date('Y-m-d H:i:s')
				, 'Approver' => implode('~', $signers)
				, 'DescApprover' => implode('~', $desc_approver)
				, 'Posisi' => $posisi
				, 'Status' => 1
				, 'StatusApproval' => null
				, 'TglProses' => null
				, 'CatatanApprover' => null
				, 'ApproverVia' => implode('~', $signers_via)
				, 'DescApproverVia' => implode('~', $desc_approver_via)
				, 'PosisiVia' => $posisi_via
				, 'StatusVia' => 1
				, 'StatusApprovalVia' => null
				, 'ApproverParalel' => implode('~', $signers_paralel)
				, 'CheckApproverParalel' => implode('~', $signers_paralel)
				, 'DescApproverParalel' => implode('~', $desc_approver_paralel)
				
			);

			$arr_template_via = array();
			foreach($signers_via as $item){
				$arr_template_via[] = 'X';
			}
			
			if($posisi_via != ''){
				$param['TglProsesVia'] = implode('~', $arr_template_via);
				$param['CatatanApproverVia'] = implode('~', $arr_template_via);
				$param['CandidateApprovalVia'] = implode('~', $arr_template_via);
				$param['CandidateDescApprovalVia'] = implode('~', $arr_template_via);
			}
			else{
				$param['ApproverVia'] = null;
				$param['DescApproverVia'] = null;
				$param['PosisiVia'] = 'SELESAI';
				$param['StatusVia'] = 2;
				$param['TglProsesVia'] = null;
				$param['CatatanApproverVia'] = null;
				$param['CandidateApprovalVia'] = null;
				$param['CandidateDescApprovalVia'] = null;
			}
			

			$arr_template_paralel = array();
			foreach($signers_paralel as $item){
				$arr_template_paralel[] = 'X';
			}
			
			$param['StatusApprovalParalel'] = implode('~', $arr_template_paralel);
			$param['TglProsesParalel'] = implode('~', $arr_template_paralel);
			$param['CatatanApproverParalel'] = implode('~', $arr_template_paralel);
			$param['CandidateApprovalParalel'] = implode('~', $arr_template_paralel);
			$param['CandidateDescApprovalParalel'] = implode('~', $arr_template_paralel);

			$proses = $this->db->update('TalentBucket', $param, array('IdBucket' => $filter['id_bucket']));

			if($proses){
				$this->auditrail_model->add_log('Talent', 'Mengirim Pengajuan. Id Bucket = '. $filter['id_bucket']);
				$data['message'] = $this->libs->generate_message('success','Pengajuan berhasil dikirim.');
			}
			else{
				$data['message'] = $this->libs->generate_message('danger','Pengajuan gagal dikirim.');
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Approver tidak ditemukan.');
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusApprover();
		$data['result'] = $this->candidates(true);
		$this->load->view('succession/filter_candidates', $data);

	}

	public function filter_approval_candidates(){
		$data = array();
		$data['result'] = $this->approval_candidates(true);
		$this->load->view('succession/filter_approval_candidates', $data);
	}
	
	public function approval_candidates($string=false)
	{
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.OrgUnit',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrgUnitDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Hilfm',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Htext',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.BucketName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}
		
		$param[] = $this->libs->arrWhere('AND','a.Posisi',$_SESSION[$this->config->item('session_prefix')]['pernr'],'1','=');
		$param[] = $this->libs->arrWhere('AND','a.Status',1,'1','=');

		/* Paginatian */
		$config['base_url'] = site_url('succession/approval_candidates/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->succession_model->get_candidates(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$data['candidates'] = $this->succession_model->get_candidates(false,$param,'a.ModifiedDate asc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('succession/approval_candidates',$data,true); 
		}else{
			$this->load->view('succession/approval_candidates',$data);
		}
	}

	function detail_approval_bucket(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');
		$filter['organization'] = $this->input->get_post('orgeh');
		$data['filter'] = $filter;

		$data['talent_bucket'] = $this->db->get_where('TalentBucket', array('IdBucket' => $filter['id_bucket']))->row();
		
		$this->db->order_by('Urutan');
		$data['candidates'] = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$data['content'] = $this->load->view('succession/candidates_content',$data,true);
		$this->load->view('succession/detail_approval_candidates',$data); 
	}

	public function approve_data(){
		$id_bucket = $this->db->escape_str($this->input->get_post('id_bucket'));
		$komentar = $this->db->escape_str($this->input->get_post('komentar'));
		$proses = $this->succession_model->approve_data($id_bucket, $komentar);
		if (!$proses['error']) {
			$this->auditrail_model->add_log("Persetujuan Bucket", $_SESSION[$this->config->item('session_prefix')]['pernr']." menyetujui pengajuan bucket untuk id_bucket ". $id_bucket);
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		} else {
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}
		$data['notif'] = $this->access_menu_model->get_notif();
		$data['result'] = $this->approval_candidates(true);
		$this->load->view('succession/filter_approval_candidates', $data);
	}

	public function reject_data(){
		$id_bucket = $this->db->escape_str($this->input->get_post('id_bucket'));
		$komentar = $this->db->escape_str($this->input->get_post('komentar'));
		$proses = $this->succession_model->reject_data($id_bucket, $komentar);
		if (!$proses['error']) {
			$this->auditrail_model->add_log("Persetujuan Bucket", $_SESSION[$this->config->item('session_prefix')]['pernr']." menolak pengajuan bucket untuk id_bucket ". $id_bucket);
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		} else {
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}
		$data['notif'] = $this->access_menu_model->get_notif();
		$data['result'] = $this->approval_candidates(true);
		$this->load->view('succession/filter_approval_candidates', $data);
	}

	public function create_pdf_candidates()
	{	
		$filter['id_bucket'] = $this->input->get_post('id_bucket_candidates');
		$filter['orgeh'] = $this->input->get_post('orgeh_candidates');
		$filter['hilfm'] = $this->input->get_post('hilfm_candidates');
		$filter['organization'] = $this->input->get_post('organization_candidates');
		$data['filter'] = $filter;
		if($filter['id_bucket']!='')
		{
			$data = array();
			$param = array();
			$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
			$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
			$param[] = $this->libs->arrWhere('AND','CHILD',$filter['orgeh'],'1','=');
			$param[] = $this->libs->arrWhere('AND','FLAG',1);
			$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
			$data['organization'] = isset($organization[0])?$organization[0]:'';
			$data['keyjobs'] = $this->setting_model->getMstKeyjobs($filter['orgeh'], $filter['hilfm']);
			$data['hilfm'] = $this->db->get_where('master_hilfm', array('hilfm'=>$filter['hilfm']))->row();
			
			$data['talent_bucket'] = $this->db->get_where('TalentBucket', array('IdBucket' => $filter['IdBucket']))->row();
			$this->db->order_by('Urutan');
			$data['candidates'] = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $filter['IdBucket']))->result();
			$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
			$file_name = isset($data['talent_bucket']->BucketName)?$data['talent_bucket']->BucketName:'Detail Candidates';
			$data['content'] = $this->load->view('succession/detail_candidates_pdf',$data,true); 
		}
		else
		{
			$file_name = 'invalid';
			$data['content'] = 'Data tidak valid';
		}

		$html = $this->load->view('theme/pdf_template',$data,true);			
		$this->libs->wkhtmltopdf($html,$file_name,'A4','Landscape');
	}

	public function bucket_successor_detail(){
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['organization'] = $filter['orgeh'];
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['bucket'] = $this->input->get_post('bucket');
		$filter['type'] = $this->input->get_post('type');

		$param_sort['sort'] = $this->input->get_post('sort');
		$param_sort['sort_column'] = $this->input->get_post('sort_column');
		$param_sort['direction'] = $this->input->get_post('direction');

		if($param_sort['sort'] == '' && $param_sort['sort_column'] == ''){
			//$param_sort['sort_column'] = 'OverallCompabilityScore';
			$param_sort['sort_column'] = 'Urutan';
			$param_sort['sort'] = 'asc';
			$param_sort['direction'] = 'up';
		}

		$s_sort = 'asc';
		if($param_sort['sort'] == 'asc')
			$s_sort = 'desc';


		$sort_by = ($param_sort['sort_column'] . ' ' . $param_sort['sort'] .', TanggalLahir ' . $s_sort);
		
		$this->load->library(array('pagination'));

		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','IdBucket',$filter['bucket'],1,'=');
		$param[] = $this->libs->arrWhere('AND','OrgUnit',$filter['orgeh'],1,'=');
		$param[] = $this->libs->arrWhere('AND','Hilfm',$filter['hilfm'],1,'=');
		$param[] = $this->libs->arrWhere('AND','CorpTitleId',$filter['corp_title_id'],1,'=');
		
		if($filter['f_pekerja'] != '')
			$param[] = $this->libs->arrWhere('AND','Pernr',$filter['f_pekerja'],1,'=');
		
		/* Paginatian */
		$config['base_url'] = site_url('succession/bucket_successor_detail/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->succession_model->get_bucket_successors(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];
		$data['filter'] = $filter;
		$data['param_sort'] = $param_sort;
		
		$data['keyjobs'] = $this->setting_model->getMstKeyjobs($filter['orgeh'], $filter['hilfm'], $filter['corp_title_id']);
		$data['hilfm'] = $this->db->get_where('master_hilfm', array('hilfm'=>$filter['hilfm']))->row();
		$data['ct'] = $this->db->get_where('corporate_title_aspirasi', array('id'=>$filter['corp_title_id']))->row();
		$data['successors'] = $this->succession_model->get_bucket_successors(false,$param,$sort_by,$rowpos,$limits);
		
		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$filter['orgeh'],'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$data['organization'] = isset($organization[0])?$organization[0]:'';

		$this->load->view('succession/successor_bucket_detail',$data);
	}

	function checked_bucket_talent(){
		$data_upd = array('IsChecked' => $this->input->get_post('checked'));
		$dcondition = array('OrgUnit' => $this->input->get_post('orgeh'), 'Hilfm' => $this->input->get_post('hilfm'), 'CorpTitleId' => $this->input->get_post('corp_title_id'), 'Pernr' => $this->input->get_post('pernr'), 'IdBucket' => $this->input->get_post('bucket'));
		if($this->db->update('TalentCandidatesResults', $data_upd, $dcondition))
			echo 'ok';
		else
			echo 'failed';
	}

	public function successor_aspiration_detail(){
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['organization'] = $filter['orgeh'];
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_aspirasi'] = $this->input->get_post('jenis_aspirasi');

		$param_sort['sort'] = $this->input->get_post('sort');
		$param_sort['sort_column'] = $this->input->get_post('sort_column');
		$param_sort['direction'] = $this->input->get_post('direction');

		if($param_sort['sort'] == '' && $param_sort['sort_column'] == ''){
			if($filter['jenis_aspirasi'] == 1)
				$param_sort['sort_column'] = 'b.OverallCompabilityScore';
			else 
			$param_sort['sort_column'] = 'a.OcsScore';

			$param_sort['sort'] = 'desc';
			$param_sort['direction'] = 'up';
		}

		$s_sort = 'asc';
		if($param_sort['sort'] == 'asc')
			$s_sort = 'desc';


		$sort_by = ($param_sort['sort_column'] . ' ' . $param_sort['sort']);
		
		$this->load->library(array('pagination'));

		$param = array();
		
		if($filter['jenis_aspirasi'] == 1){
			$param[] = $this->libs->arrWhere('AND','a.OrgUnit',$filter['orgeh'],1,'=');
			$param[] = $this->libs->arrWhere('AND','a.Hilfm',$filter['hilfm'],1,'=');

			if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',array('SM', 'AVP'),1,'IN');
			}
			elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id'] == 'DIR'){
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',array('SEVP', 'DIR'),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',$filter['corp_title_id'],1,'=');
			}

			$param[] = $this->libs->arrWhere('AND','a.StatusData',1,1,'=');
		}
		/*elseif($filter['jenis_aspirasi'] == 2){
			$param[] = $this->libs->arrWhere('AND','a.OrgUnit',$filter['orgeh'],1,'=');
			$param[] = $this->libs->arrWhere('AND','a.Hilfm',$filter['hilfm'],1,'=');

			if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',array('SM', 'AVP'),1,'IN');
			}
			elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id'] == 'DIR'){
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',array('SEVP', 'DIR'),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleId',$filter['corp_title_id'],1,'=');
			}
		}*/
		elseif($filter['jenis_aspirasi'] == 3){
			$param[] = $this->libs->arrWhere('AND','a.OrgUnitAction',$filter['orgeh'],1,'=');
			$param[] = $this->libs->arrWhere('AND','a.HilfmAction',$filter['hilfm'],1,'=');

			if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleIdAction',array('SM', 'AVP'),1,'IN');
			}
			elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id'] == 'DIR'){
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleIdAction',array('SEVP', 'DIR'),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.CorporateTitleIdAction',$filter['corp_title_id'],1,'=');
			}
		}
			

		if($filter['f_pekerja'] != '')
			$param[] = $this->libs->arrWhere('AND','a.Pernr',$filter['f_pekerja'],1,'=');
		
		/* Paginatian */
		$config['base_url'] = site_url('succession/successor_aspiration_detail/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->succession_model->get_successors_aspiration(true,$param,$filter);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];
		$data['filter'] = $filter;
		$data['param_sort'] = $param_sort;
		
		$data['keyjobs'] = $this->setting_model->getMstKeyjobs($filter['orgeh'], $filter['hilfm'], $filter['corp_title_id']);
		$data['hilfm'] = $this->db->get_where('master_hilfm', array('hilfm'=>$filter['hilfm']))->row();
		$data['ct'] = $this->db->get_where('corporate_title_aspirasi', array('id'=>$filter['corp_title_id']))->row();

		$data['successors'] = $this->succession_model->get_successors_aspiration(false,$param,$filter,$sort_by,$rowpos,$limits);
		
		$param = array();
		$param[] = $this->libs->arrWhere('AND','CURDATE()','STARTDATE',0,'>=');
		$param[] = $this->libs->arrWhere('AND','CURDATE()','ENDDATE',0,'<=');
		$param[] = $this->libs->arrWhere('AND','CHILD',$filter['orgeh'],'1','=');
		$param[] = $this->libs->arrWhere('AND','FLAG',1);
		$organization = $this->setting_model->get_struktur_organisasi(false,$param,'CHILD ASC',0,1);
		$data['organization'] = isset($organization[0])?$organization[0]:'';

		$this->load->view('succession/successor_aspiration_detail',$data);
	}

	public function filter_talent_pool(){
		$data = array(
			'opt_jf' => array('' => '- Pilih Job Family -')+$this->succession_model->mst_jf(),
			'opt_sjf' => array('' => '- Pilih Bidang Keahlian -')
        );
		$data['result'] = $this->talent_pool(true);
		$this->load->view('succession/filter_talent_pool', $data);
	}
	
	public function talent_pool($string=false)
	{
		$filter['f_jf'] = trim($this->input->get_post('f_jf'));
		$filter['f_sjf'] = trim($this->input->get_post('f_sjf'));
		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();

		$param[] = $this->libs->arrWhere('AND','sjf.FLAG',"SJF",'1','=');
		$param[] = $this->libs->arrWhere('AND','sjf.STATUS',"1",'1','=');
		
		if($filter['f_jf']!=''){
			$param[] = $this->libs->arrWhere('AND','jf.INITIALS',"{$filter['f_jf']}",'1','=');
		}
		if($filter['f_sjf']!=''){
			$param[] = $this->libs->arrWhere('AND','sjf.INITIALS',"{$filter['f_sjf']}",'1','=');
		}
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(sjf.DESKRIPSI',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','jf.DESKRIPSI',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('succession/talent_pool/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->succession_model->get_job_family(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['talent_pool'] = $this->succession_model->get_job_family(false,$param,'jf.INITIALS, sjf.INITIALS',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('succession/talent_pool',$data,true); 
		}else{
			$this->load->view('succession/talent_pool',$data);
		}
	}

	function get_sjf(){
		$jf = trim($this->input->get_post('JF'));
		$option = '<option value="">- Pilih Bidang Keahlian -</option>';
		$data = $this->succession_model->mst_sjf($jf);
		foreach ($data as $row) {
			$option .= '<option value="'.$row->INITIALS.'">['.$row->INITIALS.'] '.$row->DESKRIPSI.'</option>';
		}

		echo $option;
	}

	function detail_talent_pool(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$jf = trim($this->input->get_post('jf'));
		$sjf = trim($this->input->get_post('sjf'));

		$param = array();
		$param[] = $this->libs->arrWhere('AND','sjf.INITIALS',$sjf,'1','=');
		$selectedJF = $this->succession_model->get_job_family(false,$param,'jf.INITIALS, sjf.INITIALS',0,1);
		$data['selectedJF'] = isset($selectedJF[0])?$selectedJF[0]:'';

		$this->db->order_by('urutan asc');
		if($tipe_uker == 'KP'){
			$data['arrCT'] = $this->db->get_where('MasterCorpTitle')->result();
		} else {
			$data['arrCT'] = $this->succession_model->get_master_corp_title();	
		}	

		//$data['arrCT'] = $this->db->get_where('MasterCorpTitle')->result();

		$data['arrCTSjf'] = array();
		$countCTSjf = $this->succession_model->countCTSjf($sjf);
		foreach($countCTSjf as $item){
			$data['arrCTSjf'][$item->kode_corp_title] = $item->jml;
		}

		$this->load->view('succession/detail_talent_pool',$data);

	}

	function detail_talent_pool_csv(){
		$sjf = trim($this->input->get_post('sjf'));
		$ct = trim($this->input->get_post('ct'));
		
		$param = array();

		$param[] = $this->libs->arrWhere('AND','a.persk',array('10','12','13','14','15','26','41','42','97','98'),1,'IN');
		$param[] = $this->libs->arrWhere('AND','b.kode_corp_title',$ct,'1','=');
		$param[] = $this->libs->arrWhere('AND','c.initials',$sjf,'1','=');

		$data['talent_pool_ct'] = $this->succession_model->get_talent_pool_ct_csv(false,$param,'b.jg desc, a.pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "TALENT_POOL_" . $ct . "_" . $sjf ."_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['talent_pool_ct'], TRUE, $filename);
	}

	function countCTGrade(){
		$sjf = trim($this->input->get_post('sjf'));
		$ct = trim($this->input->get_post('ct'));

		$countCTGrade = $this->succession_model->countCTGrade($sjf, $ct);

		if(count($countCTGrade) > 0){
			$list = '<ol class="dd-list">';
			foreach($countCTGrade as $item){
				$list .= '<li class="dd-item">';
				$list .= '<div class="dd-handle">';
				$list .= '<span class="dd_item_ex_col" rel="sjf='.$sjf.'&ct='.$ct.'&jg='. (isset($item->jg) ? $item->jg : "").'">';
				$list .= '<span class="label label-warning"><i class="fa fa-file"></i></span>';
				$list .= '<span style="margin-left:5px;">'.(isset($item->jg) ? $item->jg : "") . '</span>';
				$list .= '</span>';
				$list .= '<span class="pull-right">('.(isset($item->jml) ? $item->jml : "").' Pekerja) &nbsp; <button class="btn btn-success btn-xs download_talent_pool_ct_jg" rel="ct='.$ct.'&sjf='.$sjf.'&jg='. (isset($item->jg) ? $item->jg : "").'" value="Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i></button></span>';
				$list .= '</div>';
				$list .= '</li>';
			}
			$list .= '</ol>';
			echo $list;
		}
		else{
			echo '<div class="alert alert-danger alert-dismissible">- Data Tidak Ditemukan -</div>';
		}
	}

	function detail_talent_pool_jg_csv(){
		$sjf = trim($this->input->get_post('sjf'));
		$ct = trim($this->input->get_post('ct'));
		$jg = trim($this->input->get_post('jg'));
		
		$param = array();

		$param[] = $this->libs->arrWhere('AND','a.persk',array('10','12','13','14','15','26','41','42','97','98'),1,'IN');
		$param[] = $this->libs->arrWhere('AND','b.kode_corp_title',$ct,'1','=');
		$param[] = $this->libs->arrWhere('AND','b.jg',$jg,'1','=');
		$param[] = $this->libs->arrWhere('AND','c.initials',$sjf,'1','=');

		$data['talent_pool_ct'] = $this->succession_model->get_talent_pool_ct_csv(false,$param,'a.pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "TALENT_POOL_" . $ct . "_" . $sjf ."_" . $jg ."_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['talent_pool_ct'], TRUE, $filename);
	}

	public function show_talent_pool(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['sjf'] = trim($this->input->get_post('sjf'));
		$filter['ct'] = trim($this->input->get_post('ct'));
		$filter['jg'] = trim($this->input->get_post('jg'));
		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		$filter['f_jg'] = trim($this->input->get_post('f_jg'));
		
		$this->load->library(array('pagination'));

		$param = array();
		$param[] = $this->libs->arrWhere('AND','sjf.INITIALS',$filter['sjf'],'1','=');
		$selectedJF = $this->succession_model->get_job_family(false,$param,'jf.INITIALS, sjf.INITIALS',0,1);
		$data['selectedJF'] = isset($selectedJF[0])?$selectedJF[0]:'';

		$data['selectedCT'] = $this->db->get_where('MasterCorpTitle', array('corp_title_id' => $filter['ct']))->row();

		$param = array();

		$param[] = $this->libs->arrWhere('AND','a.persk',array('10','12','13','14','15','26','41','42','97','98'),1,'IN');
		$param[] = $this->libs->arrWhere('AND','b.kode_corp_title',$filter['ct'],'1','=');
		$param[] = $this->libs->arrWhere('AND','c.initials',$filter['sjf'],'1','=');
		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.WERKS',$pa,'1','=');
		}

		$list_jg = array();
		if($filter['jg'] != ''){
			$param[] = $this->libs->arrWhere('AND','b.jg',$filter['jg'],1,'=');
			$list_jg[$filter['jg']] = $filter['jg'];
		}
		else{
			$countCTGrade = $this->succession_model->countCTGrade($filter['sjf'], $filter['ct']);
			if(count($countCTGrade)>0){
				foreach($countCTGrade as $row){
					$list_jg[$row->jg] = $row->jg;
				}
			}
		}
			
		$data['opt_jg'] = array('' => '- Pilih Job Grade -')+$list_jg;


		if($filter['f_jg'] != ''){
			$param[] = $this->libs->arrWhere('AND','b.jg',$filter['f_jg'],1,'=');
		}

		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.sname',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('succession/show_talent_pool/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->succession_model->get_talent_pool_ct_csv(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];
		$data['filter'] = $filter;
		$data['talent_pool'] = $this->succession_model->get_talent_pool_ct_csv(false,$param,'b.jg desc, a.pernr',$rowpos,$limits);
	
		$this->load->view('succession/show_talent_pool',$data);
	}

	function show_talent_pool_csv(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$sjf = trim($this->input->get_post('sjf'));
		$ct = trim($this->input->get_post('ct'));
		$jg = trim($this->input->get_post('jg'));
		$f_jg = trim($this->input->get_post('f_jg'));
		
		$param = array();

		$param[] = $this->libs->arrWhere('AND','a.persk',array('10','12','13','14','15','26','41','42','97','98'),1,'IN');
		$param[] = $this->libs->arrWhere('AND','b.kode_corp_title',$ct,'1','=');
		$param[] = $this->libs->arrWhere('AND','c.initials',$sjf,'1','=');
		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.WERKS',$pa,'1','=');
		}

		if($jg != '')
			$param[] = $this->libs->arrWhere('AND','b.jg',$jg,'1','=');

		if($f_jg != '')
			$param[] = $this->libs->arrWhere('AND','b.jg',$f_jg,'1','=');
		

		$data['talent_pool_ct'] = $this->succession_model->get_talent_pool_ct_csv(false,$param,'b.jg desc, a.pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "TALENT_POOL_" . $ct . "_" . $sjf ."_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['talent_pool_ct'], TRUE, $filename);
	}

	function checked_bsm(){
		$data_upd = array('is_checked' => $this->input->get_post('checked'));
		$dcondition = array('pernr' => $this->input->get_post('pernr'), 'method' => $this->input->get_post('method'), 'type' => $this->input->get_post('type'), 'jenis_asesmen' => $this->input->get_post('jenis_asesmen'));
		if($this->db->update('talent_hav_matrix_aspirasi', $data_upd, $dcondition)){
			$this->db->delete('BRILIAN_SOCIETY_MEMBER', array('pernr' => $dcondition['pernr']));
			if($data_upd['is_checked'] == 1){
				$this->db->insert('BRILIAN_SOCIETY_MEMBER', array('pernr' => $dcondition['pernr'], 'status' => 1));
			}
			echo 'ok';
		}	
		else
			echo 'failed';
	}

	public function filter_talent_comite(){
		$data = array(
			'opt_comite_type' => $this->setting_model->mst_comite_type()
        );
		$data['result'] = $this->talent_comite(true);
		$this->load->view('succession/filter_talent_comite', $data);
	}
	
	public function talent_comite($string=false)
	{
		$filter['f_comite_type'] = trim($this->input->get_post('f_comite_type'));
		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();

		$param[] = $this->libs->arrWhere('AND','(Deskripsi',"%{$filter['f_keyword']}%",'1','LIKE');
		$param[] = $this->libs->arrWhere('OR','Title',"%{$filter['f_keyword']}%",'1','LIKE','',')');

		if($filter['f_comite_type'] != '')
			$param[] = $this->libs->arrWhere('AND','ComiteType',$filter['f_comite_type'],'1','=');

		$param[] = $this->libs->arrWhere('AND','Status',1,'1','=');
		$param[] = $this->libs->arrWhere('AND','Modifier',$_SESSION[$this->config->item('session_prefix')]['pernr'],'1','=');
		
		
		/* Paginatian */
		$config['base_url'] = site_url('setting/talent_comite/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->setting_model->get_talent_comite(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		$data['comite'] = $this->setting_model->get_talent_comite(false,$param,'ComiteDate desc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('succession/talent_comite',$data,true); 
		}else{
			$this->load->view('succession/talent_comite',$data);
		}
	}

	function detail_talent_comite(){
		$data = array();
		$filter['id_comite'] = $this->input->get_post('id_comite');
		$data['filter'] = $filter;
		$param = array();
		$param[] = $this->libs->arrWhere('AND','ComiteId',$filter['id_comite'],'1','=');
		$comite = $this->setting_model->get_talent_comite(false,$param,'ComiteDate desc',0,1);
		$data['comite'] = isset($comite[0])?$comite[0]:array();
		$data['comiteBucket'] = $this->setting_model->getComiteBucket($filter['id_comite']);
		$data['opt_comite_type'] = $this->setting_model->mst_comite_type();
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		$this->load->view('succession/detail_talent_comite',$data); 
	}

	function talent_comite_candidates(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['id_comite'] = $this->input->get_post('id_comite');
		$data['filter'] = $filter;

		$data['talent_bucket'] = $this->db->get_where('TalentBucket', array('IdBucket' => $filter['id_bucket']))->row();
		
		$pernrExclude = array();

		$chosen_candidates = $this->db->get_where('TalentComiteBucket', array('ComiteId' => $filter['id_comite']))->result();
		if(count($chosen_candidates) > 0){
			foreach($chosen_candidates as $row){
				$pernrExclude[] = isset($row->Choosen)?$row->Choosen:'-';
			}
		}
		
		$this->db->order_by('Urutan');
		if(count($pernrExclude) > 0)
			$this->db->where_not_in('Pernr', $pernrExclude);
		$data['candidates'] = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $filter['id_bucket']))->result();
		
		$this->load->view('succession/talent_comite_candidates',$data); 
	}

	function talent_comite_candidates_chosen(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['id_comite'] = $this->input->get_post('id_comite');
		$filter['chosen'] = $this->input->get_post('chosen');
		$data['filter'] = $filter;

		$data['talent_bucket'] = $this->db->get_where('TalentBucket', array('IdBucket' => $filter['id_bucket']))->row();
		
		$this->db->order_by('Urutan');
		$data['candidates'] = $this->db->get_where('TalentCandidatesResults', array('IdBucket' => $filter['id_bucket'], 'Pernr' => $filter['chosen']))->result();
		$this->load->view('succession/talent_comite_candidates_chosen',$data); 
	}

	function choose_candidate(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['id_comite'] = $this->input->get_post('id_comite');
		$filter['chosen'] = $this->input->get_post('chosen');
		$data['filter'] = $filter;

		$candidate = $this->talent_model->get_selected_pekerja($filter['chosen']);
		$proses = $this->succession_model->action_choose($filter, $candidate);
		if($proses){
			$this->auditrail_model->add_log('Talent Committee', 'Action Choose Candidate, Comite Id = '. $filter['id_comite'] . ', Bucket Id = ' . $filter['id_bucket'] . ', Pernr = ' . $filter['chosen']);
			$data['message'] = $this->libs->generate_message('success','Data berhasil disimpan.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Data gagal disimpan.');
		}
		
		$param = array();
		$param[] = $this->libs->arrWhere('AND','ComiteId',$filter['id_comite'],'1','=');
		$comite = $this->setting_model->get_talent_comite(false,$param,'ComiteDate desc',0,1);
		$data['comite'] = isset($comite[0])?$comite[0]:array();
		$data['comiteBucket'] = $this->setting_model->getComiteBucket($filter['id_comite']);
		$data['opt_comite_type'] = $this->setting_model->mst_comite_type();
		$data['arr_status'] = $this->libs->arrStatusPublishWithStyle();
		$this->load->view('succession/detail_talent_comite',$data); 

	}

	public function badge_info(){
		$data = array();
		$this->load->view('succession/badge_info',$data);
	}
	
}

/* End of file succession.php */
/* Location: ./application/controllers/succession.php */