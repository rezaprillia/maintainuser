<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Talent extends CI_Controller {
	public function __construct()
   	{
		parent::__construct();
		// Your own constructor code
		
		$this->mysession->check_no_session();
		$this->mysession->check_session_expired();
		$this->load->model(array('user_model', 'option_model', 'talent_model', 'hasil_model', 'access_menu_model'));
   	}
	
	public function filter_hav_matrix(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		if($tipe_uker == 'KP'){
			$data = array(
				'opt_corp_title' => $this->option_model->opt_corp_title()
				, 'opt_hilfm' => $this->option_model->opt_hilfm()
				, 'opt_category' => $this->option_model->opt_category()
				, 'opt_talent_class' => $this->option_model->opt_talent_class()
				, 'opt_type' => $this->option_model->opt_type()
				, 'opt_jenis_asesmen' => $this->option_model->opt_jenis_asesmen()
			);

			$data['result'] = $this->load->view('talent/empty_hav', $data, true);
			$this->load->view('talent/filter_hav_matrix', $data);
		}
		else{
			$data = array(
				'opt_corp_title' => $this->option_model->opt_corp_title_nonkp()
				, 'opt_category' => $this->option_model->opt_category()
				, 'opt_talent_class' => $this->option_model->opt_talent_class()
				, 'opt_type' => $this->option_model->opt_type()
				, 'opt_jenis_asesmen' => $this->option_model->opt_jenis_asesmen()
			);

			$data['result'] = $this->load->view('talent/empty_hav', $data, true);
			$this->load->view('talent/filter_hav_matrix_nonkp', $data);
		}
	}

	public function get_selected_asesmen($jenis_asesmen){
		$selected_asesmen = '';
		$opt_jenis_asesmen = $this->option_model->opt_jenis_asesmen();
		foreach($opt_jenis_asesmen as $idx => $item){
			if($jenis_asesmen == $idx){
				$selected_asesmen = $item;
			}
		}
		return $selected_asesmen;
	}
	
	public function hav_matrix(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$data = array();
		$corp_title = $this->input->post('f_corp_title');
		$job = $this->input->post('f_job');
        $method = $this->input->post('f_category');
        $talent_class = $this->input->post('f_talent_class');
		$type = $this->input->post('f_type');
		$jenis_asesmen = $this->input->post('f_jenis_asesmen');
		$personnalarea = $pa;
		$tipeuker = $tipe_uker;
		
		if($tipe_uker == 'KP'){
			$param['corp_title'] = $data['corp_title'] = implode(',',$corp_title);
			$param['job'] = $data['job'] = implode(',',$job);
			$param['method'] = $data['method'] = implode(',',$method);
			$param['talent_class'] = $data['talent_class'] = $talent_class;
			$param['type'] = $data['type'] = !empty($type)?implode(',',$type):array();
			$param['jenis_asesmen'] = $data['jenis_asesmen'] = $jenis_asesmen;
		}
		else{
			$param['corp_title'] = $data['corp_title'] = implode(',',$corp_title);
			$param['method'] = $data['method'] = implode(',',$method);
			$param['talent_class'] = $data['talent_class'] = $talent_class;
			$param['type'] = $data['type'] = !empty($type)?implode(',',$type):array();
			$param['jenis_asesmen'] = $data['jenis_asesmen'] = $jenis_asesmen;
		}
		$data['param'] = $param;
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		
		if(is_array($method) && $talent_class != '' && $jenis_asesmen != ''){
			$condition[] = $this->libs->arrWhere('AND','a.corp_title',$corp_title,0,'IN');
			$condition[] = $this->libs->arrWhere('AND','a.method',$method,0,'IN');
			$condition[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$jenis_asesmen,0,'=');
			if($tipe_uker == 'KP'){
				$condition[] = $this->libs->arrWhere('AND','a.hilfm',$job,1,'IN');
			}

			if($type == array("1", "2")){
				$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
			}
			else if($type == array("1")){
				$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
			}
			else if($type == array("2")){
				$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
			}
			else{
				$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
			}

			if($tipe_uker != 'KP'){
				$condition[] = $this->libs->arrWhere('AND','b.WERKS',$pa,'1','=');
			}
			
			if($talent_class == 1){
				$data['Q1'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q1', 'Q2'");
				$data['Q2'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q3','Q4'");
				$data['Q3'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q5','Q6'");
				$data['Q4'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q7','Q8'");
				$data['Q5'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q9'");
				$this->load->view('talent/five_talent_class', $data);
			}
			else{
				$data['Q1'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q1'");
				$data['Q2'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q2'");
				$data['Q3'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q3'");
				$data['Q4'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q4'");
				$data['Q5'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q5'");
				$data['Q6'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q6'");
				$data['Q7'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q7'");
				$data['Q8'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q8'");
				$data['Q9'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q9'");
				$this->load->view('talent/nine_talent_class', $data);
			}
			
		}
		else{
			$this->load->view('talent/empty_hav', $data);
		}
	}
	
	public function detail_nine_talent_class(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		
		$filter['corp_title'] = $this->input->get_post('corp_title');
		if($tipe_uker == 'KP'){
			$filter['job'] = explode(',', $this->input->get_post('job'));
		}
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = explode(',', $this->input->get_post('talent_class'));
		//$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = explode(',', $this->input->get_post('type'));
		//$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}

		if($tipe_uker == 'KP'){
			if(count($filter['job']) > 0){
				$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.hilfm',$this->input->get_post('job'),1,'IN');
				$filter['job'] = $this->input->get_post('job');
			}
		}
		
		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','d.WERKS',$pa,'1','=');
		}
		
		if(count($filter['talent_class']) > 0){
			$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.talent_class',$this->input->get_post('talent_class'),1,'IN');
			$filter['talent_class'] = $this->input->get_post('talent_class');
		}
		
		
		if(count($filter['type']) > 0){
			if($filter['type'] == array("1", "2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
			}
			else if($filter['type'] == array("1")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
			}
			else if($filter['type'] == array("2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
			}
		}
		else{
			$filter['type'] = $this->input->get_post('type');
			if($filter['type'] == array("1", "2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
			}
			else if($filter['type'] == array("1")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
			}
			else if($filter['type'] == array("2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
			}
			
		}

		/* Paginatian */
		$config['base_url'] = site_url('talent/detail_nine_talent_class/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_detail_nine_talent_class(true,$param);
		$config['per_page'] = 20;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['opt_direktorat'] = $this->option_model->opt_direktorat();
		$data['hav'] = $this->talent_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir',$rowpos,$limits);
		//$data['hav'] = $this->talent_model->get_detail_nine_talent_class(false,$param,'corp_title asc, count_voter desc, urutan',$rowpos,$limits);
		$this->load->view('talent/detail_nine_talent_class',$data);
	}
	
	public function detail_nine_talent_class_back(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['corp_title'] = $this->input->get_post('corp_title');
		if($tipe_uker == 'KP'){
			$filter['job'] = explode(',', $this->input->get_post('job'));
		}
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = explode(',', $this->input->get_post('talent_class'));
		$filter['type'] = explode(',', $this->input->get_post('type'));
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','d.WERKS',$pa,'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/detail_nine_talent_class/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_detail_nine_talent_class(true,$param);
		$config['per_page'] = 20;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['opt_direktorat'] = $this->option_model->opt_direktorat();
		$data['hav'] = $this->talent_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir',$rowpos,$limits);
		//$data['hav'] = $this->talent_model->get_detail_nine_talent_class(false,$param,'avg_score desc, tanggallahir',$rowpos,$limits);
		
		$this->load->view('talent/detail_nine_talent_class',$data);
	}
	
	public function detail_five_talent_class(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['corp_title'] = $this->input->get_post('corp_title');
		if($tipe_uker == 'KP'){
			$filter['job'] = explode(',', $this->input->get_post('job'));
		}
		$filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = explode(',', $this->input->get_post('talent_class'));
		$filter['type'] = explode(',', $this->input->get_post('type'));
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');

		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}

		if($tipe_uker == 'KP'){
			if(count($filter['job']) > 0){
				$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.hilfm',$this->input->get_post('job'),1,'IN');
				$filter['job'] = $this->input->get_post('job');
			}
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','d.WERKS',$pa,'1','=');
		}
		
		if(count($filter['talent_class']) > 0){
			$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.talent_class',$this->input->get_post('talent_class'),1,'IN');
			$filter['talent_class'] = $this->input->get_post('talent_class');
		}
		
		
		if(count($filter['type']) > 0){
			if($filter['type'] == array("1", "2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
			}
			else if($filter['type'] == array("1")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
			}
			else if($filter['type'] == array("2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
			}
		}
		else{
			$filter['type'] = $this->input->get_post('type');
			if($filter['type'] == array("1", "2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
			}
			else if($filter['type'] == array("1")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
			}
			else if($filter['type'] == array("2")){
				$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
			}
			else{
				$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
			}
			
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/detail_five_talent_class/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_detail_five_talent_class(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['opt_direktorat'] = $this->option_model->opt_direktorat();
		//$data['hav'] = $this->talent_model->get_detail_five_talent_class(false,$param,'talent_class, avg_score desc, tanggallahir',$rowpos,$limits);
		$data['hav'] = $this->talent_model->get_detail_five_talent_class(false,$param,'talent_class asc, corp_title asc, sum_avg desc, tanggallahir',$rowpos,$limits);
		
		$this->load->view('talent/detail_five_talent_class',$data);
	}
	
	public function detail_five_talent_class_back(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/detail_five_talent_class/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_detail_five_talent_class(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['opt_direktorat'] = $this->option_model->opt_direktorat();
		//$data['hav'] = $this->talent_model->get_detail_five_talent_class(false,$param,'talent_class, avg_score desc, tanggallahir',$rowpos,$limits);
		$data['hav'] = $this->talent_model->get_detail_five_talent_class(false,$param,'talent_class asc, corp_title asc, sum_avg desc, tanggallahir',$rowpos,$limits);

		$this->load->view('talent/detail_five_talent_class',$data);
	}
	
	function nine_talent_class_pdf() {
		$corp_title = $this->input->get_post('corp_title');
		$job = explode(',',$this->input->get_post('job'));
        $method = $this->input->get_post('method');
		$type = explode(',', $this->input->get_post('type'));
		$jenis_asesmen = $this->input->get_post('jenis_asesmen');
		
		if($type == array("1", "2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($type == array("1")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($type == array("2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$condition[] = $this->libs->arrWhere('AND','corp_title','('.$corp_title.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
		$condition[] = $this->libs->arrWhere('AND','method','('.$method.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
		
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		$data['Q1'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q1'");
		$data['Q2'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q2'");
		$data['Q3'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q3'");
		$data['Q4'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q4'");
		$data['Q5'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q5'");
		$data['Q6'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q6'");
		$data['Q7'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q7'");
		$data['Q8'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q8'");
		$data['Q9'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q9'");
		
		$data['content'] = $this->load->view('talent/nine_talent_class_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Nine_Talent_Class_HAV_Matrix', 'A4', 'Landscape');
    }
	
	function nine_talent_class_excel() {
		$corp_title = $this->input->get_post('corp_title');
		$job = explode(',',$this->input->get_post('job'));
        $method = $this->input->get_post('method');
		$type = explode(',', $this->input->get_post('type'));
		$jenis_asesmen = $this->input->get_post('jenis_asesmen');
		
		if($type == array("1", "2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($type == array("1")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($type == array("2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$condition[] = $this->libs->arrWhere('AND','corp_title','('.$corp_title.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
		$condition[] = $this->libs->arrWhere('AND','method','('.$method.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		$data['Q1'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q1'");
		$data['Q2'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q2'");
		$data['Q3'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q3'");
		$data['Q4'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q4'");
		$data['Q5'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q5'");
		$data['Q6'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q6'");
		$data['Q7'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q7'");
		$data['Q8'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q8'");
		$data['Q9'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q9'");
		
		$data['content'] = $this->load->view('talent/nine_talent_class_pdf', $data, true);
        $data['file_name'] = 'Nine_Talent_Class_HAV_Matrix';
        $this->load->view('theme/excel_template', $data);
    }
	
	function five_talent_class_pdf() {
		$corp_title = $this->input->get_post('corp_title');
		$job = explode(',',$this->input->get_post('job'));
        $method = $this->input->get_post('method');
		$type = explode(',', $this->input->get_post('type'));
		$jenis_asesmen = $this->input->get_post('jenis_asesmen');
		
		if($type == array("1", "2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($type == array("1")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($type == array("2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$condition[] = $this->libs->arrWhere('AND','corp_title','('.$corp_title.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
		$condition[] = $this->libs->arrWhere('AND','method','('.$method.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		$data['Q1'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q1'");
		$data['Q2'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q2','Q3','Q4'");
		$data['Q3'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q5','Q7'");
		$data['Q4'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q6','Q8'");
		$data['Q5'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q9'");
		
		$data['content'] = $this->load->view('talent/five_talent_class_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Five_Talent_Class_HAV_Matrix', 'A4', 'Landscape');
    }
	
	function five_talent_class_excel() {
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$corp_title = $this->input->get_post('corp_title');
		$job = explode(',',$this->input->get_post('job'));
        $method = $this->input->get_post('method');
		$type = explode(',', $this->input->get_post('type'));
		$jenis_asesmen = $this->input->get_post('jenis_asesmen');
		
		if($type == array("1", "2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($type == array("1")){
			$condition[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($type == array("2")){
			$condition[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$condition[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$condition[] = $this->libs->arrWhere('AND','corp_title','('.$corp_title.')',0,'IN');
		if($tipe_uker == 'KP'){
			$condition[] = $this->libs->arrWhere('AND','hilfm',$job,1,'IN');
		}
		$condition[] = $this->libs->arrWhere('AND','method','('.$method.')',0,'IN');
		$condition[] = $this->libs->arrWhere('AND','jenis_asesmen',$jenis_asesmen,0,'=');
		
		$data['selected_asesmen'] = $this->get_selected_asesmen($jenis_asesmen);
		$data['Q1'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q1'");
		$data['Q2'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q2','Q3','Q4'");
		$data['Q3'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q5','Q7'");
		$data['Q4'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q6','Q8'");
		$data['Q5'] = $this->talent_model->get_mapping_hav_matrix($condition, "'Q9'");
		
		$data['content'] = $this->load->view('talent/five_talent_class_excel', $data, true);
        $data['file_name'] = 'Five_Talent_Class_HAV_Matrix';
        $this->load->view('theme/excel_template', $data);
    }
	
	function detail_nine_talent_class_pdf(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}
		
		$data['hav'] = $this->talent_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir');
		$data['filter'] = $filter;
		$data['content'] = $this->load->view('talent/detail_nine_talent_class_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Detail_Nine_Talent_Class_HAV_Matrix', 'A4', 'Landscape');
	}
	
	function detail_nine_talent_class_excel(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		
		$filter['corp_title'] = $this->input->get_post('corp_title');
		if($tipe_uker == 'KP'){
			$filter['job'] = $this->input->get_post('job');
		}
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		if($tipe_uker == 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		}
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');

		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','d.WERKS',$pa,'1','=');
		}
		
		$data['hav'] = $this->talent_model->get_detail_nine_talent_class(false,$param,'corp_title asc, sum_avg desc, tanggallahir');
		$data['filter'] = $filter;
		$data['content'] = $this->load->view('talent/detail_nine_talent_class_pdf', $data, true);
        $data['file_name'] = 'Detail_Nine_Talent_Class_HAV_Matrix';
        $this->load->view('theme/excel_template', $data);
	}
	
	function detail_five_talent_class_pdf(){
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','corp_title','('.$filter['corp_title'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','hilfm',$filter['job'],1,'IN');
		$param[] = $this->libs->arrWhere('AND','method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','talent_class',$filter['talent_class'],1,'IN');
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','type',array("0"),1,'IN');
		}
		
		$data['hav'] = $this->talent_model->get_detail_five_talent_class(false,$param,'talent_class, avg_score desc, tanggallahir');
		$data['filter'] = $filter;
		$data['content'] = $this->load->view('talent/detail_five_talent_class_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Detail_Five_Talent_Class_HAV_Matrix', 'A4', 'Landscape');
	}
	
	function detail_five_talent_class_excel(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['corp_title'] = $this->input->get_post('corp_title');
		if($tipe_uker == 'KP'){
			$filter['job'] = $this->input->get_post('job');
		}
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['type'] = $this->input->get_post('type');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');
		$filter['f_direktorat'] = $this->input->get_post('f_direktorat');
		
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','a.corp_title','('.$filter['corp_title'].')',0,'IN');
		if($tipe_uker == 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.hilfm',$filter['job'],1,'IN');
		}
		$param[] = $this->libs->arrWhere('AND','a.method','('.$filter['method'].')',0,'IN');
		$param[] = $this->libs->arrWhere('AND','a.talent_class',$filter['talent_class'],1,'IN');

		$param[] = $this->libs->arrWhere('AND','a.jenis_asesmen',$filter['jenis_asesmen'],0,'=');

		if($filter['f_pekerja'] != ''){
			$param[] = $this->libs->arrWhere('AND','a.pernr',$filter['f_pekerja'],1,'=');
		}
		if($filter['f_direktorat'] != ''){
			$param[] = $this->libs->arrWhere('AND','c.objid',$filter['f_direktorat'],1,'=');
		}
		
		if($filter['type'] == array("1", "2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1", "2"),1,'IN');
		}
		else if($filter['type'] == array("1")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("1"),1,'IN');
		}
		else if($filter['type'] == array("2")){
			$param[] = $this->libs->arrWhere('AND','a.type',array("2"),1,'IN');
		}
		else{
			$param[] = $this->libs->arrWhere('AND','a.type',array("0"),1,'IN');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','d.WERKS',$pa,'1','=');
		}
		
		$data['hav'] = $this->talent_model->get_detail_nine_talent_class(false,$param,'talent_class asc, corp_title asc, sum_avg desc, tanggallahir');
		$data['filter'] = $filter;
		$data['content'] = $this->load->view('talent/detail_five_talent_class_pdf', $data, true);
        $data['file_name'] = 'Detail_Five_Talent_Class_HAV_Matrix';
        $this->load->view('theme/excel_template', $data);
	}
	
	public function detail_pekerja()
	{
		$filter['corp_title'] = $this->input->get_post('corp_title');
		$filter['job'] = $this->input->get_post('job');
        $filter['method'] = $this->input->get_post('method');
		$filter['talent_class'] = $this->input->get_post('talent_class');
		$filter['legend'] = $this->input->get_post('legend');
		$filter['pernr'] = $this->input->get_post('pernr');
		$filter['compare_pernr'] = $this->input->get_post('compare_pernr');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['source'] = $this->input->get_post('source');
		$filter['ctrl'] = $this->input->get_post('ctrl');
		$filter['bucket'] = $this->input->get_post('bucket');
		$filter['type'] = $this->input->get_post('type');
		$filter['jenis_asesmen'] = $this->input->get_post('jenis_asesmen');
		$filter['status'] = $this->input->get_post('status');
		$filter['orgeh'] = $this->input->get_post('orgeh');
		$filter['hilfm'] = $this->input->get_post('hilfm');
		$filter['jenis_aspirasi'] = $this->input->get_post('jenis_aspirasi');
		$filter['corp_title_id'] = $this->input->get_post('corp_title_id');
		
		
		$data['pekerja'] 		= $this->talent_model->data_personal($filter['pernr']);
		$data['file_image'] 	= $this->hasil_model->get_foto($filter['pernr']);

		$data['alamat_domisili'] = $this->hasil_model->get_domisili($filter['pernr']);
		$data['keluarga'] 		= $this->hasil_model->get_data_keluarga($filter['pernr']);
		$data['pendidikan'] 	= $this->hasil_model->get_data_pendidikan($filter['pernr']);
		$data['riwayat'] 		= $this->hasil_model->get_riwayat_jabatan($filter['pernr']);
		$data['smk'] 			= $this->hasil_model->get_history_smk($filter['pernr']);
		$data['itp'] 			= $this->hasil_model->get_history_itp($filter['pernr']);
		$data['training'] 		= $this->hasil_model->get_data_training($filter['pernr']);
		$data['asesmen'] 		= $this->hasil_model->get_history_asesmen($filter['pernr']);
		$data['klaim'] 			= $this->hasil_model->get_history_kesehatan($filter['pernr']);
		$data['insus'] 			= $this->hasil_model->get_history_insus($filter['pernr']);
		
		$data['filter'] = $filter;
		
		$data['detail_profile'] = $this->load->view('talent/detail_profile',$data,TRUE);
		$this->load->view('talent/detail_pekerja',$data);
	}
	
	/*public function create_pdf_detail_pekerja($pernr)
	{
		$filter['pernr'] = trim($pernr);

		$data['pekerja'] 		= $this->talent_model->data_personal($filter['pernr']);
		$data['file_image'] 	= $this->hasil_model->get_foto($filter['pernr']);

		$data['alamat_domisili'] = $this->hasil_model->get_domisili($filter['pernr']);
		$data['keluarga'] 		= $this->hasil_model->get_data_keluarga($filter['pernr']);
		$data['pendidikan'] 	= $this->hasil_model->get_data_pendidikan($filter['pernr']);
		$data['riwayat'] 		= $this->hasil_model->get_riwayat_jabatan($filter['pernr']);
		$data['smk'] 			= $this->hasil_model->get_history_smk($filter['pernr']);
		$data['itp'] 			= $this->hasil_model->get_history_itp($filter['pernr']);
		$data['training'] 		= $this->hasil_model->get_data_training($filter['pernr']);
		$data['asesmen'] 		= $this->hasil_model->get_history_asesmen($filter['pernr']);
		$data['klaim'] 			= $this->hasil_model->get_history_kesehatan($filter['pernr']);
		$data['insus'] 			= $this->hasil_model->get_history_insus($filter['pernr']);
		
		$data['content'] = $this->load->view('talent/detail_profile_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'CV_'.$filter['pernr'], 'A4', 'Portrait');
	}*/
	
	public function filter_succession_plan(){
		$data = array(
			'opt_organization_area' => $this->option_model->opt_organization_area(),
			'opt_severity_level' => $this->option_model->opt_severity_level(),
        );
		$data['result'] = $this->load->view('talent/empty_organization_area', $data, true);
		$this->load->view('talent/filter_succession_plan', $data);
	}
	
	public function succession_plan(){
		$data = array();
		$f_organization_area = $this->input->post('f_organization_area');
		$f_severity_level = $this->input->post('f_severity_level');
		$data['severity_level'] = $f_severity_level;
		if($f_organization_area != ''){
			$data['parent'] = $this->db->get_where('mst_organization' , array('organization_level' => 0, 'organization_area' => $f_organization_area))->row();
			$this->load->view('talent/succession_plan', $data);
		}
		else{
			$this->load->view('talent/empty_organization_area', $data);
		}
	}
	
	public function keyjob_list(){
		$filter['organization'] = $this->input->get_post('organization');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','organization',$filter['organization'],1,'=');
		$param[] = $this->libs->arrWhere('AND','status',1,1,'=');
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/keyjob_list/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_keyjobs(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		$data['keyjobs'] = $this->talent_model->get_keyjobs(false,$param,'keyjobs',$rowpos,$limits);
		
		$this->load->view('talent/keyjob_list',$data);
	}
	
	public function successor_detail(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');

		$param_sort['sort'] = $this->input->get_post('sort');
		$param_sort['sort_column'] = $this->input->get_post('sort_column');
		$param_sort['direction'] = $this->input->get_post('direction');

		if($param_sort['sort'] == '' && $param_sort['sort_column'] == ''){
			$param_sort['sort_column'] = 'overall_compability';
			$param_sort['sort'] = 'desc';
			$param_sort['direction'] = 'up';
		}

		$s_sort = 'asc';
		if($param_sort['sort'] == 'asc')
			$s_sort = 'desc';


		$sort_by = ($param_sort['sort_column'] . ' ' . $param_sort['sort'] .', tanggallahir ' . $s_sort);
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		if($filter['f_pekerja'] != '')
			$param[] = $this->libs->arrWhere('AND','pernr',$filter['f_pekerja'],1,'=');
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/successor_detail/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_successors(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];
		$data['filter'] = $filter;
		$data['param_sort'] = $param_sort;
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		$data['successors'] = $this->talent_model->get_successors(false,$param,$sort_by,$rowpos,$limits);
		
		$this->load->view('talent/successor_detail',$data);
	}
	
	function successor_detail_pdf(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');

		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		
		$data['successors'] = $this->talent_model->get_successors(false,$param,'overall_compability desc, tanggallahir');
		
		$data['filter'] = $filter;
		$keyjobs = isset($data['keyjobs']->keyjobs_desc)?str_replace(' ','_',$data['keyjobs']->keyjobs_desc):'-';
		$organization = isset($data['organization']->organization_abr)?str_replace(' ','_',$data['organization']->organization_abr):'-';
		$data['content'] = $this->load->view('talent/successor_detail_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Succession_Plan_'.$keyjobs.'_'.$organization, 'A4', 'Landscape');
	}
	
	function successor_detail_excel(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');

		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		
		$data['successors'] = $this->talent_model->get_successors(false,$param,'overall_compability desc, tanggallahir');
		
		$data['filter'] = $filter;
		$keyjobs = isset($data['keyjobs']->keyjobs_desc)?str_replace(' ','_',$data['keyjobs']->keyjobs_desc):'-';
		$organization = isset($data['organization']->organization_abr)?str_replace(' ','_',$data['organization']->organization_abr):'-';
		
		$data['content'] = $this->load->view('talent/successor_detail_pdf', $data, true);
        $data['file_name'] = 'Succession_Plan_'.$keyjobs.'_'.$organization;
        $this->load->view('theme/excel_template', $data);
	}
	
	function successors_compare(){
		$data = array();
		$filter['compare_pernr'] = $this->input->get_post('compare_pernr');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['bucket'] = $this->input->get_post('bucket');
		$filter['source'] = $this->input->get_post('source');

		$param = array();
		$data['filter'] = $filter;
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		$param[] = $this->libs->arrWhere('AND','is_checked',1,1,'=');
		
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		if(isset($filter['bucket'])){
			if($filter['bucket'] != '' && $filter['bucket'] != 0){
				$param[] = $this->libs->arrWhere('AND','id_bucket',$filter['bucket'],1,'=');
				$data['successors'] = $this->talent_model->get_bucket_successors(false,$param,'overall_compability desc, tanggallahir');
			}
			else{
				$data['successors'] = $this->talent_model->get_successors(false,$param,'overall_compability desc, tanggallahir');
			}
		}
		else{
			$data['successors'] = $this->talent_model->get_successors(false,$param,'overall_compability desc, tanggallahir');
		}
		
		
		$this->load->view('talent/successors_compare',$data);
		
	}
	
	function director_profile(){
		$data = array();
		$filter['organization'] = $this->input->get_post('organization');
		$param = array();
		$data['filter'] = $filter;
		$param[] = $this->libs->arrWhere('AND','organization',$filter['organization'],1,'=');
		$param[] = $this->libs->arrWhere('AND','status',1,1,'=');
		
		$organization = $this->talent_model->get_organization_top_holder($filter['organization']);
		
		if(isset($organization->pernr)){
			$data['profile'] = $organization;
			$data['pendidikan'] = $this->db->get_where('mst_riwayat_pendidikan', array('pernr' => $organization->pernr))->result();
			$data['pekerjaan'] = $this->db->get_where('mst_riwayat_pekerjaan', array('pernr' => $organization->pernr))->result();
			
			$this->load->view('talent/director_profile',$data);
		}
		else{
			$data['empty'] = $this->load->view('talent/empty_successors', $data, true);
			$this->load->view('talent/director_profile',$data);
		}
		
	}
	
	public function create_pdf_detail_pekerja()
	{	
		$pernr 	= trim($this->input->post('pernr'));
		if($pernr!='')
			{
			$data['file_image'] 	= $this->hasil_model->get_foto($pernr);
			$data['personal'] 	= $this->input->post('personal');
			$data['keluarga'] 	= $this->input->post('keluarga');
			$data['pendidikan'] 	= $this->input->post('pendidikan');
			$data['karir'] 	= $this->input->post('karir');
			$data['riwayat_jabatan'] 	= $this->input->post('riwayat_jabatan');
			$data['riwayat_training'] 	= $this->input->post('riwayat_training');
			$data['riwayat_smk'] 	= $this->input->post('riwayat_smk');
			$data['riwayat_itp'] 	= $this->input->post('riwayat_itp');
			$data['riwayat_assesmen'] 	= $this->input->post('riwayat_assesmen');
			$data['riwayat_klaim'] 	= $this->input->post('riwayat_klaim');
			$data['riwayat_insus'] 	= $this->input->post('riwayat_insus');

			$file_name = 'cv_' . $pernr;
			$data['content'] = $this->load->view('hasil/detail_profile_pdf',$data,TRUE);
			}
		else
			{
			$file_name = 'invalid';
			$data['content'] = 'Data tidak valid';
			}

		$html = $this->load->view('theme/pdf_template',$data,true);			
		$this->libs->wkhtmltopdf($html,$file_name);
	}

	public function create_excel_detail_pekerja()
	{
		$pernr 	= trim($this->input->post('pernr'));
		if($pernr!='')
			{
			$data['file_image'] 	= $this->hasil_model->get_foto($pernr);
			$data['personal'] 	= $this->input->post('personal');
			$data['keluarga'] 	= $this->input->post('keluarga');
			$data['pendidikan'] 	= $this->input->post('pendidikan');
			$data['karir'] 	= $this->input->post('karir');
			$data['riwayat_jabatan'] 	= $this->input->post('riwayat_jabatan');
			$data['riwayat_training'] 	= $this->input->post('riwayat_training');
			$data['riwayat_smk'] 	= $this->input->post('riwayat_smk');
			$data['riwayat_itp'] 	= $this->input->post('riwayat_itp');
			$data['riwayat_assesmen'] 	= $this->input->post('riwayat_assesmen');
			$data['riwayat_klaim'] 	= $this->input->post('riwayat_klaim');
			$data['riwayat_insus'] 	= $this->input->post('riwayat_insus');

			$file_name = $pernr;
			$data['content'] = $this->load->view('hasil/detail_profile_pdf',$data,TRUE);
			}
		else
			{
			$file_name = 'invalid';
			$data['content'] = 'Data tidak valid';
			}
      $data['file_name'] = 'cv_' . $pernr;
      $this->load->view('theme/excel_template', $data);
	}
	
	public function filter_succession_plan_person(){
		$data = array(
			'opt_organization_area' => $this->option_model->opt_organization_area(),
			'opt_severity_level' => $this->option_model->opt_severity_level(),
        );
		$data['result'] = $this->load->view('talent/empty_organization_area', $data, true);
		$this->load->view('talent/filter_succession_plan_person', $data);
	}
	
	public function succession_plan_person(){
		$data = array();
		$f_organization_area = $this->input->post('f_organization_area');
		if($f_organization_area != ''){
			$data['parent'] = $this->db->get_where('mst_organization' , array('organization_level' => 0, 'organization_area' => $f_organization_area))->row();
			$this->load->view('talent/succession_plan_person', $data);
		}
		else{
			$this->load->view('talent/empty_organization_area', $data);
		}
	}
	
	public function keyjob_list_person(){
		$filter['organization'] = $this->input->get_post('organization');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','organization',$filter['organization'],1,'=');
		$param[] = $this->libs->arrWhere('AND','status',1,1,'=');
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/keyjob_list_person/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_keyjobs(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		$data['keyjobs'] = $this->talent_model->get_keyjobs(false,$param,'keyjobs',$rowpos,$limits);
		
		$this->load->view('talent/keyjob_list_person',$data);
	}
	
	public function successor_detail_person(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/successor_detail_person/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_successors_person(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];
		$data['filter'] = $filter;
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		$data['successors'] = $this->talent_model->get_successors_person(false,$param,'overall_compability desc, tanggallahir',$rowpos,$limits);
		
		$this->load->view('talent/successor_detail_person',$data);
	}
	
	function successor_detail_person_pdf(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');

		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		
		$data['successors'] = $this->talent_model->get_successors_person(false,$param,'overall_compability desc, tanggallahir');
		
		$data['filter'] = $filter;
		$keyjobs = isset($data['keyjobs']->keyjobs_desc)?str_replace(' ','_',$data['keyjobs']->keyjobs_desc):'-';
		$organization = isset($data['organization']->organization_abr)?str_replace(' ','_',$data['organization']->organization_abr):'-';
		$data['content'] = $this->load->view('talent/successor_detail_person_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Succession_Plan_Person_'.$keyjobs.'_'.$organization, 'A4', 'Landscape');
	}
	
	function successor_detail_person_excel(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');

		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		
		$data['successors'] = $this->talent_model->get_successors_person(false,$param,'overall_compability desc, tanggallahir');
		
		$data['filter'] = $filter;
		$keyjobs = isset($data['keyjobs']->keyjobs_desc)?str_replace(' ','_',$data['keyjobs']->keyjobs_desc):'-';
		$organization = isset($data['organization']->organization_abr)?str_replace(' ','_',$data['organization']->organization_abr):'-';
		
		$data['content'] = $this->load->view('talent/successor_detail_person_pdf', $data, true);
        $data['file_name'] = 'Succession_Plan_Person_'.$keyjobs.'_'.$organization;
        $this->load->view('theme/excel_template', $data);
	}

	function checked_talent(){
		$data_upd = array('is_checked' => $this->input->get_post('checked'));
		$dcondition = array('keyjobs' => $this->input->get_post('keyjobs'), 'pernr' => $this->input->get_post('pernr'));
		if($this->db->update('talent_succession_plan_results', $data_upd, $dcondition))
			echo 'ok';
		else
			echo 'failed';
	}

	function save_candidates(){
		$data = array();
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$filter['bucket'] = $this->input->get_post('bucket');

		$param = array();
		$data['filter'] = $filter;

		$param_ins = array(
			'keyjobs' => $filter['keyjobs']
			, 'organization' => $filter['organization']
			, 'bucket_name' => $this->input->get_post('bucket_name')
			, 'modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			, 'modified_by' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			, 'modified_date' => date('Y-m-d H:i:s')
			, 'status' => 0
		);

		if(isset($filter['bucket'])){
			if($filter['bucket'] != '' && $filter['bucket'] != ''){
				$arr_input = $this->talent_model->insert_new_candidates_bucket($param_ins, $filter);
			}
			else{
				$arr_input = $this->talent_model->insert_candidates_bucket($param_ins, $filter);
			}
		}
		else{
			$arr_input = $this->talent_model->insert_candidates_bucket($param_ins, $filter);
		}

		if($arr_input['status']){
			$this->auditrail_model->add_log('Talent', 'Insert Candidates Bucket');
			$data['message'] = $this->libs->generate_message('success',$arr_input['message']);
			unset($_POST);
		}else{
			$data['message'] = $this->libs->generate_message('danger',$arr_input['message']);
		}
		
		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusApprover();

		$data['result'] = $this->candidates(true);
		$this->load->view('talent/filter_candidates', $data);
	}

	public function filter_candidates(){
		$data = array(
			'opt_status' => array(''=>'- Semua status -') + $this->libs->arrStatusApprover()
        );
		$data['result'] = $this->candidates(true);
		$this->load->view('talent/filter_candidates', $data);
	}
	
	public function candidates($string=false)
	{
		$filter['f_status'] = trim($this->input->post('f_status'));
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_status']!=''){
			$param[] = $this->libs->arrWhere('AND','a.status',"{$filter['f_status']}",'1','=');
		}
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(b.keyjobs_desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.organization_desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.organization_abr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.bucket_name',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','a.modifier',$_SESSION[$this->config->item('session_prefix')]['pernr'],'1','=');
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/candidates/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_candidates(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$data['candidates'] = $this->talent_model->get_candidates(false,$param,'a.modified_date desc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('talent/candidates',$data,true); 
		}else{
			$this->load->view('talent/candidates',$data);
		}
	}

	function detail_bucket(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$data['filter'] = $filter;

		$data['talent_bucket'] = $this->db->get_where('talent_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		$this->db->order_by('urutan');
		$data['candidates'] = $this->db->get_where('talent_candidates_results', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$data['content'] = $this->load->view('talent/candidates_content',$data,true); 
		$this->load->view('talent/detail_candidates',$data); 
	}

	public function get_checker_signer() {
		$term = $this->db->escape_str(trim($this->input->get_post('searchTerm')));

		$cs = $this->talent_model->get_checker_signer($term);
		if($cs->num_rows() > 0) {
			foreach($cs->result() as $idx=>$row){
				$result[$idx] = array('id'=>$row->PERNR, 'text'=>$row->PERNR ."/". $row->SNAME ."/".$row->STELL_TX ."/".$row->KOSTL_TX); 
			}
		} else {
			$result = array(0=>array('id'=>'','text'=>'- Data Tidak Ditemukan -'));
		}
		
		echo json_encode($result);
	}

	public function get_auto_candidates() {
		$term = $this->db->escape_str(trim($this->input->get_post('searchTerm')));

		$cs = $this->talent_model->get_auto_candidates($term);
		if($cs->num_rows() > 0) {
			foreach($cs->result() as $idx=>$row){
				$result[$idx] = array('id'=>$row->PERNR, 'text'=>$row->PERNR ."/". $row->SNAME ."/".$row->STELL_TX ."/".$row->KOSTL_TX); 
			}
		} else {
			$result = array(0=>array('id'=>'','text'=>'- Data Tidak Ditemukan -'));
		}
		
		echo json_encode($result);
	}

	function update_ordered_list(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['pernr'] = $this->input->get_post('pernr');
		$new_urutan = $this->input->get_post('urutan');

		$proses = $this->talent_model->update_ordered_list($filter, $new_urutan);

		if($proses['status']){
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}

		$data['talent_bucket'] = $this->db->get_where('talent_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $data['keyjobs']->organization))->row();
		$this->db->order_by('urutan');
		$data['candidates'] = $this->db->get_where('talent_candidates_results', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$this->load->view('talent/candidates_content',$data); 
	}

	function delete_candidates(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['pernr'] = $this->input->get_post('pernr');

		$proses = $this->talent_model->delete_candidates($filter);

		if($proses['status']){
			$this->auditrail_model->add_log('Talent', 'Delete Candidates PN = ' . $filter['pernr'] . ', Keyjobs = ' . $filter['keyjobs']  . ', Id Bucket = ' . $filter['id_bucket']);
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		}
		else{
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}
	
		$data['talent_bucket'] = $this->db->get_where('talent_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $data['keyjobs']->organization))->row();
		$this->db->order_by('urutan');
		$data['candidates'] = $this->db->get_where('talent_candidates_results', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$this->load->view('talent/candidates_content',$data); 
	}

	function add_new_candidates(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');

		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $data['keyjobs']->organization))->row();

		$this->load->view('talent/form_add_candidates',$data); 
	}

	function save_new_candidates(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['candidates'] = $this->input->get_post('candidates');
		$filter['overall_compability'] = $this->input->get_post('overall_compability');

		$candidates = $this->talent_model->get_selected_pekerja($filter['candidates']);

		$is_exist = $this->talent_model->is_candidates_exist($filter);
		if(!$is_exist){
			if(isset($candidates->PERNR)){
				$proses = $this->talent_model->save_new_candidates($filter, $candidates);
				if($proses['status']){
					$this->auditrail_model->add_log('Talent', 'Add New Candidates PN = ' . $filter['candidates'] . ', Keyjobs = ' . $filter['keyjobs']  . ', Id Bucket = ' . $filter['id_bucket']);
					$data['message'] = $this->libs->generate_message('success',$proses['message']);
				}
				else{
					$data['message'] = $this->libs->generate_message('danger',$proses['message']);
				}
			}
			else{
				$data['message'] = $this->libs->generate_message('danger','Data Pekerja Tidak Ditemukan.');
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Data Pekerja Sudah Ada.');
		}

		$data['talent_bucket'] = $this->db->get_where('talent_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $data['keyjobs']->organization))->row();
		$this->db->order_by('urutan');
		$data['candidates'] = $this->db->get_where('talent_candidates_results', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$this->load->view('talent/candidates_content',$data); 
	}

	function batalkan_pengajuan(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$param = array(
			'modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
			, 'modified_by' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
			, 'modified_date' => date('Y-m-d H:i:s')
			, 'status' => 4
		);
		$proses = $this->db->update('talent_bucket', $param, array('id_bucket' => $filter['id_bucket']));

		if($proses){
			$this->auditrail_model->add_log('Talent', 'Membatalkan Pengajuan. Id Bucket = '. $filter['id_bucket']);
			$data['message'] = $this->libs->generate_message('success','Pengajuan berhasil dibatalkan.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Pengajuan gagal dibatalkan.');
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusApprover();
		$data['result'] = $this->candidates(true);
		$this->load->view('talent/filter_candidates', $data);
	}

	function hapus_pengajuan(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		
		$proses = $this->db->delete('talent_bucket', array('id_bucket' => $filter['id_bucket']));

		if($proses){
			$this->auditrail_model->add_log('Talent', 'Hapus Bucket. Id Bucket = '. $filter['id_bucket']);
			$data['message'] = $this->libs->generate_message('success','Bucket berhasil dihapus.');
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Bucket gagal dihapus.');
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusApprover();
		$data['result'] = $this->candidates(true);
		$this->load->view('talent/filter_candidates', $data);
	}

	function kirim_candidates(){
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$arr_data['arr_cs'] = $this->input->get_post('cs');
		$arr_data['arr_text_cs'] = $this->input->get_post('text_cs');
		$posisi = '';
		$signers = array();
		$valid_cs = true;
		$desc_approver = array();
		foreach($arr_data['arr_cs'] as $idx=>$row) {
			if($posisi == '') {
				$posisi = $row;
			}

			if(isset($arr_data['arr_text_cs'][$idx])){
				
				$desc_approver[$idx] = str_replace('/','|',$arr_data['arr_text_cs'][$idx]);
				$signers[$idx] = $row;
			}
			else{
				$valid_cs = false;
				break;
			}
		}

		if($valid_cs){
			$param = array(
				'modifier' => $_SESSION[$this->config->item('session_prefix')]['pernr']
				, 'modified_by' => $_SESSION[$this->config->item('session_prefix')]['nama'] . '|' . $_SESSION[$this->config->item('session_prefix')]['stell_tx']
				, 'modified_date' => date('Y-m-d H:i:s')
				, 'approver' => implode('~', $signers)
				, 'desc_approver' => implode('~', $desc_approver)
				, 'posisi' => $posisi
				, 'status' => 1
				, 'status_approval' => null
				, 'tgl_proses' => null
				, 'catatan_approver' => null
			);

			$proses = $this->db->update('talent_bucket', $param, array('id_bucket' => $filter['id_bucket']));

			if($proses){
				$this->auditrail_model->add_log('Talent', 'Mengirim Pengajuan. Id Bucket = '. $filter['id_bucket']);
				$data['message'] = $this->libs->generate_message('success','Pengajuan berhasil dikirim.');
			}
			else{
				$data['message'] = $this->libs->generate_message('danger','Pengajuan gagal dikirim.');
			}
		}
		else{
			$data['message'] = $this->libs->generate_message('danger','Approver tidak ditemukan.');
		}

		$data['opt_status'] = array(''=>'- Semua status -') + $this->libs->arrStatusApprover();
		$data['result'] = $this->candidates(true);
		$this->load->view('talent/filter_candidates', $data);

	}

	public function filter_approval_candidates(){
		$data = array();
		$data['result'] = $this->approval_candidates(true);
		$this->load->view('talent/filter_approval_candidates', $data);
	}
	
	public function approval_candidates($string=false)
	{
		$filter['f_keyword'] = trim($this->input->post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(b.keyjobs_desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.organization_desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.organization_abr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.bucket_name',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}
		
		$param[] = $this->libs->arrWhere('AND','a.Posisi',$_SESSION[$this->config->item('session_prefix')]['pernr'],'1','=');
		$param[] = $this->libs->arrWhere('AND','a.Status',1,'1','=');

		/* Paginatian */
		$config['base_url'] = site_url('talent/candidates/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_candidates(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$data['candidates'] = $this->talent_model->get_candidates(false,$param,'a.modified_date desc',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('talent/approval_candidates',$data,true); 
		}else{
			$this->load->view('talent/approval_candidates',$data);
		}
	}

	function detail_approval_bucket(){
		$data = array();
		$filter['id_bucket'] = $this->input->get_post('id_bucket');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['organization'] = $this->input->get_post('organization');
		$data['filter'] = $filter;

		$data['talent_bucket'] = $this->db->get_where('talent_bucket', array('id_bucket' => $filter['id_bucket']))->row();
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		$this->db->order_by('urutan');
		$data['candidates'] = $this->db->get_where('talent_candidates_results', array('id_bucket' => $filter['id_bucket']))->result();
		$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
		$data['content'] = $this->load->view('talent/candidates_content',$data,true); 
		$this->load->view('talent/detail_approval_candidates',$data); 
	}

	public function approve_data(){
		$id_bucket = $this->db->escape_str($this->input->get_post('id_bucket'));
		$komentar = $this->db->escape_str($this->input->get_post('komentar'));
		$proses = $this->talent_model->approve_data($id_bucket, $komentar);
		if (!$proses['error']) {
			$this->auditrail_model->add_log("Pesertujuan Bucket", $_SESSION[$this->config->item('session_prefix')]['pernr']." menolak pengajuan bucket untuk id_bucket ". $id_bucket);
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		} else {
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}
		$data['notif'] = $this->access_menu_model->get_notif();
		$data['result'] = $this->approval_candidates(true);
		$this->load->view('talent/filter_approval_candidates', $data);
	}

	public function reject_data(){
		$id_bucket = $this->db->escape_str($this->input->get_post('id_bucket'));
		$komentar = $this->db->escape_str($this->input->get_post('komentar'));
		$proses = $this->talent_model->reject_data($id_bucket, $komentar);
		if (!$proses['error']) {
			$this->auditrail_model->add_log("Pesertujuan Bucket", $_SESSION[$this->config->item('session_prefix')]['pernr']." menolak pengajuan bucket untuk id_bucket ". $id_bucket);
			$data['message'] = $this->libs->generate_message('success',$proses['message']);
		} else {
			$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}
		$data['notif'] = $this->access_menu_model->get_notif();
		$data['result'] = $this->approval_candidates(true);
		$this->load->view('talent/filter_approval_candidates', $data);
	}

	public function create_pdf_candidates()
	{	
		$filter['id_bucket'] = $this->input->get_post('id_bucket_candidates');
		$filter['keyjobs'] = $this->input->get_post('keyjobs_candidates');
		$filter['organization'] = $this->input->get_post('organization_candidates');
		$data['filter'] = $filter;
		if($filter['id_bucket']!='')
		{
			$data = array();
			$data['talent_bucket'] = $this->db->get_where('talent_bucket', array('id_bucket' => $filter['id_bucket']))->row();
			$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
			$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
			$this->db->order_by('urutan');
			$data['candidates'] = $this->db->get_where('talent_candidates_results', array('id_bucket' => $filter['id_bucket']))->result();
			$data['arr_status'] = $this->libs->arrStatusApproverWithStyle();
			$file_name = $data['talent_bucket']->bucket_name;
			$data['content'] = $this->load->view('talent/detail_candidates_pdf',$data,true); 
		}
		else
			{
			$file_name = 'invalid';
			$data['content'] = 'Data tidak valid';
			}

		$html = $this->load->view('theme/pdf_template',$data,true);			
		$this->libs->wkhtmltopdf($html,$file_name,'A4','Landscape');
	}

	public function bucket_successor_detail(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['bucket'] = $this->input->get_post('bucket');
		$filter['f_pekerja'] = $this->input->get_post('f_pekerja');

		$param_sort['sort'] = $this->input->get_post('sort');
		$param_sort['sort_column'] = $this->input->get_post('sort_column');
		$param_sort['direction'] = $this->input->get_post('direction');

		if($param_sort['sort'] == '' && $param_sort['sort_column'] == ''){
			$param_sort['sort_column'] = 'overall_compability';
			$param_sort['sort'] = 'desc';
			$param_sort['direction'] = 'up';
		}

		$s_sort = 'asc';
		if($param_sort['sort'] == 'asc')
			$s_sort = 'desc';


		$sort_by = ($param_sort['sort_column'] . ' ' . $param_sort['sort'] .', tanggallahir ' . $s_sort);
		
		$this->load->library(array('pagination'));
		$param = array();
		
		$param[] = $this->libs->arrWhere('AND','id_bucket',$filter['bucket'],1,'=');
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		if($filter['f_pekerja'] != '')
			$param[] = $this->libs->arrWhere('AND','pernr',$filter['f_pekerja'],1,'=');
		
		/* Paginatian */
		$config['base_url'] = site_url('talent/bucket_successor_detail/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->talent_model->get_bucket_successors(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];
		$data['filter'] = $filter;
		$data['param_sort'] = $param_sort;
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();
		$data['successors'] = $this->talent_model->get_bucket_successors(false,$param,$sort_by,$rowpos,$limits);
		
		$this->load->view('talent/successor_bucket_detail',$data);
	}

	function checked_bucket_talent(){
		$data_upd = array('is_checked' => $this->input->get_post('checked'));
		$dcondition = array('keyjobs' => $this->input->get_post('keyjobs'), 'pernr' => $this->input->get_post('pernr'), 'id_bucket' => $this->input->get_post('bucket'));
		if($this->db->update('talent_candidates_results', $data_upd, $dcondition))
			echo 'ok';
		else
			echo 'failed';
	}

	public function successor_auto_view(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['status'] = $this->input->get_post('status');
		//$pernr_drop = $this->input->get_post('pernr_drop');
		
		$this->load->library(array('pagination'));
		$param = array();

		/*if(!empty($pernr_drop)){
			$proses = $this->talent_model->drop_candidates_view($filter['keyjobs'], $pernr_drop);
			if($proses['status'])
				$data['message'] = $this->libs->generate_message('success',$proses['message']);
			else
				$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}*/
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();

		$filter['corp_title'] = $this->input->get_post('corp_title');
		
		$data['filter'] = $filter;
		if($filter['corp_title'] == 'Executive Vice President'){
			$get_wakil = $this->talent_model->get_wakil_keyjobs($filter['keyjobs'], $filter['organization']);
			$data['wakil'] = $get_wakil;
			$count_wakil = count($get_wakil);
		}
		else{
			$data['wakil'] = array();
			$count_wakil = 0;
		}
		$data['new_candidates'] = $this->talent_model->get_new_candidates_keyjobs($filter['keyjobs'], $filter['organization']);
		if($filter['status'] == 1){
			$data['successors_1'] = $this->talent_model->get_successors_rotasi($filter, 3);
			$data['successors_2'] = $this->talent_model->get_successors_case_promosi($filter, 2);
		}
		elseif($filter['status'] == 2){
			$data['successors_1'] = $this->talent_model->get_successors_rotasi($filter, 3);
			$limit = 2;
			$limit = $limit-$count_wakil;
			if($limit<0)
				$limit = 0;
			$data['successors_2'] = $this->talent_model->get_successors_case_promosi($filter, $limit);
		}
		elseif($filter['status'] == 3){
			$data['successors_1'] = $this->talent_model->get_successors_rotasi($filter, 2);
			$limit = 3;
			$limit = $limit-$count_wakil;
			if($limit<0)
				$limit = 0;
			$data['successors_2'] = $this->talent_model->get_successors_case_promosi($filter, $limit);
		}

		$this->load->view('talent/successor_auto_view',$data);
	}

	public function successors_compare_auto_view(){
		$filter['organization'] = $this->input->get_post('organization');
		$filter['keyjobs'] = $this->input->get_post('keyjobs');
		$filter['status'] = $this->input->get_post('status');
		$filter['source'] = $this->input->get_post('source');
		$pernr_drop = $this->input->get_post('pernr_drop');
		$pekerja = $this->input->get_post('f_pekerja');
		
		$this->load->library(array('pagination'));
		$param = array();

		if(!empty($pernr_drop)){
			$proses = $this->talent_model->drop_candidates_view($filter['keyjobs'], $pernr_drop);
			if($proses['status'])
				$data['message'] = $this->libs->generate_message('success',$proses['message']);
			else
				$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}

		if(!empty($pekerja)){
			$proses = $this->talent_model->add_candidates_view($filter['keyjobs'], $pekerja);
			if($proses['status'])
				$data['message'] = $this->libs->generate_message('success',$proses['message']);
			else
				$data['message'] = $this->libs->generate_message('danger',$proses['message']);
		}
		
		$param[] = $this->libs->arrWhere('AND','keyjobs',$filter['keyjobs'],1,'=');
		
		$data['keyjobs'] = $this->db->get_where('mst_keyjobs', array('keyjobs' => $filter['keyjobs']))->row();
		$data['organization'] = $this->db->get_where('mst_organization', array('organization' => $filter['organization']))->row();

		$filter['corp_title'] = $this->input->get_post('corp_title');
		
		$data['filter'] = $filter;

		if($filter['corp_title'] == 'Executive Vice President'){
			$get_wakil = $this->talent_model->get_wakil_keyjobs($filter['keyjobs'], $filter['organization']);
			$data['wakil'] = $get_wakil;
			$count_wakil = count($get_wakil);
		}
		else{
			$data['wakil'] = array();
			$count_wakil = 0;
		}
		$data['new_candidates'] = $this->talent_model->get_new_candidates_keyjobs($filter['keyjobs'], $filter['organization']);

		if($filter['status'] == 1){
			$data['successors_1'] = $this->talent_model->get_successors_rotasi($filter, 3);
			$data['successors_2'] = $this->talent_model->get_successors_case_promosi($filter, 2);
		}
		elseif($filter['status'] == 2){
			$data['successors_1'] = $this->talent_model->get_successors_rotasi($filter, 3);
			$limit = 2;
			$limit = $limit-$count_wakil;
			if($limit<0)
				$limit = 0;
			$data['successors_2'] = $this->talent_model->get_successors_case_promosi($filter, $limit);
		}
		elseif($filter['status'] == 3){
			$data['successors_1'] = $this->talent_model->get_successors_rotasi($filter, 2);
			$limit = 3;
			$limit = $limit-$count_wakil;
			if($limit<0)
				$limit = 0;
			$data['successors_2'] = $this->talent_model->get_successors_case_promosi($filter, $limit);
		}

		$this->load->view('talent/successors_compare_auto_view',$data);
	}
	
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */