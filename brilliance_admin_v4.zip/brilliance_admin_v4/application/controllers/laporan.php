<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {
	public function __construct()
   	{
		parent::__construct();
		// Your own constructor code
		
		$this->mysession->check_no_session();
		$this->mysession->check_session_expired();
		$this->load->model(array('user_model', 'laporan_model'));
   	}
	
	public function filter_aspirasi_karir(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		if($tipe_uker == 'KP'){
			$data = array();
			$data['arrPiluker'] = $this->laporan_model->arrPiluker();
			$data['result'] = $this->aspirasi_karir(true);
			$this->load->view('laporan/filter_aspirasi_karir', $data);
		}
		else{
			$data = array();
			$data['result'] = $this->aspirasi_karir(true);
			$this->load->view('laporan/filter_aspirasi_karir_nonkp', $data);
		}
	}
	
	public function aspirasi_karir($string=false)
	{
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		$filter['f_jenis_uker'] = trim($this->input->get_post('f_jenis_uker'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CorporateTitleDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Htext',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JobGrade',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($filter['f_jenis_uker']!=''){
			$param[] = $this->libs->arrWhere('AND','a.JenisUker',$filter['f_jenis_uker'],'1','=');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalArea',$pa,'1','=');
		}

		$param[] = $this->libs->arrWhere('AND','a.StatusData',1,'1','=');
		
		/* Paginatian */ 
		$config['base_url'] = site_url('laporan/aspirasi_karir/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_aspirasi_karir(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['aspirasi_karir'] = $this->laporan_model->get_aspirasi_karir(false,$param,'a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/aspirasi_karir',$data,true); 
		}else{
			$this->load->view('laporan/aspirasi_karir',$data);
		}
	}

	function aspirasi_karir_pdf(){
		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		$filter['f_jenis_uker'] = trim($this->input->get_post('f_jenis_uker'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CorporateTitleDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Htext',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JobGrade',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($filter['f_jenis_uker']!=''){
			$param[] = $this->libs->arrWhere('AND','a.JenisUker',$filter['f_jenis_uker'],'1','=');
		}

		$param[] = $this->libs->arrWhere('AND','a.StatusData',1,'1','=');
		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['aspirasi_karir'] = $this->laporan_model->get_aspirasi_karir(false,$param,'a.Pernr');
		$data['no'] = 1;
		$data['content'] = $this->load->view('laporan/aspirasi_karir_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Aspirasi_Karir', 'A4', 'Landscape');
	}

	function aspirasi_karir_excel(){
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		$filter['f_jenis_uker'] = trim($this->input->get_post('f_jenis_uker'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CorporateTitleDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Htext',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JobGrade',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($filter['f_jenis_uker']!=''){
			$param[] = $this->libs->arrWhere('AND','a.JenisUker',$filter['f_jenis_uker'],'1','=');
		}

		$param[] = $this->libs->arrWhere('AND','a.StatusData',1,'1','=');

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalArea',$pa,'1','=');
		}

		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['aspirasi_karir'] = $this->laporan_model->get_aspirasi_karir_csv(false,$param,'a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_ASPIRASI_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['aspirasi_karir'], TRUE, $filename);
		//$data['no'] = 1;
		//$data['content'] = $this->load->view('laporan/aspirasi_karir_pdf', $data, true);
        //$data['file_name'] = 'Aspirasi_Karir';
        //$this->load->view('theme/excel_template', $data);
	}

	public function filter_suksesor_saya(){
		$data = array();
		$data['result'] = $this->suksesor_saya(true);
		$this->load->view('laporan/filter_suksesor_saya', $data);
	}
	
	public function suksesor_saya($string=false)
	{
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PernrAction',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.NamaAction',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalAreaAction',$pa,'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('laporan/suksesor_saya/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_suksesor_saya(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['suksesor_saya'] = $this->laporan_model->get_suksesor_saya(false,$param,'a.PernrAction, a.Urutan',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/suksesor_saya',$data,true); 
		}else{
			$this->load->view('laporan/suksesor_saya',$data);
		}
	}

	function suksesor_saya_pdf(){
		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
	
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PernrAction',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.NamaAction',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$data['suksesor_saya'] = $this->laporan_model->get_suksesor_saya(false,$param,'a.PernrAction, a.Urutan');
		$data['no'] = 1;
		$data['content'] = $this->load->view('laporan/suksesor_saya_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Endorsement_Successor', 'A4', 'Landscape');
	}

	function suksesor_saya_excel(){
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PernrAction',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.NamaAction',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalAreaAction',$pa,'1','=');
		}

		$data['suksesor_saya'] = $this->laporan_model->get_suksesor_saya_csv(false,$param,'a.PernrAction, a.Urutan');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_SUKSESOR_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['suksesor_saya'], TRUE, $filename);
		//$data['no'] = 1;
		//$data['content'] = $this->load->view('laporan/suksesor_saya_pdf', $data, true);
        //$data['file_name'] = 'Endorsement_Successor';
        //$this->load->view('theme/excel_template', $data);
	}

	public function filter_endorse_subordinate(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		if($tipe_uker == 'KP'){
			$data = array();
			$data['result'] = $this->endorse_subordinate(true);
			$this->load->view('laporan/filter_endorse_subordinate', $data);
		}
		else{
			$data = array();
			$data['result'] = $this->endorse_subordinate(true);
			$this->load->view('laporan/filter_endorse_subordinate_nonkp', $data);
		}	
	}
	
	public function endorse_subordinate($string=false)
	{
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		$filter['f_jenis_uker'] = trim($this->input->get_post('f_jenis_uker'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PernrEndorse',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.NamaEndorse',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($filter['f_jenis_uker']!=''){
			$param[] = $this->libs->arrWhere('AND','a.JenisUker',$filter['f_jenis_uker'],'1','=');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalArea',$pa,'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('laporan/endorse_subordinate/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_endorse_subordinate(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['endorse_subordinate'] = $this->laporan_model->get_endorse_subordinate(false,$param,'a.PernrEndorse, a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/endorse_subordinate',$data,true); 
		}else{
			$this->load->view('laporan/endorse_subordinate',$data);
		}
	}

	function endorse_subordinate_pdf(){
		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		$filter['f_jenis_uker'] = trim($this->input->get_post('f_jenis_uker'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PernrEndorse',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.NamaEndorse',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($filter['f_jenis_uker']!=''){
			$param[] = $this->libs->arrWhere('AND','a.JenisUker',$filter['f_jenis_uker'],'1','=');
		}

		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['endorse_subordinate'] = $this->laporan_model->get_endorse_subordinate(false,$param,'a.PernrEndorse, a.Pernr');
		$data['no'] = 1;
		$data['content'] = $this->load->view('laporan/endorse_subordinate_pdf', $data, true);
		$html = $this->load->view('theme/pdf_template', $data, true);
		$this->libs->wkhtmltopdf($html,'Endorse_Subordinate', 'A4', 'Landscape');
	}

	function endorse_subordinate_excel(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		$filter['f_jenis_uker'] = trim($this->input->get_post('f_jenis_uker'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PernrEndorse',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.NamaEndorse',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($filter['f_jenis_uker']!=''){
			$param[] = $this->libs->arrWhere('AND','a.JenisUker',$filter['f_jenis_uker'],'1','=');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalArea',$pa,'1','=');
		}

		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['endorse_subordinate'] = $this->laporan_model->get_endorse_subordinate_csv(false,$param,'a.PernrEndorse, a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_ENDORSEMENT_ME1_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['endorse_subordinate'], TRUE, $filename);
		//$data['no'] = 1;
		//$data['content'] = $this->load->view('laporan/endorse_subordinate_pdf', $data, true);
        //$data['file_name'] = 'Endorse_Subordinate';
        //$this->load->view('theme/excel_template', $data);
	}

	function get_children(){
		$data = array(
			'children' => array(
				array(
					'id'=> 'n4', 
					'name'=> 'Pang Pang',
					'title'=> 'Pang Pang',
					'content' => 'Pang Pang Pang Pang',
					'relationship'=> '111'
				), 
				array(
					'id'=> 'n5', 
					'name'=> 'Pang Pang Send',
					'title'=> 'Pang Pang Send',
					'content' => 'Pang Pang Send Pang Pang Send',
					'relationship'=> '111'
				)
			)
		);
		echo json_encode($data);
	}

	public function filter_aspirasi_kompetensi(){
		$data = array();
		$data['result'] = $this->aspirasi_kompetensi(true);
		$this->load->view('laporan/filter_aspirasi_kompetensi', $data);
	}
	
	public function aspirasi_kompetensi($string=false)
	{
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
	
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JF1',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JF1Desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SJF1',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SJF1Desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JF2',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JF2Desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SJF2',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SJF2Desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.SNAME',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.KOSTL_TX',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.WERKS_TX',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.ORGEH_TX',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.BTRTL_TX',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','b.WERKS',$pa,'1','=');
		}

		
		/* Paginatian */ 
		$config['base_url'] = site_url('laporan/aspirasi_kompetensi/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_aspirasi_kompetensi(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['aspirasi_kompetensi'] = $this->laporan_model->get_aspirasi_kompetensi(false,$param,'a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/aspirasi_kompetensi',$data,true); 
		}else{
			$this->load->view('laporan/aspirasi_kompetensi',$data);
		}
	}

	function aspirasi_kompetensi_excel(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		   
		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JF1',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JF1Desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SJF1',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SJF1Desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JF2',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.JF2Desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SJF2',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SJF2Desc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.SNAME',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.KOSTL_TX',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.WERKS_TX',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.ORGEH_TX',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','b.BTRTL_TX',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','b.WERKS',$pa,'1','=');
		}

		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['aspirasi_kompetensi'] = $this->laporan_model->get_aspirasi_kompetensi_csv(false,$param,'a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_ASPIRASI_KOMPETENSI_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['aspirasi_kompetensi'], TRUE, $filename);
		//$data['no'] = 1;
		//$data['content'] = $this->load->view('laporan/aspirasi_kompetensi_pdf', $data, true);
        //$data['file_name'] = 'Aspirasi_Kompetensi';
        //$this->load->view('theme/excel_template', $data);
	}

	public function filter_endorse_me2(){
		$data = array();
		$data['result'] = $this->endorse_me2(true);
		$this->load->view('laporan/filter_endorse_me2', $data);
	}
	
	public function endorse_me2($string=false)
	{
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PernrEndorse',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.NamaEndorse',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalArea',$pa,'1','=');
		}

		/* Paginatian */
		$config['base_url'] = site_url('laporan/endorse_me2/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_endorse_me2(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['endorse_subordinate'] = $this->laporan_model->get_endorse_me2(false,$param,'a.PernrEndorse, a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/endorse_me2',$data,true); 
		}else{
			$this->load->view('laporan/endorse_me2',$data);
		}
	}

	function endorse_me2_excel(){
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PernrEndorse',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.NamaEndorse',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalArea',$pa,'1','=');
		}

		$data['endorse_subordinate'] = $this->laporan_model->get_endorse_me2_csv(false,$param,'a.PernrEndorse, a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_ENDORSEMENT_ME2_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['endorse_subordinate'], TRUE, $filename);
	}

	public function filter_bdp(){
		$data = array();
		$data['result'] = $this->bdp(true);
		$this->load->view('laporan/filter_bdp', $data);
	}
	
	public function bdp($string=false)
	{
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
	
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Coach',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CoachDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Mentor',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.MentorDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SDPDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.HDPDEsc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CostCenterDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PersonnalAreaDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PersonnalSubAreaDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrgUnitDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CorporateTitleDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Htext',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','a.StatusData',1,'1','=');

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalArea',$pa,'1','=');
		}
		
		/* Paginatian */ 
		$config['base_url'] = site_url('laporan/bdp/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_bdp(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['arrPiluker'] = $this->laporan_model->arrPiluker();
		$data['bdp'] = $this->laporan_model->get_bdp(false,$param,'a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/bdp',$data,true); 
		}else{
			$this->load->view('laporan/bdp',$data);
		}
	}

	function bdp_excel(){
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Nama',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Coach',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CoachDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Mentor',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.MentorDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.SDPDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.HDPDEsc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CostCenterDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PersonnalAreaDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.PersonnalSubAreaDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.OrgUnitDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.CorporateTitleDesc',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','a.Htext',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		$param[] = $this->libs->arrWhere('AND','a.StatusData',1,'1','=');

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','a.PersonnalArea',$pa,'1','=');
		}

		$data['bdp'] = $this->laporan_model->get_bdp_csv(false,$param,'a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_BDP_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['bdp'], TRUE, $filename);
	}

	public function filter_awards(){
		$data = array();
		$data['result'] = $this->narasumber(true);
		$data['result1'] = $this->achievement(true);
		$data['result2'] = $this->karya_tulis(true);
		$data['result3'] = $this->organisasi(true);
		$data['arrPilAwards'] = array('' => '- Pilih Jenis Awards -')+$this->laporan_model->arrPilAwards();
		//$data['arrPilAwards'] = $this->laporan_model->arrPilAwards();
		$this->load->view('laporan/filter_awards', $data);
	}

	public function filter_awards_new(){
		$data = array();
		$data['arrPilAwards'] = array('' => '- Pilih Jenis Awards -')+$this->laporan_model->arrPilAwards();
		$this->load->view('laporan/filter_awards_new', $data);
	}
	
	public function narasumber($string=false)
	{
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.SName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','c.WERKS',$pa,'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('laporan/narasumber/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_narasumber(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['narasumber'] = $this->laporan_model->get_narasumber(false,$param,'a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/narasumber',$data,true); 
		}else{
			$this->load->view('laporan/narasumber',$data);
		}
	}

	function narasumber_excel(){
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.SName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','c.WERKS',$pa,'1','=');
		}

		$data['narasumber'] = $this->laporan_model->get_narasumber_csv(false,$param,'a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_NARASUMBER_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['narasumber'], TRUE, $filename);
		//$data['no'] = 1;
		//$data['content'] = $this->load->view('laporan/suksesor_saya_pdf', $data, true);
        //$data['file_name'] = 'Endorsement_Successor';
        //$this->load->view('theme/excel_template', $data);
	}

	public function achievement($string=false)
	{
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		$filter['f_jenis_awards'] = trim($this->input->get_post('f_jenis_awards'));
		
		$this->load->library(array('pagination'));
		$param = array();

		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.SName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','c.WERKS',$pa,'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('laporan/achievement/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_achievement(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['achievement'] = $this->laporan_model->get_achievement(false,$param,'a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/achievement',$data,true); 
		}else{
			$this->load->view('laporan/achievement',$data);
		}
	}

	function achievement_excel(){
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.SName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','c.WERKS',$pa,'1','=');
		}

		$data['achievement'] = $this->laporan_model->get_achievement_csv(false,$param,'a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_ACHIEVEMENT_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['achievement'], TRUE, $filename);
		//$data['no'] = 1;
		//$data['content'] = $this->load->view('laporan/suksesor_saya_pdf', $data, true);
        //$data['file_name'] = 'Endorsement_Successor';
        //$this->load->view('theme/excel_template', $data);
	}

	public function karya_tulis($string=false)
	{
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.SName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','c.WERKS',$pa,'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('laporan/karya_tulis/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_karya_tulis(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['karya_tulis'] = $this->laporan_model->get_karya_tulis(false,$param,'a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/karya_tulis',$data,true); 
		}else{
			$this->load->view('laporan/karya_tulis',$data);
		}
	}

	function karya_tulis_excel(){
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.SName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','c.WERKS',$pa,'1','=');
		}

		$data['karya_tulis'] = $this->laporan_model->get_karya_tulis_csv(false,$param,'a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_KARYA_TULIS_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['karya_tulis'], TRUE, $filename);
		//$data['no'] = 1;
		//$data['content'] = $this->load->view('laporan/suksesor_saya_pdf', $data, true);
        //$data['file_name'] = 'Endorsement_Successor';
        //$this->load->view('theme/excel_template', $data);
	}

	public function organisasi($string=false)
	{
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$this->load->library(array('pagination'));
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.SName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','c.WERKS',$pa,'1','=');
		}
		
		/* Paginatian */
		$config['base_url'] = site_url('laporan/organisasi/false');
		$config['uri_segment'] = 4;
		$config['total_rows'] = $this->laporan_model->get_organisasi(true,$param);
		$config['per_page'] = 10;
		$config['num_links'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a class="active" href="#">';
		$config['cur_tag_close'] = ' <span class="sr-only">(current)</span></a></li>';
		$config['prev_link'] = '&laquo;';
		$config['next_link'] = '&raquo;';
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['attributes'] = array('class' => 'box-paging');
		
		$data['jml_hal'] = ceil($config['total_rows']/$config['per_page']);
		if ($this->uri->segment($config['uri_segment'])=='' || $this->uri->segment($config['uri_segment'])<=0) {
			$rowpos = 0;
		} else {
			$rowpos = ($this->uri->segment($config['uri_segment']) > $data['jml_hal'])?$data['jml_hal']:$this->uri->segment($config['uri_segment']);
			$rowpos = (($rowpos-1) * $config['per_page']);
		}
		$rowpos = $rowpos<0?0:$rowpos;
		$limits = $config['per_page'];

		$this->pagination->initialize($config); 
		$data['paging'] = $this->pagination->create_links();
		/* End Pagination */
		$data['no'] = $rowpos+1;
		$data['jml_data'] = $config['total_rows'];	
		$data['filter'] = $filter;
		$data['organisasi'] = $this->laporan_model->get_organisasi(false,$param,'a.Pernr',$rowpos,$limits);
		if($string===TRUE){
			return $this->load->view('laporan/organisasi',$data,true); 
		}else{
			$this->load->view('laporan/organisasi',$data);
		}
	}

	function organisasi_excel(){
		$tipe_uker = $_SESSION[$this->config->item('session_prefix')]['tipe_uker'];
		$pa = $_SESSION[$this->config->item('session_prefix')]['pa'];
		$psa = $_SESSION[$this->config->item('session_prefix')]['psa'];

		$filter['f_keyword'] = trim($this->input->get_post('f_keyword'));
		
		$param = array();
		
		if($filter['f_keyword']!=''){
			$param[] = $this->libs->arrWhere('AND','(a.Pernr',"%{$filter['f_keyword']}%",'1','LIKE');
			$param[] = $this->libs->arrWhere('OR','c.SName',"%{$filter['f_keyword']}%",'1','LIKE','',')');
		}

		if($tipe_uker != 'KP'){
			$param[] = $this->libs->arrWhere('AND','c.WERKS',$pa,'1','=');
		}

		$data['organisasi'] = $this->laporan_model->get_organisasi_csv(false,$param,'a.Pernr');
		$this->load->helper('csv');
		ini_set('memory_limit', '-1');
		$filename = "REKAP_RIWAYAT_ORGANISASI_" . date('Y') . '_' . date('m') . '_' . date('d') . '_' . date('His') .'.csv';
		echo query_to_csv($data['organisasi'], TRUE, $filename);
		//$data['no'] = 1;
		//$data['content'] = $this->load->view('laporan/suksesor_saya_pdf', $data, true);
        //$data['file_name'] = 'Endorsement_Successor';
        //$this->load->view('theme/excel_template', $data);
	}

}

/* End of file home.php */
/* Location: ./application/controllers/home.php */