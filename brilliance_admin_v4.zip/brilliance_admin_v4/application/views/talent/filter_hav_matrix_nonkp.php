<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<h3 class="maintitle"><i class="fa fa-line-chart"></i> <span> Talent Cluster</span></h3>
<?=isset($breadcrum)?$breadcrum:'';?>
<div class="row">
	<div class="col-sm-3">
		<div class="panel panel-primary" style="margin-bottom:10px;">
		  <div class="panel-heading"><h3 class="panel-title">Filter</h3></div>
		  <div class="panel-body" style="padding:15px;height:475px;">
				<?=form_open('talent/hav_matrix/','id="form_filter"')?>
					<div class="row">
						<div class="col-md-12">Corporate Title : <?='';//form_dropdown('f_corp_title',(isset($opt_corp_title)?$opt_corp_title:array(''=>'- Choose Corporate Title -')),$this->input->post('f_corp_title'),'class="form-control filter input-sm" id="f_corp_title" title="Choose Corporate here."');?><?=form_dropdown('f_corp_title[]',isset($opt_corp_title)?$opt_corp_title:array(),($this->input->post('f_corp_title')?$this->input->post('f_corp_title'):(isset($selected_corp_title)?$selected_corp_title:array())),' id="f_corp_title" class="multiselect" multiple="multiple" title="Choose Corporate Title here."')?>
						</div>
					</div>
					<!-- <div class="row">
						<div class="col-md-12" style="margin-top:5px;">Jobs : <?='';//form_dropdown('f_job',(isset($opt_hilfm)?$opt_hilfm:array(''=>'- Choose Jobs -')),$this->input->post('f_job'),'class="form-control filter input-sm" id="f_job" title="Choose Jobs here."');?><?=form_dropdown('f_job[]',isset($opt_hilfm)?$opt_hilfm:array(),($this->input->post('f_job')?$this->input->post('f_job'):(isset($selected_hilfm)?$selected_hilfm:array())),' id="f_job" class="multiselect" multiple="multiple" title="Choose Jobs here."')?>
						</div>
					</div> -->
					<div class="row">
						<div class="col-md-12" style="margin-top:5px;">Category : <?='';//form_dropdown('f_category',(isset($opt_category)?$opt_category:array(''=>'- Choose Jobs -')),$this->input->post('f_category'),'class="form-control filter input-sm" id="f_category" title="Choose Category here."');?><?=form_dropdown('f_category[]',isset($opt_category)?$opt_category:array(),($this->input->post('f_category')?$this->input->post('f_category'):(isset($selected_category)?$selected_category:array())),' id="f_category" class="multiselect" multiple="multiple" title="Choose Category here."')?>
						</div>
					</div>
					<!--<div class="row">
						<div class="col-md-12" style="margin-top:5px;">Bisnis / Non Bisnis : <?=form_dropdown('f_type[]',isset($opt_type)?$opt_type:array(),($this->input->post('f_type')?$this->input->post('f_type'):(isset($selected_type)?$selected_type:array())),' id="f_type" class="multiselect" multiple="multiple" title="Choose here."')?>
						</div>
					</div>-->
					<div class="row">
						<div class="col-md-12" style="margin-top:5px;">Jenis Assessment : <?=form_dropdown('f_jenis_asesmen',(isset($opt_jenis_asesmen)?$opt_jenis_asesmen:array(''=>'- Choose Assessment -')),1,'class="form-control filter input-sm" id="f_jenis_asesmen" title="Choose Assessment here."');?>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12" style="margin-top:5px;">Talent Class : <?=form_dropdown('f_talent_class',(isset($opt_talent_class)?$opt_talent_class:array(''=>'- Choose Talent Class -')),2,'class="form-control filter input-sm" id="f_talent_class" title="Choose Talent Class here."');?><?='';//form_dropdown('f_talent_class[]',isset($opt_talent_class)?$opt_talent_class:array(),($this->input->post('f_talent_class')?$this->input->post('f_talent_class'):(isset($selected_talent_class)?$selected_talent_class:array())),' id="f_talent_class" class="multiselect" multiple="multiple" title="Choose Talent Class here."')?>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12" align="center">
							&nbsp;
						</div>
					</div>
					<div class="row">
						<div class="col-md-12" align="center">
							<button class="btn btn-success" name="show" id="show" value="Analyze" type="submit" title="Klik di sini untuk analisa data.">Analyze</button>
						</div>
					</div>
				</form>
		  </div>
		</div>
	</div>
	<div class="col-sm-9">
		<div class="panel panel-yellow ">
			<div class="panel-heading"><h3 class="panel-title">Result</h3></div>
			<div class="panel-body" style="padding:3px;height:475px;">
				<div id="result" style="margin-top:3px;">
					<?=isset($result)?$result:'';?>
				</div>
			</div>
		</div>
	</div>
</div>
<link rel="stylesheet" type="text/css" href="<?=base_url()?>sources/plugins/multiselect/bootstrap/bootstrap-multiselect.css" />
<script type="text/javascript" src="<?=base_url()?>sources/plugins/multiselect/bootstrap/bootstrap-multiselect.js"></script>
<script>
$(document).ready(function(){
	
	if(Array.prototype.equals)
    console.warn("Overriding existing Array.prototype.equals. Possible causes: New API defines the method, there's a framework conflict or you've got double inclusions in your code.");
	// attach the .equals method to Array's prototype to call it on any array
	Array.prototype.equals = function (array) {
		// if the other array is a falsy value, return
		if (!array)
			return false;

		// compare lengths - can save a lot of time 
		if (this.length != array.length)
			return false;

		for (var i = 0, l=this.length; i < l; i++) {
			// Check if we have nested arrays
			if (this[i] instanceof Array && array[i] instanceof Array) {
				// recurse into the nested arrays
				if (!this[i].equals(array[i]))
					return false;       
			}           
			else if (this[i] != array[i]) { 
				// Warning - two different object instances will never be equal: {x:20} != {x:20}
				return false;   
			}           
		}       
		return true;
	}
	// Hide method from for-in loops
	Object.defineProperty(Array.prototype, "equals", {enumerable: false});
	
	$('.multiselect').multiselect({
		  buttonWidth: '100%',
		  maxHeight: 300,
		  includeSelectAllOption: true,
		  enableFiltering: true,
		  enableCaseInsensitiveFiltering:true
	}).multiselect('selectAll', false)
	.multiselect('updateButtonText');
	
	$('#f_corp_title').on('change', function(){
		if($(this).val().equals (["4", "5"]) || $(this).val().equals (["4"]) || $(this).val().equals (["5"])){
			console.log('hai');
		}
    });
	
	$('#form_filter').off().submit(function(e){
		$(this).myAjax({
			url : $(this).attr('action'),
			data: 'mt=1&'+$(this).serialize(),
			success: function(data){
				$('#result').html(data);
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});
	
});
</script>