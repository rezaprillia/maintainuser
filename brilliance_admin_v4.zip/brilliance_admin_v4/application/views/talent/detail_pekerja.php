<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<div class="modal-header">
	<!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
	<h4 class="modal-title" id="modal-message">Employee CV</h4>
</div>
<div class="modal-body">
	<div class="row" style="margin-bottom:10px;">
		<div class="col-md-6">
			<?php
			if(in_array($filter['source'], array('candidates_bucket','candidates','monitoring'))){
			?>
				<button class="btn btn-warning btn-sm close_btn" id="close_btn" value="Back" type="button" title="Click here to back."><i class="fa fa-arrow-left"></i> Back</button>
			<?php
			}
			else{
			?>
				<button class="btn btn-warning btn-sm back_btn" id="back_btn" value="Back" type="button" title="Click here to back."><i class="fa fa-arrow-left"></i> Back</button>
			<?php
			}
			?>
		</div>
		<div class="col-md-6 text-right">
			<button class="btn btn-sm btn-success download_excel" value="Download Excel" type="button" title=""><i class="fa fa-file-excel-o"></i> Download Excel</button>&nbsp; 
			<button class="btn btn-sm btn-theme download_pdf" value="Download Pdf" type="button" title=""><i class="fa fa-file-pdf-o"></i> Download Pdf</button>
		</div>
	</div>

	<?=form_open('','id="from_detail_pekerja"')?>
		<?=isset($filter)?form_hidden($filter):''?>
	</form>
	
	<?=form_open('hasil/create_pdf_detail_pekerja','target="_blank" id="profile"')?>
		<div id="detail_profile"><?=isset($detail_profile) ? $detail_profile : '';?></div>
	<?=form_close();?>
	<div class="row" style="margin-bottom:10px;display:none;">
		<div class="col-md-6">
			<?php
			if(in_array($filter['source'], array('candidates_bucket','candidates','monitoring'))){
			?>
				<button class="btn btn-warning btn-sm close_btn" id="close_btn" value="Back" type="button" title="Click here to back."><i class="fa fa-arrow-left"></i> Back</button>
			<?php
			}
			else{
			?>
				<button class="btn btn-warning btn-sm back_btn" id="back_btn" value="Back" type="button" title="Click here to back."><i class="fa fa-arrow-left"></i> Back</button>
			<?php
			}
			?>
		</div>
		<div class="col-md-6 text-right">
			<button class="btn btn-sm btn-success download_excel" value="Download Excel" type="button" title=""><i class="fa fa-file-excel-o"></i> Download Excel</button>&nbsp; 
			<button class="btn btn-sm btn-theme download_pdf" value="Download Pdf" type="button" title=""><i class="fa fa-file-pdf-o"></i> Download Pdf</button>
		</div>
	</div>
</div>

<script>
$(document).ready(function(){
	// $('.back_btn').off().click(function(e){
	// 	$(this).myAjax({
	// 		url : '<?=site_url($filter['ctrl']).'/'.$filter['source']?>',
	// 		data: 'mt=1&'+$('#from_detail_pekerja').serialize(),
	// 		success: function(data){
	// 			$('#general_popup .modal-dialog .modal-content').empty();
	// 			$('#general_popup .modal-dialog').removeClass('modal-lg modal-md modal-sm modal-hav modal-successor modal-compare modal-cv').addClass('modal-compare');
	// 			$('#general_popup .modal-dialog .modal-content').html(data);
	// 			$('#ajax-loader').hide();
	// 		}
	// 	});
	// 	e.preventDefault();
	// });

	$('.back_btn').off().click(function(e){
		$('#general_popup').modal('hide');
		e.preventDefault();
	});

	$('.close_btn').off().click(function(e){
		$('#general_popup').modal('hide');
		e.preventDefault();
	});
	
	$('.download_pdf').off().click(function(){
		$('#profile').attr('action',"<?=site_url('talent/create_pdf_detail_pekerja');?>");
		$('#profile').submit();
	});

	$('.download_excel').off().click(function(){
		$('#profile').attr('action',"<?=site_url('talent/create_excel_detail_pekerja');?>");
		$('#profile').submit();
	});
});
</script>