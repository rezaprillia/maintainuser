<style>
.exp{
	max-width:80px !important;
    word-wrap:break-word !important;
}
</style>
<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <h4 class="modal-title"><?=isset($filter['legend'])?$filter['legend']:'-'?></h4>
 </div>
 
 <div class="modal-body">
	<div id="modal_body">
		<div align="left" style="float:left"><button class="btn btn-warning btn-sm" id="back_btn" value="Back" type="button" title="Click here to back."><i class="fa fa-arrow-left"></i> Back</button> <button class="btn btn-danger btn-sm" id="filter_show" value="Show Filter" type="button" title="Click here to show filter."><i class="fa fa-filter"></i> Show Filter</button><button class="btn btn-danger btn-sm" id="filter_hide" value="Hide Filter" type="button" title="Click here to hide filter." style="display:none;"><i class="fa fa-filter"></i> Hide Filter</button></div>
		<div align="right" style=""><button class="btn btn-success btn-sm" id="download_detail_excel" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>&nbsp;&nbsp;<!--<button class="btn btn-theme btn-sm" id="download_detail_pdf" value="Download Pdf" type="button" title="Click here to download file as pdf."><i class="fa fa-file-pdf-o"></i> Download Pdf</button>--></div>
		<?=form_open('talent/detail_five_talent_class/false','id="form_data"')?>
			<?=isset($filter)?form_hidden($filter):''?>
			<?php 
				if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
			?>
			<div class="panel panel-primary filter_area" style="display:none;margin-top:5px;">
				<div class="panel-heading"><h3 class="panel-title">Pencarian</h3></div>
				<div class="panel-body">
					<div class="col-md-12"> Pekerja : <?=form_input(array('name' => 'f_pekerja', 'id' => 'f_pekerja', 'class' => 'form-control input-sm filter f_pekerja', 'value' => '', 'placeholder' => 'Pekerja', 'rel' => 'Pekerja', 'yn' => 'pekerja'));?>
					</div>
					<div class="col-md-12"> Direktorat : <?=form_dropdown('f_direktorat',(isset($opt_direktorat)?array(''=>'- Choose Direktorat -')+$opt_direktorat:array(''=>'- Choose Direktorat -')),$this->input->post('f_direktorat'),'class="form-control f_direktorat input-sm" id="f_direktorat" title="Choose Direktorat here."');?>
					</div>
					<div class="col-md-12">
						<br>
						<button class="btn btn-theme" name="cari" id="cari" value="Cari" type="button" title="Klik di sini untuk mencari data."><i class="fa fa-search"></i> Cari</button>
						<button class="btn btn-warning" name="cari_all" id="cari_all" value="Semua" type="button" title="Klik di sini untuk menampilkan semua data."><i class="fa fa-search-plus"></i> Semua</button>
					</div>
					</form>
				</div>
			</div>
			<?php 
				} else {
			?>
				<div class="panel panel-primary filter_area" style="display:none;margin-top:5px;">
					<div class="panel-heading"><h3 class="panel-title">Pencarian</h3></div>
					<div class="panel-body">
						<div class="col-md-12"> Pekerja : <?=form_input(array('name' => 'f_pekerja', 'id' => 'f_pekerja', 'class' => 'form-control input-sm filter f_pekerja', 'value' => '', 'placeholder' => 'Pekerja', 'rel' => 'Pekerja', 'yn' => 'pekerja'));?>
						</div>
						<div class="col-md-12">
							<br>
							<button class="btn btn-theme" name="cari" id="cari" value="Cari" type="button" title="Klik di sini untuk mencari data."><i class="fa fa-search"></i> Cari</button>
							<button class="btn btn-warning" name="cari_all" id="cari_all" value="Semua" type="button" title="Klik di sini untuk menampilkan semua data."><i class="fa fa-search-plus"></i> Semua</button>
						</div>
						</form>
					</div>
				</div>
			<?php 
				}
	     	?>	
			<table align="center" width="100%" cellpadding="3px" cellspacing="0px" class="table-theme responsive-general-table" border="0" style="margin-top:5px;">
			<thead>
				<tr>
					<th width="5%" align="center" rowspan="2">No</th>
					<th width="10%" align="center" rowspan="2">PN</th>
					<th width="10%" align="center" rowspan="2">Nama</th>
					<!--<th width="10%" align="center">Uker</th>-->
					<th width="10%" align="center" rowspan="2">Cost Center</th>
					<th width="10%" align="center" rowspan="2">Direktorat</th>
					<th width="10%" align="center" rowspan="2">EXP</th>
					<th width="10%" align="center" rowspan="2">Talent Class</th>
					<th width="10%" align="center" colspan="2">Score Assessment</th>
					<th width="10%" align="center" colspan="3">Performance</th>
					<th width="10%" align="center" rowspan="2">Final Result</th>
					<th width="6%" align="center" rowspan="2">Profil</th>
				</tr>
				<tr>
					<th align="center">Score</th>
					<th align="center">Recommendation</th>
					<th align="center">KPI</th>
					<th align="center">Competency</th>
					<th align="center">Score</th>
				</tr>
			</thead>
			<?php 
			if(isset($hav)){
				if(count($hav)>0){
			?>
			<tbody>
			<?php
					foreach($hav as $row){
			?>
				<tr>
					<td align="center" data-title="No"><?=$no?>.</td>
					<td align="center" data-title="PN"><?=isset($row->pernr)?$row->pernr:''?></td>
					<td align="center" data-title="Nama"><?=isset($row->nama)?$row->nama:''?></td>
					<!--<td align="center" data-title="Uker"><?=isset($row->subarea)?$row->subarea:''?></td>-->
					<td align="center" data-title="CC"><?=isset($row->costcenter)?$row->costcenter:''?></td>
					<td align="center" data-title="CC"><?=isset($row->organization_desc)?$row->organization_desc:'-'?></td>
					<td align="center" data-title="EXP"><?=isset($row->expertise)?$row->expertise:'-'?></td>
					<td align="center" data-title="Talent Class"><?=isset($row->talent_class)?$row->talent_class_desc . ' ('. $row->talent_class .')':'-'?></td>
					<!--<td align="center" data-title="Score"><?=isset($row->avg_kompetensi)?$row->avg_kompetensi :'-'?></td>-->
					<td align="center" data-title="Score"><?=isset($row->poin_asm)?$row->poin_asm :'-'?></td>
					<td align="center" data-title="Readiness"><?=isset($row->readiness)?$row->readiness :'-'?></td>
					<td align="center" data-title="KPI"><?=isset($row->avg_sko)?$row->avg_sko :'-'?></td>
					<td align="center" data-title="Competency"><?=isset($row->avg_sk)?$row->avg_sk :'-'?></td>
					<td align="center" data-title="Ratas SMK"><?=isset($row->avg_score)?$row->avg_score :'-'?></td>
					<!--<td align="center" data-title="Final Score"><?=isset($row->sum_avg)?$row->sum_avg :'-'?></td>-->
					<td align="center" data-title="Final Score"><?=isset($row->poin_talent)?$row->poin_talent :'-'?></td>
					<td align="center" data-title="Profil">
						<span class="blue link cv" title="Click here to download CV."  id="<?=isset($row->pernr)?$row->pernr:''?>">CV</span>
					</td>
				</tr>
			<?php
						$no++;
					}
			?>
			</tbody>
			<tfoot>
			<tr>
				<th align="left" colspan="15">Jumlah Data : <?php echo isset($jml_data)?$jml_data:'';?> Records</th>
			</tr>
			<tr>
				<th align="left" colspan="15">Jumlah Halaman : <?php echo isset($jml_hal)?$jml_hal:'';?> Halaman</th>
			</tr>
			<?php
					if($jml_hal>1){
			?>
			<tr>
				<td align="left" colspan="15" id="row-pagging"><?php echo isset($paging)?$paging:'';?></td>
			</tr>
			<?php
					}
			?>
			</tfoot>
			<?php
				}else{
			?>
			<tfoot>
			<tr>
				<th colspan="15">
					<div class="alert alert-danger message" role="alert">- Data tidak ditemukan -</div>
				</th>
			</tr>
			</tfoot>
			<?php
				}
			}
			?>
			</table>
		</form>
	</div>
</div>
<script>
$(document).ready(function(){

	$('#cari_all').off().click(function(e){
		$('.f_pekerja').val("");
		$('.f_direktorat').val("");
		$('.select2-chosen').html("");
		search_hav();
		e.preventDefault();
	});
	$('#cari').off().click(function(e){
		search_hav();
		e.preventDefault();
	});

	$('#back_btn').off().click(function(e){
		$('#general_popup').modal('hide');
		e.preventDefault();
	});
	$('#download_detail_pdf').click(function() {
            location.href = "<?= site_url('talent/detail_five_talent_class_pdf'); ?>?" + $('#form_data').serialize();
            return false;
	});
	
	$('#download_detail_excel').click(function() {
		location.href = "<?= site_url('talent/detail_five_talent_class_excel'); ?>?" + $('#form_data').serialize();
		return false;
	});
	
	$(".cv").off().click(function(e){
		var id = $(this).attr('id');
		$(this).myAjax({
			url : '<?=site_url('talent/detail_pekerja')?>',
			data: 'mt=1&ctrl=talent&source=detail_five_talent_class_back&pernr='+id+'&'+$('#form_data').serialize(),
			success: function(data){
				$('#general_popup .modal-dialog .modal-content').empty();
				$('#general_popup .modal-dialog').removeClass('modal-lg modal-md modal-sm modal-hav modal-successor modal-compare modal-cv').addClass('modal-lg');
				$('#general_popup .modal-dialog .modal-content').html(data);
				$('#ajax-loader').hide();
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});
	
	$("#row-pagging a:not('.active')").off().click(function(e){
		$(this).myAjax({
			url : $(this).attr('href'),
			data: 'mt=1&'+$('#form_data').serialize(),
			success: function(data){
				$('#general_popup .modal-dialog .modal-content').html(data);
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});

	$('#filter_show').off().click(function(e){
		$('#filter_hide').show();
		$('.filter_area').show();
		$(this).hide();
		e.preventDefault();
	});

	$('#filter_hide').off().click(function(e){
		$('#filter_show').show();
		$('.filter_area').hide();
		$(this).hide();
		e.preventDefault();
	});

	$(".f_pekerja").select2({
		placeholder: "Pekerja",
		minimumInputLength: 3,
		quietMillis: 100,
		allowClear: true,
		ajax:{
			url : "<?=site_url("konfigurasi/get_pekerja");?>",
			dataType: 'json',
			data : function(term) {
				return {
					searchTerm : term
				};
			},
			results : function(data) {
				return { results : data }
			}
		},
		initSelection: function(element, callback) {
			var id = element.val();
			var data = { id: element.val(), text:element.next().val() };
			callback(data);
		}
	}).on('change', function(e){
		$(this).next().val($(this).select2('data').text);
	});
});

function search_hav(){
	$(this).myAjax({
		url : "<?=site_url("talent/detail_five_talent_class");?>",
		data: 'mt=1&'+$('#form_data').serialize(),
		success: function(data){
			$('#general_popup .modal-dialog .modal-content').html(data);
			$('#ajax-loader').hide();
		}
	});
}
</script>