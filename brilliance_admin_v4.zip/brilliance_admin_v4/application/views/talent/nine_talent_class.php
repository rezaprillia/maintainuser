<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<style>
	.rotateCell {
		text-align: center;
		-webkit-transform: rotate(-90deg);
		-moz-transform: rotate(-90deg);
		-ms-transform: rotate(-90deg);
		-o-transform: rotate(-90deg);
		filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=3);
	}
	.borderSelected {
		border:1px solid blue;
	}
</style>

<form id="form_input">
<?=form_hidden($param);?>
</form>
<!--<div align="right" style=""><button class="btn btn-success btn-sm" id="download_excel" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>&nbsp;&nbsp;<button class="btn btn-theme btn-sm" id="download_pdf" value="Download Pdf" type="button" title="Click here to download file as pdf."><i class="fa fa-file-pdf-o"></i> Download Pdf</button></div>-->
<br>
<div align="center" style="font-size:20px;margin-left:150px;"><strong>Nine Talent Class HAV Matrix</strong></div>
<br>
<table width="750" height="218" align="center">
   <tbody>
	  <tr>
		 <td align="center">
			<table style="border-collapse:collapse" width="100%" border="0" align="center" cellspacing="0" cellpadding="0">
			   <tbody>
				  <tr>
					 <td colspan="4" class="scheduler-border">
						<table class="nine_table" style="border-collapse:collapse" width="100%" border="1" cellspacing="0" cellpadding="0">
						   <tbody>
							  <tr>
								<td height="100" rowspan="3" style="border-left: solid 1px #FFF;border-top: solid 1px #FFF;border-bottom: solid 1px #FFF;font-size:20px;">
									<div class="rotateCell"><strong>Potential</strong></div>
								 </td>
								 <td height="100" align="center" bgcolor="#2de540">
									<div class="rotateCell"><strong>High</strong></div>
								 </td>
								 <td height="100" bgcolor="#e8d614" width="30%">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
										<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q7&legend=UNDER ACHIEVER" id="[1,1]" title="UNDER ACHIEVER" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
										<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q7&legend=UNDER ACHIEVER" id="[1,1]" title="UNDER ACHIEVER" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									}
								 ?>		
									   <table width="100%" height="100%">
										  <tbody>
											 <tr>
												<td style="text-align:center;font-size:20px;"><?=$Q7;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">UNDER ACHIEVER</td>
											 </tr>
										  </tbody>
									   </table>
									</div>
								 </td>
								 <td height="100" bgcolor="#19ea5f" width="30%">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q2&legend=HIGH POTENTIALS" id="[1,2]" title="HIGH POTENTIALS" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
								 	<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q2&legend=HIGH POTENTIALS" id="[1,2]" title="HIGH POTENTIALS" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">	   
								 <?php 
									}
								 ?>		
										<table width="100%" height="100%">
										  <tbody>
											<tr>
												<td style="text-align:center;font-size:20px;"><?=$Q2;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">HIGH POTENTIALS</td>
											 </tr>
										  </tbody>
									   </table>
									</a>
								 </td>
								 <td height="100" bgcolor="#19ea5f" width="30%">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q1&legend=HIGH POTENTIALS" id="[1,3]" title="HIGH POTENTIALS" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
								 	<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q1&legend=HIGH POTENTIALS" id="[1,3]" title="HIGH POTENTIALS" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">	   
								 <?php 
									}
								 ?>
										<table width="100%" height="100%">
										  <tbody>
											<tr>
												<td style="text-align:center;font-size:20px;"><?=$Q1;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">HIGH POTENTIALS</td>
											 </tr>
										  </tbody>
									   </table>
									</a>
								 </td>
							  </tr>
							  <tr>
								<td height="100" align="center" bgcolor="#e0f920">
									<div class="rotateCell"><strong>Moderate</strong></div>
								 </td>
								 <td height="100" bgcolor="#e8d614">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q8&legend=UNDER ACHIEVER" id="[2,1]" title="UNDER ACHIEVER" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q8&legend=UNDER ACHIEVER" id="[2,1]" title="UNDER ACHIEVER" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									}
								 ?>
										<table width="100%" height="100%">
										  <tbody>
											<tr>
												<td style="text-align:center;font-size:20px;"><?=$Q8;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">UNDER ACHIEVER</td>
											 </tr>
										  </tbody>
									   </table>
									</a>
								 </td>
								 <td height="100" bgcolor="#38c9e0">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q4&legend=CRITICAL RESOURCES" id="[2,2]" title="CRITICAL RESOURCES" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
								 	<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q4&legend=CRITICAL RESOURCES" id="[2,2]" title="CRITICAL RESOURCES" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									}
								 ?>
										<table width="100%" height="100%">
										  <tbody>
											<tr>
												<td style="text-align:center;font-size:20px;"><?=$Q4;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">CRITICAL RESOURCES</td>
											 </tr>
										  </tbody>
									   </table>
									</a>
								 </td>
								 <td height="100" bgcolor="#38c9e0">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q3&legend=CRITICAL RESOURCES" id="[2,3]" title="CRITICAL RESOURCES" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
								 	<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q3&legend=CRITICAL RESOURCES" id="[2,3]" title="CRITICAL RESOURCES" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									}
								 ?>
										<table width="100%" height="100%">
										  <tbody>
											<tr>
												<td style="text-align:center;font-size:20px;"><?=$Q3;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">CRITICAL RESOURCES</td>
											 </tr>
										  </tbody>
									   </table>
									</a>
								 </td>
							  </tr>
							  <tr>
								<td height="100" align="center" bgcolor="#f9bddf">
									<div class="rotateCell"><strong>Low</strong></div>
								 </td>
								 <td height="100" bgcolor="#808284">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q9&legend=LIMITED CONTRIBUTOR" id="[3,1]" title="LIMITED CONTRIBUTOR" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
								 	<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q9&legend=LIMITED CONTRIBUTOR" id="[3,1]" title="LIMITED CONTRIBUTOR" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									}
								 ?>
										<table width="100%" height="100%">
										  <tbody>
											<tr>
												<td style="text-align:center;font-size:20px;"><?=$Q9;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">LIMITED CONTRIBUTOR</td>
											 </tr>
										  </tbody>
									   </table>
									</a>
								 </td>
								 <td height="100" bgcolor="#cc7410">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q6&legend=KEY CONTRIBUTOR" id="[3,2]" title="KEY CONTRIBUTOR" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
								 	<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q6&legend=KEY CONTRIBUTOR" id="[3,2]" title="KEY CONTRIBUTOR" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									}
								 ?>
										<table width="100%" height="100%">
										  <tbody>
											<tr>
												<td style="text-align:center;font-size:20px;"><?=$Q6;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">KEY CONTRIBUTOR</td>
											 </tr>
										  </tbody>
									   </table>
									</a>
								 </td>
								 <td height="100" bgcolor="#cc7410">
								 <?php 
									if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
								 ?>
									<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&job=<?=$job;?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q5&legend=KEY CONTRIBUTOR" id="[3,3]" title="KEY CONTRIBUTOR" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									} else{
								 ?>
								 	<div rel="jenis_asesmen=<?=$jenis_asesmen?>&corp_title=<?=$corp_title?>&method=<?=$method;?>&type=<?=$type;?>&talent_class=Q5&legend=KEY CONTRIBUTOR" id="[3,3]" title="KEY CONTRIBUTOR" class="detail_hav" style="cursor:pointer;color:black;font-weight:bold;height:100%;">
								 <?php 
									}
								 ?>
										<table width="100%" height="100%">
										  <tbody>
											<tr>
												<td style="text-align:center;font-size:20px;"><?=$Q5;?></td>
											 </tr>
											 <tr>
												<td style="vertical-align:bottom;text-align:center;">KEY CONTRIBUTOR</td>
											 </tr>
										  </tbody>
									   </table>
									</a>
								 </td>
							  </tr>
							  <tr>
								<td height="40" align="center" style="border-left: solid 1px #FFF;border-bottom: solid 1px #FFF;" colspan="2">
									
								 </td>
								 <td align="center" bgcolor="#f9bddf">
									<strong>Low</strong>
								 </td>
								 <td align="center" bgcolor="#e0f920">
									<strong>Moderate</strong>
								 </td>
								 <td align="center" bgcolor="#2de540">
									<strong>High</strong>
								 </td>
							  </tr>
							  <tr>
								 <td align="center" colspan="5" style="border-left: solid 1px #FFF;border-right: solid 1px #FFF;border-bottom: solid 1px #FFF;font-size:20px;">
									<div style="margin-top:10px;margin-left:150px;"><strong><?= "Performance";//isset($selected_asesmen)?$selected_asesmen:'-';?></strong></div>
								 </td>
							  </tr>
						   </tbody>
						</table>
					 </td>
				  </tr>
			   </tbody>
			</table>
		 </td>
	  </tr>
	  </tr>
   </tbody>
</table>
<script>
    $(document).ready(function() {
		$(".detail_hav").click(function(){
			$(this).closest('.nine_table').find('.borderSelected').removeClass('borderSelected');
			$(this).addClass('borderSelected');
			var rel = $(this).attr('rel');
			$(this).myAjax({
				url : '<?=site_url('talent/detail_nine_talent_class')?>',
				data: 'mt=1&'+rel,
				success: function(data){
					$('#general_popup .modal-dialog').removeClass('modal-lg modal-md modal-sm modal-hav modal-successor modal-compare modal-cv').addClass('modal-hav');
					$('#general_popup .modal-dialog .modal-content').html(data);
					$('#general_popup').modal({'backdrop':'static'});
					$('#ajax-loader').hide();
				}
			});
		});
		
		$('#download_pdf').click(function() {
            location.href = "<?= site_url('talent/nine_talent_class_pdf'); ?>?" + $('#form_input').serialize();
            return false;
        });
		
		$('#download_excel').click(function() {
            location.href = "<?= site_url('talent/nine_talent_class_excel'); ?>?" + $('#form_input').serialize();
            return false;
        });

    });
</script>