<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<link rel="stylesheet" type="text/css" href="<?=base_url()?>sources/plugins/multiselect/bootstrap/bootstrap-multiselect.css" />
<script type="text/javascript" src="<?=base_url()?>sources/plugins/multiselect/bootstrap/bootstrap-multiselect.js"></script>
<style type="text/css">
.no-padding-both{
	padding-left: 0px !important;
	padding-right: 0px !important;
}
</style>

<h3 class="maintitle"><i class="fa fa-search"></i> <span> Pencarian Data Pekerja</span></h3>
<?=isset($breadcrum)?$breadcrum:'';?>
<?=isset($message) ? $message : '';?>
<?=form_open('template/cari_template','id="form_filter_template"');?>
<div class="panel panel-info">
  	<div class="panel-heading"><label style="color:#0155aa">Data Utama SDM</label></div>
  	<div class="panel-body">

  		<div class="row">
  			<div class="col-md-3">Personal Number : 	<?=form_input(array('name' => 'fa_pernr', 'id' => 'fa_pernr', 'class' => 'form-control input-sm'));?> <textarea class="form-control input-sm" name="f_pernr" id="f_pernr" rows="2" style="resize:none"></textarea></div>
			<?php
				if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KP'){
			?>
  			<div class="col-md-3">Personnel Area : 		<?=form_input(array('name' => 'fa_pa', 'id' => 'fa_pa', 'class' => 'form-control input-sm'));?> <textarea class="form-control input-sm" name="f_pa" id="f_pa" rows="2" style="resize:none"></textarea></div>
  			<div class="col-md-3">Personnel Sub Area : 	<?=form_input(array('name' => 'fa_psa', 'id' => 'fa_psa', 'class' => 'form-control input-sm'));?> <textarea name="f_psa" id="f_psa" class="form-control input-sm" rows="2" style="resize:none"></textarea></div>
			<?php
				}
			?>
			<?php
				if($_SESSION[$this->config->item('session_prefix')]['tipe_uker'] == 'KW'){
			?>
  			<div class="col-md-3">Personnel Sub Area : 	<?=form_input(array('name' => 'fa_psa', 'id' => 'fa_psa', 'class' => 'form-control input-sm'));?> <textarea name="f_psa" id="f_psa" class="form-control input-sm" rows="2" style="resize:none"></textarea></div>
			<?php
				}
			?>
  			<div class="col-md-3">Jenis Kelamin :	 	<?=form_dropdown('f_jenis_kelamin',array('' => '- Pilih Jenis Kelamin -','L'=>'Laki-laki','P' => 'Perempuan'),'','id="f_jenis_kelamin" class="form-control input-sm"');?></div>
  		</div>

  		<div class="row">
  			<div class="col-md-3 no-padding-both">
  				<div class="col-md-6 ">Job Grade Min : <?=form_dropdown('f_jg_min',isset($opt_job_grade)?$opt_job_grade:array('' => '- Pilih JG -'),'','id="f_jg_min" class="form-control input-sm"');?></div>
  				<div class="col-md-6 ">Job Grade Max : <?=form_dropdown('f_jg_max',isset($opt_job_grade)?$opt_job_grade:array('' => '- Pilih JG -'),'','id="f_jg_max" class="form-control input-sm"');?></div>
  			</div>
  			<div class="col-md-3 no-padding-both">
  				<div class="col-md-6 ">Person Grade Min : <?=form_dropdown('f_pg_min',isset($opt_person_grade)?$opt_person_grade:array('' => '- Pilih PG -'),'','id="f_pg_min" class="form-control input-sm"');?></div>
  				<div class="col-md-6 ">Person Grade Max : <?=form_dropdown('f_pg_max',isset($opt_person_grade)?$opt_person_grade:array('' => '- Pilih PG -'),'','id="f_pg_max" class="form-control input-sm"');?></div>
  			</div>
  			<div class="col-md-3 no-padding-both">
  				<div class="col-md-6 ">Usia Min : <?=form_input(array('name' => 'f_usia_min', 'id' => 'f_usia_min', 'class' => 'form-control input-sm number_only'));?></div>
  				<div class="col-md-6 ">Usia Max : <?=form_input(array('name' => 'f_usia_max', 'id' => 'f_usia_max', 'class' => 'form-control input-sm number_only'));?></div>
  			</div>
  			<div class="col-md-3">Agama : <?=form_dropdown('f_agama',isset($opt_agama)?$opt_agama:array('' => '- Pilih Agama -'),'','id="f_agama" class="form-control input-sm"');?></div>
  		</div>


  		<div class="row">
  			<div class="col-md-3">Jabatan : <?=form_dropdown('f_jabatan[]',isset($opt_jabatan)?$opt_jabatan:array(),($this->input->post('f_jabatan')?$this->input->post('f_jabatan'):(isset($selected_jabatan)?$selected_jabatan:array())),' id="f_jabatan" class="multiselect" multiple="multiple" title="Pilih Jabatan di sini."')?></div>
  			<div class="col-md-3">Program Masuk : <?=form_dropdown('f_program_masuk[]',isset($opt_program_masuk)?$opt_program_masuk:array(),($this->input->post('f_program_masuk')?$this->input->post('f_program_masuk'):(isset($selected_mk_jabatan)?$selected_mk_jabatan:array())),' id="f_program_masuk" class="multiselect" multiple="multiple" title="Pilih Program Masuk di sini."')?></div>
  			<div class="col-md-3">MK Jabatan : 		<?=form_dropdown('f_mk_jabatan[]',isset($opt_mk_jabatan_uker)?$opt_mk_jabatan_uker:array(),($this->input->post('f_mk_jabatan')?$this->input->post('f_mk_jabatan'):(isset($selected_mk_jabatan)?$selected_mk_jabatan:array())),' id="f_mk_jabatan" class="multiselect" multiple="multiple" title="Pilih MK Jabatan di sini."')?></div>
  			<div class="col-md-3">MK Job Grade : <?=form_dropdown('f_mk_jg[]',isset($opt_mk_jg_pg)?$opt_mk_jg_pg:array(),($this->input->post('f_mk_jg')?$this->input->post('f_mk_jg'):(isset($selected_mk_jg)?$selected_mk_jg:array())),' id="f_mk_jg" class="multiselect" multiple="multiple" title="Pilih MK Job Grade di sini."')?></div>
  		</div>

  		<div class="row">
  			<div class="col-md-3">MK Person Grade : <?=form_dropdown('f_mk_pg[]',isset($opt_mk_jg_pg)?$opt_mk_jg_pg:array(),($this->input->post('f_mk_pg')?$this->input->post('f_mk_pg'):(isset($selected_mk_pg)?$selected_mk_pg:array())),' id="f_mk_pg" class="multiselect" multiple="multiple" title="Pilih MK Person Grade di sini."')?></div>
  			<div class="col-md-3">MK Unit kerja : <?=form_dropdown('f_mk_uker[]',isset($opt_mk_jabatan_uker)?$opt_mk_jabatan_uker:array(),($this->input->post('f_mk_uker')?$this->input->post('f_mk_jg'):(isset($selected_mk_uker)?$selected_mk_uker:array())),' id="f_mk_uker" class="multiselect" multiple="multiple" title="Pilih MK Unit Kerja di sini."')?></div>
  			<div class="col-md-3"></div>
  			<div class="col-md-3"></div>
  		</div>

  	</div>
</div>


<div class="panel panel-info">
  	<div class="panel-heading"><label style="color:#0155aa">Data Pendidikan</label></div>
  	<div class="panel-body">

  		<div class="row">
  			<div class="col-md-3">Universitas : <!--<?=form_input(array('name' => 'f_universitas', 'id' => 'f_universitas', 'class' => 'form-control input-sm'));?>--> <textarea class="form-control input-sm" name="f_universitas" id="f_universitas" rows="2" style="resize:none"></textarea></div>
  			<div class="col-md-3">Jurusan : <!--<?=form_input(array('name' => 'f_jurusan', 'id' => 'f_jurusan', 'class' => 'form-control input-sm'));?>--> <textarea class="form-control input-sm" name="f_jurusan" id="f_jurusan" rows="2" style="resize:none"></textarea></div>
  			<div class="col-md-3">Sertifikasi : <?=form_dropdown('f_sertifikasi',isset($opt_sertifikasi)?$opt_sertifikasi:array('' => '- Pilih Sertifikasi -'),'','id="f_sertifikasi" class="form-control input-sm"');?></div>
  			<div class="col-md-3">Pendidikan / Training / PC  : <!--<?=form_input(array('name' => 'f_training', 'id' => 'f_training', 'class' => 'form-control input-sm'));?>--><textarea class="form-control input-sm" name="f_training" id="f_training" rows="2" style="resize:none"></textarea></div>
  		</div>

  		<div class="row">
  			<div class="col-md-3">Rangking di Corpu : <?=form_input(array('name' => 'f_rangking', 'id' => 'f_rangking', 'class' => 'form-control input-sm', 'disabled'=>'disabled'));?></div>
  			<div class="col-md-3 no-padding-both">
  				<div class="col-md-6 ">IPK / GPA Min: <?=form_input(array('name' => 'f_ipk_min', 'id' => 'f_ipk_min', 'class' => 'form-control input-sm number_only'));?></div>
  				<div class="col-md-6 ">IPK / GPA Max: <?=form_input(array('name' => 'f_ipk_max', 'id' => 'f_ipk_max', 'class' => 'form-control input-sm number_only'));?></div>
  			</div>
  			<div class="col-md-3">Skor Bahasa Asing : <?=form_input(array('name' => 'f_skor_bahasa_asing', 'id' => 'f_skor_bahasa_asing', 'class' => 'form-control input-sm number_only'));?></div>
  			<div class="col-md-3"></div>
  		</div>

  	</div>
</div>

<div class="row">
	<!-- <div class="col-md-6">

		<div class="panel panel-info">
		  	<div class="panel-heading"><label style="color:#0155aa">Riwayat Kesehatan</label></div>
		  	<div class="panel-body">

		  		<div class="row">
					<div class="col-md-6">Jenis Klaim : <?=form_dropdown('f_jenis_klaim[]',isset($opt_jenis_klaim)?$opt_jenis_klaim: array(''=> '- Pilih Jenis Klaim -'),'','id="f_jenis_klaim" class="multiselect" multiple="multiple"');?></div>
		  			<div class="col-md-6">Kelompok Penyakit : <?=form_dropdown('f_kelompok_penyakit',isset($opt_kelompok_penyakit)?$opt_kelompok_penyakit: array(''=> '- Pilih Kelompok Penyakit -'),'','id="f_kelompok_penyakit" class="form-control input-sm"');?></div>
		  			
		  		</div>

		  	</div>
		</div>
	</div> -->
	<div class="col-md-6">
		<div class="panel panel-info">
		  	<div class="panel-heading"><label style="color:#0155aa">Data Reward</label></div>
		  	<div class="panel-body">

		  		<div class="row">
		  			<div class="col-md-6">ITP MIN : <?=form_input(array('name' => 'f_itp_min', 'id' => 'f_itp_min', 'class' => 'form-control input-sm number_only'));?></div>
		  			<div class="col-md-6">ITP MAX : <?=form_input(array('name' => 'f_itp_max', 'id' => 'f_itp_max', 'class' => 'form-control input-sm number_only'));?></div>
		  		</div>

		  	</div>
		</div>	
	</div>

	
	<div class="col-md-6">
		<div class="panel panel-info">
			<div class="panel-heading"><label style="color:#0155aa">Data SMK</label></div>
			<div class="panel-body">

				<div class="row">
					<div class="col-md-3">SMK (SKO) MIN : <?=form_input(array('name' => 'f_sko_min', 'id' => 'f_sko_min', 'class' => 'form-control input-sm number_only'));?></div>
					<div class="col-md-3">SMK (SKO) MAX : <?=form_input(array('name' => 'f_sko_max', 'id' => 'f_sko_max', 'class' => 'form-control input-sm number_only'));?></div>
					<div class="col-md-3">SMK (SKK) MIN : <?=form_input(array('name' => 'f_skk_min', 'id' => 'f_skk_min', 'class' => 'form-control input-sm number_only'));?></div>
					<div class="col-md-3">SMK (SKK) MAX : <?=form_input(array('name' => 'f_skk_max', 'id' => 'f_skk_max', 'class' => 'form-control input-sm number_only'));?></div>
					<div class="col-md-3">SMK MIN : <?=form_input(array('name' => 'f_smk_min', 'id' => 'f_smk_min', 'class' => 'form-control input-sm number_only'));?></div>
					<div class="col-md-3">SMK MAX : <?=form_input(array('name' => 'f_smk_max', 'id' => 'f_smk_max', 'class' => 'form-control input-sm number_only'));?></div>
					<div class="col-md-3">Tahun SMK : <?=form_input(array('name' => 'f_tahun_smk', 'id' => 'f_tahun_smk', 'class' => 'form-control input-sm number_only'));?></div>
				</div>
			</div>
		</div>	
	</div>
</div>



<div class="row">
	<!-- <div class="col-md-6">
		<div class="panel panel-info">
			<div class="panel-heading"><label style="color:#0155aa">Data Assessment</label></div>
			<div class="panel-body">

				<div class="row">
					<div class="col-md-6">Rekomendasi / Hasil Assessment : <?=form_dropdown('f_rekomendasi_asesmen[]',isset($opt_rekomendasi_asesmen)?$opt_rekomendasi_asesmen: array(''=> '- Pilih Rekomendasi Assessment -'),'','id="f_rekomendasi_asesmen" class="multiselect" multiple="multiple"');?></div>
					<div class="col-md-6">Judul Assessment : <?=form_input(array('name' => 'f_judul_assesment', 'id' => 'f_judul_assesment', 'class' => 'form-control input-sm'));?></div>
				</div>

			</div>
		</div>	
	</div> -->
</div>

<div class="row">
	<div class="col-md-6">

		<div class="panel panel-info">
		  	<div class="panel-heading"><label style="color:#0155aa">Data Pengembangan Karir</label></div>
		  	<div class="panel-body">

		  		<div class="row">
		  			<div class="col-md-6">Jabatan : <!--<?=form_input(array('name' => 'f_histori_jabatan', 'id' => 'f_histori_jabatan', 'class' => 'form-control input-sm'));?>--><textarea class="form-control input-sm" name="f_histori_jabatan" id="f_histori_jabatan" rows="2" style="resize:none"></textarea></div>
		  			<div class="col-md-6">Unit Kerja : <!--<?=form_input(array('name' => 'f_histori_uker', 'id' => 'f_histori_uker', 'class' => 'form-control input-sm'));?>--><textarea class="form-control input-sm" name="f_histori_uker" id="f_histori_uker" rows="2" style="resize:none"></textarea></div>
		  		</div>

		  	</div>
		</div>	

	</div>
	<div class="col-md-6">


		<div class="panel panel-info">
		  	<div class="panel-heading"><label style="color:#0155aa">Data Alamat</label></div>
		  	<div class="panel-body">

		  		<div class="row">
		  			<div class="col-md-6">Homebase : <?=form_input(array('name' => 'f_homebase', 'id' => 'f_homebase', 'class' => 'form-control input-sm'));?></div>
		  			<div class="col-md-6">Domisili : <?=form_input(array('name' => 'f_domisili', 'id' => 'f_domisili', 'class' => 'form-control input-sm'));?></div>
		  		</div>

		  	</div>
		</div>

	</div>
</div>

<div class="row">
	<!-- <div class="col-md-6">
		<div class="panel panel-info">
			<div class="panel-heading"><label style="color:#0155aa">Data Psikotes (UC)</label></div>
			<div class="panel-body">

				<div class="row">
					<div class="col-md-6">IQ : <?=form_input(array('name' => 'f_iq', 'id' => 'f_iq', 'class' => 'form-control input-sm number_only'));?></div>
					<div class="col-md-6">Minat / Aspirasi : <?=form_input(array('name' => 'f_minat', 'id' => 'f_minat', 'class' => 'form-control input-sm'));?></div>
				</div>

			</div>
		</div>	
	</div> -->

	<div class="col-md-6">
		<div class="panel panel-info">
		  	<div class="panel-heading"><label style="color:#0155aa">Data HBI</label></div>
		  	<div class="panel-body">

		  		<div class="row">
		  			<div class="col-md-6">Insus : <?=form_dropdown('f_insus[]',isset($opt_insus)?$opt_insus: array(''=> '- Pilih Status Insus -'),'','id="f_insus" class="multiselect" multiple="multiple"');?></div>
		  			<div class="col-md-6">Masa Hukuman : <?=form_input(array('name' => 'f_masa_hukuman', 'id' => 'f_masa_hukuman', 'class' => 'form-control input-sm', 'disabled' => true));?></div>
		  		</div>

		  	</div>
		</div>	


	</div>
</div>


<!-- <div class="panel panel-info">
	<div class="panel-heading"><label style="color:#0155aa">Data Lainnya (UC)</label></div>
	<div class="panel-body">

		<div class="row">
			<div class="col-md-3">Hobi : <?=form_input(array('name' => 'f_hobi', 'id' => 'f_hobi', 'class' => 'form-control input-sm'));?></div>
			<div class="col-md-3 no-padding-both">
				<div class="col-md-6 ">Tinggi Badan Min : <?=form_input(array('name' => 'f_tinggi_min', 'id' => 'f_tinggi_min', 'class' => 'form-control input-sm number_only'));?></div>
				<div class="col-md-6 ">Tinggi Badan Max : <?=form_input(array('name' => 'f_tinggi_max', 'id' => 'f_tinggi_max', 'class' => 'form-control input-sm number_only'));?></div>
			</div>
			<div class="col-md-3 no-padding-both">
				<div class="col-md-6 ">Berat Badan Min : <?=form_input(array('name' => 'f_berat_min', 'id' => 'f_tinggi_min', 'class' => 'form-control input-sm number_only'));?></div>
				<div class="col-md-6 ">Berat Badan Max : <?=form_input(array('name' => 'f_berat_max', 'id' => 'f_tinggi_max', 'class' => 'form-control input-sm number_only'));?></div>
			</div>
			<div class="col-md-3">Keahlian : <?=form_input(array('name' => 'f_keahlian', 'id' => 'f_keahlian', 'class' => 'form-control input-sm'));?></div>
		</div>

		<div class="row">
			<div class="col-md-3">Penguasaan Bahasa : <?=form_dropdown('f_penguasaan_bahasa',isset($opt_penguasaan_bahasa)?$opt_penguasaan_bahasa: array(''=> '- Pilih Penguasaan Bahasa -'),'','id="f_penguasaan_bahasa" class="form-control input-sm"');?></div>
			<div class="col-md-3">Pengalaman Kerja : <?=form_dropdown('f_pengalaman_kerja',isset($opt_bidang_pekerjaan)?$opt_bidang_pekerjaan: array(''=> '- Pilih Bidang Pekerjaan -'),'','id="f_pengalaman_kerja" class="form-control input-sm"');?></div>
			<div class="col-md-3"></div>
			<div class="col-md-3"></div>
		</div>

	</div>
</div>	 -->


<div class="row">
	<div class="col-md-6">
		<button class="btn btn-theme" name="cari" id="cari" value="Cari" type="submit" title="Klik di sini untuk mencari data."><i class="fa fa-search"></i> Cari</button>
	</div>

	<!--<div class="col-md-6 text-right">
		<button class="btn btn-warning" name="simpan" id="simpan" value="Simpan Template" type="button" title="Klik di sini untuk menyimpan data."><i class="fa fa-save"></i> Simpan Template</button>
	</div>-->
</div>
<?=form_close();?>

<div class="panel panel-primary" style="margin-bottom:10px;margin-top:10px;display:none;" id="panel_info">
	  <div class="panel-body">

		<div class="row">
			<div class="col-md-2"><label>Waktu Mulai Pencarian</label></div>
			<div class="col-md-10"><span id="start_process"></span></div>
		</div>

		<div class="row">
			<div class="col-md-2"><label>Elapse Time</label></div>
			<div class="col-md-10"><span id="elapse_time"></span></div>
		</div>

		<div class="row">
			<div class="col-md-2"><label>Progress Status</label></div>
			<div class="col-md-10"><span id="progress_status"></span></div>
		</div>

		<div class="row">
			<div class="col-md-2"><label>Progress</label></div>
			<div class="col-md-10">
				<div class="progress">
					<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="min-width: 2em; width: 2%;">
						<span id="lbl_progress">0 %</span>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-2"><label>Error Status</label></div>
			<div class="col-md-10"><span id="error_status">...</span></div>
		</div>
	  
	  </div>
</div>
<div id="hasil_pencarian"></div>

<script type="text/javascript">
$(document).ready(function(){
	//$('#panel_info').hide();

	$('.number_only').on('input', function (event) { 
		this.value = this.value.replace(/[^0-9.]/ig, '');
	});

	
	$('.multiselect').multiselect({
      buttonWidth: '100%',
      maxHeight: 300,
      includeSelectAllOption: true,
	  enableFiltering: true,
	  enableCaseInsensitiveFiltering:true
    });


    $("#fa_pernr").autocomplete({
		source: '<?=site_url("template/autocomp_pekerja");?>',
		minLength: 2,
		select: function(event,ui){
            var str_val = ui.item.value
            var arr_val = str_val.split('/');
            var pa      = arr_val[0] != 'undefined' ? arr_val[0]+'\r\n' : '';
            $('#f_pernr').val($('#f_pernr').val()+pa);
            return false;
        	},
        close: function(event, ui){
            $(this).val('');
        	}
	});


	$("#fa_pa").autocomplete({
		source: '<?=site_url("template/autocomp_pa");?>',
		minLength: 2,
		select: function(event,ui){
            var str_val = ui.item.value
            var arr_val = str_val.split('/');
            var pa      = arr_val[0] != 'undefined' ? arr_val[0]+'\r\n' : '';
            $('#f_pa').val($('#f_pa').val()+pa);
            return false;
        	},
        close: function(event, ui){
            $(this).val('');
        	}
	});


	$("#fa_psa").autocomplete({
		source: '<?=site_url("template/autocomp_psa");?>',
		minLength: 2,
		select: function(event,ui){
            var str_val = ui.item.value
            var arr_val = str_val.split('/');
            var pa      = arr_val[0] != 'undefined' ? arr_val[0]+'\r\n' : '';
            $('#f_psa').val($('#f_psa').val()+pa);
            return false;
        	},
        close: function(event, ui){
            $(this).val('');
        	}
	});


	$("#fa_histori_jabatan").autocomplete({
		source: '<?=site_url("template/autocomp_histori_jabatan");?>',
		minLength: 2,
		select: function(event,ui){
            var str_val = ui.item.value
            var history_jabatan     = str_val+'\r\n';
            $('#f_histori_jabatan').val($('#f_histori_jabatan').val()+history_jabatan);
            return false;
        	},
        close: function(event, ui){
            $(this).val('');
        	}
	});


	$("#fa_histori_uker").autocomplete({
		source: '<?=site_url("template/autocomp_histori_uker");?>',
		minLength: 2,
		select: function(event,ui){
            var str_val = ui.item.value
            var history_uker     = str_val+'\r\n';
            $('#f_histori_uker').val($('#f_histori_uker').val()+history_uker);
            return false;
        	},
        close: function(event, ui){
            $(this).val('');
        	}
	});


	/*$("#f_training").autocomplete({
		source: '<?=site_url("template/autocomp_training");?>',
		minLength: 2
	});*/


	$("#fa_jurusan").autocomplete({
		source: '<?=site_url("template/autocomp_jurusan");?>',
		minLength: 2,
		select: function(event,ui){
            var str_val = ui.item.value
            var arr_val = str_val.split('/');
            var pa      = arr_val[0] != 'undefined' ? arr_val[0]+'\r\n' : '';
            $('#f_jurusan').val($('#f_jurusan').val()+pa);
            return false;
        	},
        close: function(event, ui){
            $(this).val('');
        	}
	});


	$("#fa_universitas").autocomplete({
		source: '<?=site_url("template/autocomp_universitas");?>',
		minLength: 2,
		select: function(event,ui){
            var str_val = ui.item.value
            $('#f_universitas').val($('#f_universitas').val()+str_val+'\r\n');
            return false;
        	},
        close: function(event, ui){
            $(this).val('');
        	}
	});



	$('#simpan').click(function(){
		$.ajax({
			type 		: 'POST',
			url 		: '<?=site_url('template/validasi_template');?>',
			data 		: $('#form_filter_template').serialize(),
			dataType 	: 'HTML',
			beforeSend 	: function(){$('#ajax-loader').show();},
			error 		: function(){$('#ajax-loader').hide(); alert('ERROR !!!');},
			success 	: function(result){$('#ajax-loader').hide();
				//$('#modal_content').html(result);
				//$('#template_modal').modal('show');
				$('#general_popup .modal-dialog').removeClass('modal-lg modal-md modal-sm').addClass('modal-md');
				$('#general_popup .modal-dialog .modal-content').html(result);
				$('#general_popup').modal({'backdrop':'static'});
				}
			});
	});
	
	$('#cari').click(function(e){
		if(confirm('Apakah anda yakin?'))
			{
			$('#hasil_pencarian').empty();
			$.ajax({
				type 		: 'POST',
				url 		: '<?=site_url('template/proses_pencarian_go');?>',
				data 		: 'mt=1&' + $("#form_filter_template").serialize(),
				dataType 	: 'JSON',
				beforeSend 	: function(){$('#ajax-loader').show();},
				error 		: function(){$('#ajax-loader').hide(); alert('ERROR !!!');},
				success 	: function(result){
					$('#ajax-loader').hide();
					if(result.error_log != '1'){
						$('#panel_info').show();
						$('#start_process').text(result.start_process);
						$('#lbl_progress').text(result.prosentase+' %');
						$('.progress-bar').css('width',result.prosentase+'%');
						$('#progress_status').text(result.progress_text);
						$('#error_status').text(result.error_log);

						if(result.prosentase!=100 && result.error_log=='')
							{
							var id_template = 0;
							progress_refresh(id_template);
							}
						if(result.prosentase==100)
							{
							$('#elapse_time').text(result.elapse_time);
							setTimeout(show_hasil_pencarian, 800);
							}
					}
					else{
						alert(result.error_msg);
					}
				}
			});
			}
		e.preventDefault();
	});
	function progress_refresh(id_template)
	{
	$.ajax({
			type 		: 'POST',
			url 		: '<?=site_url('template/pencarian_progress_refresh');?>',
			data 		: 'mt=1&id_template='+id_template,
			dataType 	: 'JSON',
			beforeSend 	: function(){},
			error 		: function(){alert('ERROR !!!');},
			success 	: function(result){
				$('#start_process').text(result.start_process);
				$('#lbl_progress').text(result.prosentase+' %');
				$('.progress-bar').css('width',result.prosentase+'%');
				$('#progress_status').text(result.progress_text);
				$('#error_status').text(result.error_log);

				if(result.prosentase!=100 && result.error_log=='')
					{
					progress_refresh(id_template);
					}
				if(result.prosentase==100)
					{
					$('#elapse_time').text(result.elapse_time);
					setTimeout(show_hasil_pencarian, 800);
					}
			}
		});
	}



	function show_hasil_pencarian()
	{
		$.ajax({
			type 		: 'POST',
			url 		: '<?=site_url('template/show_hasil_pencarian');?>',
			data 		: '',
			dataType 	: 'HTML',
			beforeSend 	: function(){$('#ajax-loader').show();},
			error 		: function(){$('#ajax-loader').hide(); alert('ERROR !!!');},
			success 	: function(result){$('#ajax-loader').hide();
				$('#hasil_pencarian').html(result);
			}
		});
	}
});
</script>
