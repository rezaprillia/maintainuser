<style type="text/css">
.thblue{
	background-color: #337ab7;
	color: #FFFFFF;
	text-align: center;
}
.linkdetail{
	color:blue;
	text-decoration:underline;
	cursor:pointer;
}
</style>
<br>
<h3 class="maintitle"><i class="fa fa-users"></i> <span> Hasil Pencarian Pekerja</span></h3>
<div class="row navi_btn" style="padding-bottom:10px;">
	<div class="col-md-12 text-right">
		<a href="<?=site_url('template/create_csv_hasil_pencarian');?>" target="_blank" style="text-decoration:none; cursor:pointer;"  class="btn btn-sm btn-success" title="Klik di sini untuk export CSV." style="color:#022969;"><i class="fa fa-send"></i> Export CSV</a>
	</div>
</div>
<?=form_open('template/show_hasil_pencarian','id="form_page_hasil_pencarian"');?>
	<input type="hidden" id="id_template" name="id_template" value="<?=$id_template;?>">
	<div class="row">
		<div class="col-md-3">
			Urutkan PERNR
			<?=form_dropdown('f_sort_pernr',array('' => '- Sort By PERNR -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_pernr'),'id="f_sort_pernr" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan Jabatan
			<?=form_dropdown('f_sort_jabatan',array('' => '- Sort By Jabatan -','1'=>'A ke Z','2' => 'Z ke A'),$this->input->post('f_sort_jabatan'),'id="f_sort_jabatan" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan JG
			<?=form_dropdown('f_sort_jg',array('' => '- Sort By JG -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_jg'),'id="f_sort_jg" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan PG
			<?=form_dropdown('f_sort_pg',array('' => '- Sort By PG -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_pg'),'id="f_sort_pg" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan Usia
			<?=form_dropdown('f_sort_usia',array('' => '- Sort By Usia -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_usia'),'id="f_sort_usia" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan MKE
			<?=form_dropdown('f_sort_mke',array('' => '- Sort By MKE -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_mke'),'id="f_sort_mke" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan MKJ
			<?=form_dropdown('f_sort_mkj',array('' => '- Sort By MKJ -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_mkj'),'id="f_sort_mkj" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan MKJG
			<?=form_dropdown('f_sort_mkjg',array('' => '- Sort By MKJG -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_mkjg'),'id="f_sort_mkjg" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan MKPG
			<?=form_dropdown('f_sort_mkpg',array('' => '- Sort By MKPG -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_mkpg'),'id="f_sort_mkpg" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan MKU
			<?=form_dropdown('f_sort_mku',array('' => '- Sort By MKU -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_mku'),'id="f_sort_mku" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan IPK
			<?=form_dropdown('f_sort_ipk',array('' => '- Sort By IPK -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_ipk'),'id="f_sort_ipk" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan ITP
			<?=form_dropdown('f_sort_itp',array('' => '- Sort By ITP -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_itp'),'id="f_sort_itp" class="form-control input-sm filter"');?>
		</div>
	</div>
	<div class="row">
		<div class="col-md-3">
			Urutkan SMK
			<?=form_dropdown('f_sort_smk',array('' => '- Sort By SMK -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_smk'),'id="f_sort_smk" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan SKO
			<?=form_dropdown('f_sort_sko',array('' => '- Sort By SKO -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_sko'),'id="f_sort_sko" class="form-control input-sm filter"');?>
		</div>
		<div class="col-md-3">
			Urutkan SKK
			<?=form_dropdown('f_sort_skk',array('' => '- Sort By SKK -','1'=>'Tinggi ke Rendah','2' => 'Rendah ke Tinggi'),$this->input->post('f_sort_skk'),'id="f_sort_skk" class="form-control input-sm filter"');?>
		</div>
		<!-- <div class="col-md-3">
			Rekomendasi / Hasil Assessment : <?=form_dropdown('f_rekomendasi_asesmen[]',isset($opt_rekomendasi_asesmen)?$opt_rekomendasi_asesmen: array(''=> '- Pilih Rekomendasi Assessment -'),$this->input->post('f_rekomendasi_asesmen'),'id="f_rekomendasi_asesmen" class="multiselect f_hasil_asm" multiple="multiple"');?>
		</div> -->
	</div>
	<br>
	<div class="row" align="right">
		<div class="col-md-12">
			<button class="btn btn-theme btn-sm" name="show" id="show" value="Cari" type="submit" title="Klik di sini untuk mencari data."><i class="fa fa-search"></i> Cari</button>
			<button class="btn btn-warning btn-sm" name="show_all" id="show_all" value="Semua" type="submit" title="Klik di sini untuk menampilkan semua data."><i class="fa fa-search-plus"></i> Semua</button>
		</div>
	</div>
<?=form_close();?>
<br>
<div style="overflow-x: scroll;">
<table width="100%" class="table table-hover table-bordered">
		<tr>
			<th class="thblue">No</th>
			<th class="thblue">PERNR / NIP</th>
			<th class="thblue">NAME</th>
			<th class="thblue">JK</th>
			<th class="thblue">TTL</th>
			<th class="thblue">USIA</th>
			<th class="thblue">AGAMA</th>
			<th class="thblue">TGL MASUK BRI</th>
			<th class="thblue">PROGRAM MASUK</th>
			<th class="thblue">JABATAN</th>
			<th class="thblue">KELOMPOK JABATAN</th>
			<th class="thblue">JG/PG</th>
			<th class="thblue">STATUS PEKERJA</th>
			<th class="thblue">PSA</th>
			<th class="thblue">PA</th>
			<th class="thblue">TMT PT/PS</th>
			<th class="thblue">MKE</th>
			<th class="thblue">MKJ</th>
			<th class="thblue">MKPG</th>
			<th class="thblue">MKJG</th>
			<th class="thblue">MKU</th>
			<th class="thblue">SMK LAST</th>
			<th class="thblue">SKO LAST</th>
			<th class="thblue">SKK LAST</th>
			<!-- <th class="thblue">REKOMENDASI LAST</th> -->
			<th class="thblue">IPK LAST</th>
			<th class="thblue">ITP LAST</th>
		</tr>
		<?php if(isset($hasil_pencarian)):?>
			<?php if(!empty($hasil_pencarian)):?>
				<?php foreach($hasil_pencarian as $row):?>
					<?php $cell = $no%2==0 ? 'warning' : ''?>
					<tr>
						<td align="center" class="<?=$cell;?>"><?=isset($no)?$no:'';?></td>
						<td align="center" class="<?=$cell;?>"><span class="linkdetail" id="PERNR=<?=isset($row->PERNR)?$row->PERNR:'';?>"><?=isset($row->PERNR)?$row->PERNR:'';?> / <?=isset($row->NIP)?$row->NIP:'';?></span></td>
						<td class="<?=$cell;?>"><?=isset($row->SNAME)?$row->SNAME:'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->SNAME)? ($row->JK == 'L' ? 'Laki-laki' : 'Perempuan'):'';?></td>
						<td class="<?=$cell;?>"><?=isset($row->TEMPATLAHIR)?$row->TEMPATLAHIR:'';?>, <?=isset($row->TANGGALLAHIR)?$this->libs->ymdhis2dmonthy($row->TANGGALLAHIR):'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->TANGGALLAHIR)?$this->libs->get_age($row->TANGGALLAHIR):'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->AGAMA)?$row->AGAMA:'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->TMT_MASUK)?$this->libs->ymdhis2dmonthy($row->TMT_MASUK):'';?></td>
						<td class="<?=$cell;?>"><?=isset($row->PROGRAM_MASUK)?$row->PROGRAM_MASUK:'';?></td>
						<td class="<?=$cell;?>"><?=isset($row->STELL_TX)?$row->STELL_TX:'';?></td>
						<td class="<?=$cell;?>"><?=isset($row->HTEXT)?$row->HTEXT:'';?></td>
						<td class="<?=$cell;?>"><?=isset($row->JGPG)?$row->JGPG:'';?></td>
						<td class="<?=$cell;?>"><?=isset($row->STATUS)?$row->STATUS:'';?></td>
						<td class="<?=$cell;?>"><?=isset($row->WERKS_TX)?$row->WERKS_TX:'';?></td>
						<td class="<?=$cell;?>"><?=isset($row->BTRTL_TX)?$row->BTRTL_TX:'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->TMT_PT)?$this->libs->ymdhis2dmonthy($row->TMT_PT):'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->MK_MKE)?$row->MK_MKE:'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->MK_MKJ)?$row->MK_MKJ:'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->MK_MKPG)?$row->MK_MKPG:'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->MK_MKJG)?$row->MK_MKJG:'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->MK_MKU)?$row->MK_MKU:'';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->nilai_smk_last)?$row->nilai_smk_last:'-';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->nilai_sko_last)?$row->nilai_sko_last:'-';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->nilai_skk_last)?$row->nilai_skk_last:'-';?></td>
						<!-- <td align="center" class="<?=$cell;?>"><?=isset($row->rekomendasi_last)?$row->rekomendasi_last:'-';?></td> -->
						<td align="center" class="<?=$cell;?>"><?=isset($row->ipk_last)?$row->ipk_last:'-';?></td>
						<td align="center" class="<?=$cell;?>"><?=isset($row->itp_last)?$row->itp_last:'-';?></td>
					</tr>
				<?php $no++;?>
				<?php endforeach;?>
			<?php else:?>
				<tr>
					<td colspan="20" align="center">Tidak ada data</td>
				</tr>
			<?php endif;?>
		<?php else:?>
			<tr>
				<td colspan="20" align="center">Tidak ada data</td>
			</tr>
		<?php endif;?>
	</table>
</div>
<table width="100%" >
	<tr>
		<td width="50%"><?php echo isset($paging) ? '<ul class="center-block" style="display:inline-block; padding:0px 0px 0px 0px !important;">'.$paging.'</ul>' : ''; ?></td>
		<!-- <td width="50%" align="right"><button class="btn btn-sm btn-primary" name="simpan_hasil" id="simpan_hasil" value="simpan_hasil" type="button" title="Klik di sini untuk menyimpan."><i class="fa fa-save"></i> Simpan Hasil Pencarian</button></td> -->
	</tr>
</table>

<div id="form_simpan_pencarian"></div>

<script type="text/javascript">
$(document).ready(function(){

	$('#show_all').off().click(function(e){
		$('.filter').val('');
	});
	
	$('.f_hasil_asm').multiselect({
      buttonWidth: '100%',
      maxHeight: 300,
      includeSelectAllOption: true
    });
	
	$('#form_page_hasil_pencarian').off().submit(function(e){
		$.ajax({
			type 		: 'POST',
			url 		: '<?=site_url('template/show_hasil_pencarian');?>',
			data 		: $('#form_page_hasil_pencarian').serialize(),
			dataType 	: 'HTML',
			beforeSend 	: function(){$('#ajax-loader').show();},
			error 		: function(){$('#ajax-loader').hide(); alert('ERROR !!!');},
			success 	: function(result){
				$('#ajax-loader').hide();
				$('#hasil_pencarian').html(result);
			}
		});
		e.preventDefault();
	});
	
	$('.page').click(function(){
		$.ajax({
			type 		: 'post',
			url 		: $(this).find('a:first').attr('href'),
			data 		: $('#form_page_hasil_pencarian').serialize(),
			dataType	: 'HTML',
			beforeSend	: function(){$('#ajax-loader').show();},
			error 		: function(){$('#ajax-loader').hide();alert('ERROR !!!');},
			success		: function(result){$('#ajax-loader').hide();
				$('#hasil_pencarian').html(result);
			}
		});
		return false;
	});
	
	$(".linkdetail").off().click(function(e){
		var id = $(this).attr('id');
		$(this).myAjax({
			url : '<?=site_url('hasil/detail_pekerja')?>',
			data: 'mt=1&'+id+'&is_go=1&id_template=0',
			success: function(data){
				$('#general_popup .modal-dialog').removeClass('modal-lg modal-md modal-sm').addClass('modal-lg');
				$('#general_popup .modal-dialog .modal-content').html(data);
				$('#general_popup').modal({'backdrop':'static'});
				/*$('#general_popup').on('hide.bs.modal', function (e) {
					$(this).myAjax({
						url : $('#form_data').attr('action'),
						data: 'mt=1&'+$('#form_data').serialize(),
						success: function(data){
							$('#result').html(data);
							$('#ajax-loader').hide();
						}
					});
				});*/
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});


	$('#simpan_hasil').click(function(){
		var id_template = $('#id_template').val();
		//console.log(id_template);
		if(typeof  id_template != 'undefined' && id_template != '0' && id_template != ''){
			$.ajax({
				type 		: 'post',
				url 		: '<?=site_url('template/load_form_simpan_hasil_pencarian');?>',
				data 		: '',
				dataType	: 'HTML',
				beforeSend	: function(){$('#ajax-loader').show();},
				error 		: function(){$('#ajax-loader').hide();alert('ERROR !!!');},
				success		: function(result){$('#ajax-loader').hide();
					$('#form_simpan_pencarian').html(result);
				}
			});
		}
		else{
			$.ajax({
				type 		: 'post',
				url 		: '<?=site_url('template/load_form_simpan_non_template');?>',
				data 		: '',
				dataType	: 'HTML',
				beforeSend	: function(){$('#ajax-loader').show();},
				error 		: function(){$('#ajax-loader').hide();alert('ERROR !!!');},
				success		: function(result){$('#ajax-loader').hide();
					$('#form_simpan_pencarian').html(result);
				}
			});
		}
	});

});
</script>
