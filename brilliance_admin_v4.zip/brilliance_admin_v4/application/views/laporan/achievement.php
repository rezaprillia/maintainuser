<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<?php
	echo isset($message)?$message:'';
	if(isset($_SESSION[$this->config->item('session_prefix')]['message'])){
		echo $_SESSION[$this->config->item('session_prefix')]['message'];
		unset($_SESSION[$this->config->item('session_prefix')]['message']);
	}
?>
<style>
.orgchart { background: #fff; }
.orgchart .node .horizontalEdge { display: none; }
</style>
<?=form_open('laporan/achievement/false','id="form_data"')?>
<?=isset($filter)?form_hidden($filter):''?>
<div class="panel panel-primary" id="penghargaan">
	<div class="panel-heading"><h3 class="panel-title">Penghargaan (Internal/Eksternal)</h3></div>
	<table align="center" width="100%" cellpadding="3px" cellspacing="0px" class="table-theme responsive-general-table" border="0">
		<thead>
			<tr>
				<th width="5%" align="center">No</th>
				<th width="10%" align="center">Pernr / Nama</th>
				<th width="10%" align="center">Personnal Area</th>
				<th width="10%" align="center">Personnal Sub Area</th>
				<th width="10%" align="center">Jenis Penghargaan</th>
				<th width="10%" align="center">Tingkat</th>
				<th width="10%" align="center">Diberikan Oleh</th>
				<th width="10%" align="center">Tahun</th>
			</tr>
		</thead>
			<?php 
			if(isset($achievement)){
				if(count($achievement)>0){
			?>
		<tbody>
			<?php
					foreach($achievement as $row){
			?>
				<tr>
					<td align="center" data-title="No"><?=$no?>.</td>
					<td align="center" data-title="PN"><?=isset($row->PERNR)?$row->PERNR:'-'?> / <?=isset($row->Nama)?$row->Nama:'-'?></td>
					<td align="left" data-title="PA"><?=isset($row->pa)?$row->pa:'-'?></td>
					<td align="left" data-title="PSA"><?=isset($row->psa)?$row->psa:'-'?></td>
					<td align="left" data-title="PENGHARGAAN"><?=isset($row->PENGHARGAAN)?$row->PENGHARGAAN:'-'?></td>
					<td align="center" data-title="TINGKAT"><?=isset($row->TINGKAT)?$row->TINGKAT:'-'?></td>
					<td align="left" data-title="PEMBERI"><?=isset($row->PEMBERI)?$row->PEMBERI:'-'?></td>
					<td align="left" data-title="TAHUN"><?=isset($row->TAHUN)?$row->TAHUN:'-'?></td>
				</tr>
			<?php
						$no++;
					}
			?>
			</tbody>
			<tfoot>
				<tr>
					<th align="left" colspan="16">Jumlah Data : <?php echo isset($jml_data)?$jml_data:'';?> Records</th>
				</tr>
				<tr>
					<th align="left" colspan="16">Jumlah Halaman : <?php echo isset($jml_hal)?$jml_hal:'';?> Halaman</th>
				</tr>
				<?php
						if($jml_hal>1){
				?>
				<tr>
					<td align="left" colspan="16" id="row-pagging"><?php echo isset($paging)?$paging:'';?></td>
				</tr>
				<?php
						}
				?>
			</tfoot>
			<?php
				}else{
			?>
		<tfoot>
			<tr>
				<th colspan="16">
					<div class="alert alert-danger message" role="alert">- Data tidak ditemukan -</div>
				</th>
			</tr>
		</tfoot>
			<?php
				}
			}
			?>
	</table>
	<div id="tools" class="col-sm-12" style="text-align:right; padding-top: 5px;">
		<button class="btn btn-success btn-sm download_detail_excel_achievement" id="download_detail_excel_achievement" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>
	</div>
	</div>
	</form>
	</div>
</div>

<script>
$(document).ready(function(){
	$('.download_detail_excel_achievement').click(function() {
		location.href = "<?= site_url('laporan/achievement_excel'); ?>?" + $('#form_data').serialize();
		return false;
	});

	$("#row-pagging a:not('.active')").off().click(function(e){
		$(this).myAjax({
			url : $(this).attr('href'),
			data: 'mt=1&'+$('#form_data').serialize(),
			success: function(data){
				$('#result1').html(data);
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});
});
</script>