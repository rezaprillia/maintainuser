<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<?php
	echo isset($message)?$message:'';
	if(isset($_SESSION[$this->config->item('session_prefix')]['message'])){
		echo $_SESSION[$this->config->item('session_prefix')]['message'];
		unset($_SESSION[$this->config->item('session_prefix')]['message']);
	}
?>
<style>
.orgchart { background: #fff; }
.orgchart .node .horizontalEdge { display: none; }
</style>
<?=form_open('laporan/karya_tulis/false','id="form_data"')?>
<?=isset($filter)?form_hidden($filter):''?>
<div class="panel panel-primary" id="publikasi">
	<div class="panel-heading"><h3 class="panel-title">Publikasi (Dalam 5 tahun terakhir)</h3></div>
	<table align="center" width="100%" cellpadding="3px" cellspacing="0px" class="table-theme responsive-general-table" border="0">
		<thead>
			<tr>
				<th width="5%" align="center">No</th>
				<th width="10%" align="center">Pernr / Nama</th>
				<th width="10%" align="center">Personnal Area</th>
				<th width="10%" align="center">Personnal Sub Area</th>
				<th width="10%" align="center">Judul</th>
				<th width="10%" align="center">Media Publikasi</th>
				<th width="10%" align="center">Tahun</th>
			</tr>
		</thead>
			<?php 
			if(isset($karya_tulis)){
				if(count($karya_tulis)>0){
			?>
		<tbody>
			<?php
					foreach($karya_tulis as $row){
			?>
				<tr>
					<td align="center" data-title="No"><?=$no?>.</td>
					<td align="center" data-title="PN"><?=isset($row->PERNR)?$row->PERNR:'-'?> / <?=isset($row->Nama)?$row->Nama:'-'?></td>
					<td align="left" data-title="PA"><?=isset($row->pa)?$row->pa:'-'?></td>
					<td align="left" data-title="PSA"><?=isset($row->psa)?$row->psa:'-'?></td>
					<td align="left" data-title="JUDUL"><?=isset($row->JUDUL)?$row->JUDUL:'-'?></td>
					<td align="center" data-title="MEDIA_PUBLIKASI"><?=isset($row->MEDIA_PUBLIKASI)?$row->MEDIA_PUBLIKASI:'-'?></td>
					<td align="left" data-title="TAHUN"><?=isset($row->TAHUN)?$row->TAHUN:'-'?></td>
				</tr>
			<?php
						$no++;
					}
			?>
			</tbody>
			<tfoot>
				<tr>
					<th align="left" colspan="16">Jumlah Data : <?php echo isset($jml_data)?$jml_data:'';?> Records</th>
				</tr>
				<tr>
					<th align="left" colspan="16">Jumlah Halaman : <?php echo isset($jml_hal)?$jml_hal:'';?> Halaman</th>
				</tr>
				<?php
						if($jml_hal>1){
				?>
				<tr>
					<td align="left" colspan="16" id="row-pagging"><?php echo isset($paging)?$paging:'';?></td>
				</tr>
				<?php
						}
				?>
			</tfoot>
			<?php
				}else{
			?>
		<tfoot>
			<tr>
				<th colspan="16">
					<div class="alert alert-danger message" role="alert">- Data tidak ditemukan -</div>
				</th>
			</tr>
		</tfoot>
			<?php
				}
			}
			?>
	</table>
	<div id="tools" class="col-sm-12" style="text-align:right; padding-top: 5px;">
		<button class="btn btn-success btn-sm download_detail_excel_karya_tulis" id="download_detail_excel_karya_tulis" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>
	</div>
	</form>
	</div>
</div>

<script>
$(document).ready(function(){

	$('.download_detail_excel_karya_tulis').click(function() {
		location.href = "<?= site_url('laporan/karya_tulis_excel'); ?>?" + $('#form_data').serialize();
		return false;
	});

	$("#row-pagging a:not('.active')").off().click(function(e){
		$(this).myAjax({
			url : $(this).attr('href'),
			data: 'mt=1&'+$('#form_data').serialize(),
			success: function(data){
				$('#result2').html(data);
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});
});
</script>