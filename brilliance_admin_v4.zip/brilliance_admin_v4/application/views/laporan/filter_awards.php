<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<h3 class="maintitle"><i class="fa fa-rocket"></i> <span> Dashboard Awards Pekerja</span></h3>
<?=isset($breadcrum)?$breadcrum:'';?>
<?=isset($message) ? $message : '';?>
<?php
	//echo sha1(md5('P4ssf0rBRIll1anc3'));
?>
<div class="panel panel-primary" style="margin-bottom:10px;">
  <div class="panel-heading"><h3 class="panel-title">Pencarian</h3></div>
  <div class="panel-body" style="padding:3px;">
	<?=form_open('laporan/achievement/false','id="form_filter"')?>
	<table align="center" width="100%" cellpadding="3px" cellspacing="0px" class="table-responsive-topdown" border="0" style="border-collapse:collapse;">
	<tr>
			<th align="left" width="180px">Jenis Awards</th>
			<th align="center" width="10px">:</th>
			<td align="left" class="td-responsive">
				<div class="row row-cell">
					<div class="col-sm-12 title">Awards:</div>
					<div class="col-sm-12 value"><?=form_dropdown('f_jenis_awards',(isset($arrPilAwards)?$arrPilAwards:array(''=>'- Pilih Jenis Awards -')),($this->input->post('f_jenis_awards')!=FALSE?$this->input->post('f_jenis_awards'):''),'id="f_jenis_awards" class="form-control filter" title="Pilih jenis awards di sini." rel="Jenis Awards" style="width:40%;"')?></div>
				</div>
			</td>
		</tr>
		<tr>
		<tr>
			<th align="left" width="180px">Keyword</th>
			<th align="center" width="10px">:</th>
			<td align="left" class="td-responsive">
				<div class="row row-cell">
					<div class="col-sm-12 title">Keyword :</div>
					<div class="col-sm-12 value"><?=form_input(array('name'=>'f_keyword','id'=>'f_keyword','class'=>'form-control filter input-sm trim','placeholder'=>'Masukkan kata kunci di sini.','autocomplete'=>'off','title'=>'Ketik kata kunci di sini.','rel'=>'Kata Kunci'));?></div>
				</div>
			</td>
		</tr>
		<tr>
			<th align="left" width="180px">&nbsp;</th>
			<th align="center" width="10px">&nbsp;</th>
			<td align="left" class="td-responsive">
				<div class="row row-cell">
					<div class="col-sm-12">
						<button class="btn btn-theme" name="show" id="show" value="Cari" type="submit" title="Klik di sini untuk mencari data."><i class="fa fa-search"></i> Cari</button>
						<button class="btn btn-warning" name="show_all" id="show_all" value="Semua" type="submit" title="Klik di sini untuk menampilkan semua data."><i class="fa fa-search-plus"></i> Semua</button>
					</div>
				</div>
			</td>
		</tr>
	</table>
	</form>
  </div>
</div>
<div class="panel panel-primary" id="narasumber">
	<!-- <div class="panel-heading"><h3 class="panel-title">Narasumber</h3></div> -->
  <div class="panel-body row" style="padding:3px;">
	<!-- <div id="tools" class="col-sm-12" style="text-align:right;">
	<button class="btn btn-success btn-sm" id="download_detail_excel_narasumber" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>
	</div> -->
	<div id="result" class="col-sm-12" style="margin-top:3px;"><?=isset($result)?$result:'';?></div>
  </div>
</div>

<div class="panel panel-primary" id="penghargaan">
	<!-- <div class="panel-heading"><h3 class="panel-title">Penghargaan (Internal/Eksternal)</h3></div> -->
  <div class="panel-body row" style="padding:3px;">
	<!-- <div id="tools" class="col-sm-12" style="text-align:right;">
	<button class="btn btn-success btn-sm" id="download_detail_excel_achievement" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>
	</div> -->
	<div id="result1" class="col-sm-12" style="margin-top:3px;"><?=isset($result1)?$result1:'';?></div>
  </div>
</div>

<div class="panel panel-primary" id="publikasi">
	<!-- <div class="panel-heading"><h3 class="panel-title">Publikasi (Dalam 5 tahun terakhir)</h3></div> -->
  <div class="panel-body row" style="padding:3px;">
	<!-- <div id="tools" class="col-sm-12" style="text-align:right;">
	<button class="btn btn-success btn-sm" id="download_detail_excel_karya_tulis" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>
	</div> -->
	<div id="result2" class="col-sm-12" style="margin-top:3px;"><?=isset($result2)?$result2:'';?></div>
  </div>
</div>

<div class="panel panel-primary" id="organisasi">
	<!-- <div class="panel-heading"><h3 class="panel-title">Keanggotaan Organisasi Profesi/Komunitas yang Diikuti</h3></div> -->
  <div class="panel-body row" style="padding:3px;">
	<!-- <div id="tools" class="col-sm-12" style="text-align:right;">
	<button class="btn btn-success btn-sm" id="download_detail_excel_organisasi" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>
	</div> -->
	<div id="result3" class="col-sm-12" style="margin-top:3px;"><?=isset($result3)?$result3:'';?></div>
  </div>
</div>

<!-- <div class="panel panel-primary" id="hasil1">
	<div class="panel-heading"><h3 class="panel-title">Penghargaan (Internal/Eksternal)</h3></div>
  <div class="panel-body row" style="padding:3px;">
	<div id="tools" class="col-sm-12" style="text-align:right;">
	<button class="btn btn-success btn-sm" id="download_detail_excel_achievement" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>
	</div>
	<div id="hasil1" class="col-sm-12" style="margin-top:3px;"></div>
  </div>
</div> -->

	<div id="hasil" class="col-sm-12" style="margin-top:3px;"></div>
	<div id="hasil1" class="col-sm-12" style="margin-top:3px;"></div>
	<div id="hasil2" class="col-sm-12" style="margin-top:3px;"></div>
	<div id="hasil3" class="col-sm-12" style="margin-top:3px;"></div>
	<div id="hasil4" class="col-sm-12" style="margin-top:3px;"></div>

</div>

<script>
$(document).ready(function(){
	var filter_selected = $('#f_jenis_awards').find(":selected").text();

	$('#show_all').off().click(function(e){
		$('.filter').val('');
		$('#hasil1').show();
		$('#hasil2').show();
		$('#hasil3').show();
		$('#hasil4').show();
		//location.href = "<?php site_url();?>laporan/filter_awards";
		// return false;
	});

	$('#form_filter').submit(function(e){
		//console.log(document.getElementById("f_jenis_awards").value);
		var jenis_awards = document.getElementById("f_jenis_awards").value;
		if(jenis_awards == "PENGHARGAAN"){
			console.log(jenis_awards);
			$(this).myAjax({
				//url : $(this).attr('action'),
				url :"<?php echo site_url();?>laporan/achievement/false",
				data: 'mt=1&'+$(this).serialize(),
				beforeSend:function(){
					$('#organisasi').hide();
					$('#narasumber').hide();
					$('#publikasi').hide();
					$('#penghargaan').hide();
					$('#hasil').hide();
					$('#hasil1').hide();
					$('#hasil2').hide();
					$('#hasil3').hide();
					$('#hasil4').hide();
				},
				success: function(data){
					$('#hasil').html(data);
					$('#hasil').show();
					$('#ajax-loader').hide();
					// document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		else if(jenis_awards == "NARASUMBER"){
			console.log(jenis_awards);
			$(this).myAjax({
				//url : $(this).attr('action'),
				url :"<?php echo site_url();?>laporan/narasumber/false",
				data: 'mt=1&'+$(this).serialize(),
				beforeSend:function(){
					$('#organisasi').hide();
					$('#narasumber').hide();
					$('#publikasi').hide();
					$('#penghargaan').hide();
					$('#hasil').hide();
					$('#hasil1').hide();
					$('#hasil2').hide();
					$('#hasil3').hide();
					$('#hasil4').hide();
				},
				success: function(data){
					$('#hasil').html(data);
					$('#hasil').show();
					$('#ajax-loader').hide();
					// document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		else if(jenis_awards == "ORGANISASI"){
				console.log(jenis_awards);
				$(this).myAjax({
				//url : $(this).attr('action'),
				url :"<?php echo site_url();?>laporan/organisasi/false",
				data: 'mt=1&'+$(this).serialize(),
				beforeSend:function(){
					$('#organisasi').hide();
					$('#narasumber').hide();
					$('#publikasi').hide();
					$('#penghargaan').hide();
					$('#hasil').hide();
					$('#hasil1').hide();
					$('#hasil2').hide();
					$('#hasil3').hide();
					$('#hasil4').hide();
				},
				success: function(data){
					$('#hasil').html(data);
					$('#hasil').show();
					$('#ajax-loader').hide();
					// document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		else if(jenis_awards == "PUBLIKASI"){
				console.log(jenis_awards);
				$(this).myAjax({
				url :"<?php echo site_url();?>laporan/karya_tulis/false",
				data: 'mt=1&'+$(this).serialize(),
				beforeSend:function(){
					$('#organisasi').hide();
					$('#narasumber').hide();
					$('#publikasi').hide();
					$('#penghargaan').hide();
					$('#hasil').hide();
					$('#hasil1').hide();
					$('#hasil2').hide();
					$('#hasil3').hide();
					$('#hasil4').hide();
				},
				success: function(data){
					$('#hasil').html(data);
					$('#hasil').show();
					$('#ajax-loader').hide();
					// document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		else{
			console.log('lain');
			console.log(jenis_awards);
			$(this).myAjax({
				//url : $(this).attr('action'),
				url :"<?php echo site_url();?>laporan/achievement/false",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#penghargaan').hide();
					$('#narasumber').hide();
					$('#organisasi').hide();
					$('#publikasi').hide();
					$('#hasil').hide();
					$('#hasil1').html(data);
					console.log(data);
					$('#ajax-loader').hide();
					// document.getElementById("f_jenis_awards").reset();
				}
			});

			$(this).myAjax({
				//url : $(this).attr('action'),
				url :"<?php echo site_url();?>laporan/narasumber/false",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#penghargaan').hide();
					$('#narasumber').hide();
					$('#organisasi').hide();
					$('#publikasi').hide();
					$('#hasil').hide();
					$('#hasil2').html(data);
					$('#ajax-loader').hide();
					// document.getElementById("f_jenis_awards").reset();
				}
			});

			$(this).myAjax({
				url :"<?php echo site_url();?>laporan/karya_tulis/false",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#penghargaan').hide();
					$('#narasumber').hide();
					$('#organisasi').hide();
					$('#publikasi').hide();
					$('#hasil').hide();
					$('#hasil3').html(data);
					$('#ajax-loader').hide();
					// document.getElementById("f_jenis_awards").reset();
				}
			});

			$(this).myAjax({
				url :"<?php echo site_url();?>laporan/organisasi/false",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#penghargaan').hide();
					$('#narasumber').hide();
					$('#organisasi').hide();
					$('#publikasi').hide();
					$('#hasil').hide();
					$('#hasil4').html(data);
					$('#ajax-loader').hide();
					// document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		console.log(jenis_awards);
		e.preventDefault();
	});
});
</script>