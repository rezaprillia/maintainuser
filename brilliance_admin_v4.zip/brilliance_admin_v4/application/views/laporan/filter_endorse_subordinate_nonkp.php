<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<h3 class="maintitle"><i class="fa fa-subway"></i> <span> Dashboard Management Endorsement 1</span></h3>
<?=isset($breadcrum)?$breadcrum:'';?>
<?=isset($message) ? $message : '';?>
<div class="panel panel-primary" style="margin-bottom:10px;">
  <div class="panel-heading"><h3 class="panel-title">Pencarian</h3></div>
  <div class="panel-body" style="padding:3px;">
	<?=form_open('laporan/endorse_subordinate/false','id="form_filter"')?>
	<table align="center" width="100%" cellpadding="3px" cellspacing="0px" class="table-responsive-topdown" border="0" style="border-collapse:collapse;">
		<tr>
			<th align="left" width="180px">Keyword</th>
			<th align="center" width="10px">:</th>
			<td align="left" class="td-responsive">
				<div class="row row-cell">
					<div class="col-sm-12 title">Keyword :</div>
					<div class="col-sm-12 value"><?=form_input(array('name'=>'f_keyword','id'=>'f_keyword','class'=>'form-control filter input-sm trim','placeholder'=>'Masukkan kata kunci di sini.','autocomplete'=>'off','title'=>'Ketik kata kunci di sini.','rel'=>'Kata Kunci'));?></div>
				</div>
			</td>
		</tr>
		<tr>
			<th align="left" width="180px">&nbsp;</th>
			<th align="center" width="10px">&nbsp;</th>
			<td align="left" class="td-responsive">
				<div class="row row-cell">
					<div class="col-sm-12">
						<button class="btn btn-theme" name="show" id="show" value="Cari" type="submit" title="Klik di sini untuk mencari data."><i class="fa fa-search"></i> Cari</button>
						<button class="btn btn-warning" name="show_all" id="show_all" value="Semua" type="submit" title="Klik di sini untuk menampilkan semua data."><i class="fa fa-search-plus"></i> Semua</button>
					</div>
				</div>
			</td>
		</tr>
	</table>
	</form>
  </div>
</div>
<div class="panel panel-primary">
  <div class="panel-body row" style="padding:3px;">
	<div id="tools" class="col-sm-12" style="text-align:right;">
	<button class="btn btn-success btn-sm" id="download_detail_excel" value="Download Excel" type="button" title="Click here to download file as excel."><i class="fa fa-file-excel-o"></i> Download Excel</button>&nbsp;&nbsp;<!--<button class="btn btn-theme btn-sm" id="download_detail_pdf" value="Download Pdf" type="button" title="Click here to download file as pdf."><i class="fa fa-file-pdf-o"></i> Download Pdf</button>-->
	</div>
	<div id="result" class="col-sm-12" style="margin-top:3px;"><?=isset($result)?$result:'';?></div>
  </div>
</div>
<script>
$(document).ready(function(){
	$('#show_all').off().click(function(e){
		$('.filter').val('');
	});

	$('#download_detail_pdf').click(function() {
		location.href = "<?= site_url('laporan/endorse_subordinate_pdf'); ?>?" + $('#form_filter').serialize();
		return false;
	});
	
	$('#download_detail_excel').click(function() {
		location.href = "<?= site_url('laporan/endorse_subordinate_excel'); ?>?" + $('#form_filter').serialize();
		return false;
	});
	
	$('#form_filter').off().submit(function(e){
		$(this).myAjax({
			url : $(this).attr('action'),
			data: 'mt=1&'+$(this).serialize(),
			success: function(data){
				$('#result').html(data);
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});
});
</script>