<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<?=isset($breadcrum)?$breadcrum:'';?>
<?=isset($message) ? $message : '';?>
<?php
	//echo sha1(md5('P4ssf0rBRIll1anc3'));
?>

<script>
function munculTampilan(awards){
				if (awards == "NARASUMBER") {
					document.getElementById("penghargaan").style.display = 'none';
					document.getElementById("organisasi").style.display = 'none';
					document.getElementById("publikasi").style.display = 'none';
				}
				else if (awards == "PENGHARGAAN") {
					document.getElementById("narasumber").style.display = 'none';
					document.getElementById("organisasi").style.display = 'none';
					document.getElementById("publikasi").style.display = 'none';
				}
				else if (awards == "ORGANISASI") {
					document.getElementById("narasumber").style.display = 'none';
					document.getElementById("penghargaan").style.display = 'none';
					document.getElementById("publikasi").style.display = 'none';
				}
				else if (awards == "PUBLIKASI") {
					document.getElementById("penghargaan").style.display = 'none';
					document.getElementById("organisasi").style.display = 'none';
					document.getElementById("narasumber").style.display = 'none';
				}
				else {
					document.getElementById("penghargaan").style.display = 'block';
					document.getElementById("organisasi").style.display = 'block';
					document.getElementById("narasumber").style.display = 'block';
					document.getElementById("publikasi").style.display = 'block';
				}
}

$(document).ready(function(){
	var filter_selected = $('#f_jenis_awards').find(":selected").text();
	munculTampilan(filter_selected);

	$('#show_all').off().click(function(e){
		$('.filter').val('');
	});
	
	$('#download_detail_excel_narasumber').click(function() {
		location.href = "<?= site_url('laporan/narasumber_excel'); ?>?" + $('#form_filter').serialize();
		return false;
	});

	$('#download_detail_excel_achievement').click(function() {
		location.href = "<?= site_url('laporan/achievement_excel'); ?>?" + $('#form_filter').serialize();
		return false;
	});

	$('#download_detail_excel_karya_tulis').click(function() {
		location.href = "<?= site_url('laporan/karya_tulis_excel'); ?>?" + $('#form_filter').serialize();
		return false;
	});

	$('#download_detail_excel_organisasi').click(function() {
		location.href = "<?= site_url('laporan/organisasi_excel'); ?>?" + $('#form_filter').serialize();
		return false;
	});

	// $('#f_jenis_awards').on('change', function() {
	// 		var awards = this.value
	// 		console.log(awards);
	// 		munculTampilan(awards);
	// });

	$('#form_filter').off().submit(function(e){
		console.log(document.getElementById("f_jenis_awards").value);
		var jenis_awards = document.getElementById("f_jenis_awards").value;
		if(jenis_awards == "PENGHARGAAN"){
			$(this).myAjax({
				//url : $(this).attr('action'),
				url :"<?php echo site_url();?>laporan/achievement/false",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#penghargaan').hide();
					$('#narasumber').hide();
					$('#organisasi').hide();
					$('#publikasi').hide();
					$('#hasil').html(data);
					console.log(data);
					$('#ajax-loader').hide();
					document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		else if(jenis_awards == "NARASUMBER"){
			$(this).myAjax({
				//url : $(this).attr('action'),
				url :"<?php echo site_url();?>laporan/narasumber/false",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#penghargaan').hide();
					$('#narasumber').hide();
					$('#organisasi').hide();
					$('#publikasi').hide();
					$('#hasil').html(data);
					$('#ajax-loader').hide();
					document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		else if(jenis_awards == "ORGANISASI"){
				$(this).myAjax({
				//url : $(this).attr('action'),
				url :"<?php echo site_url();?>laporan/organisasi/false",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#penghargaan').hide();
					$('#narasumber').hide();
					$('#organisasi').hide();
					$('#publikasi').hide();
					$('#hasil').html(data);
					$('#ajax-loader').hide();
					document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		else if(jenis_awards == "PUBLIKASI"){
				$(this).myAjax({
				url :"<?php echo site_url();?>laporan/karya_tulis/false",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#penghargaan').hide();
					$('#narasumber').hide();
					$('#organisasi').hide();
					$('#publikasi').hide();
					$('#hasil').html(data);
					$('#ajax-loader').hide();
					document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		else {
				$(this).myAjax({
				url :"<?php echo site_url();?>laporan/filter_awards_new",
				data: 'mt=1&'+$(this).serialize(),
				success: function(data){
					$('#hasil').html(data);
					$('#ajax-loader').hide();
					document.getElementById("f_jenis_awards").reset();
				}
			});
		}
		console.log(jenis_awards);
		e.preventDefault();
	});
});
</script>