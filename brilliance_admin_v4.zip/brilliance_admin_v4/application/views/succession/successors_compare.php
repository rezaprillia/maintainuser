<noscript><meta http-equiv="refresh" content="0; URL=<?=site_url('error/noscript')?>"/></noscript>
<style>
.col-lg-3 {
    width: 20% !important;
}
.col-md-3 {
    width: 20% !important;
}
.col-sm-3 {
    width: 25% !important;
}
.col-sm-4 {
    width: 33% !important;
}
.col-sm-8 {
    width: 65% !important;
}
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 400px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

.button-card {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  /*background-color: #ec971f;*/
  background-color: #5cb85c;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.link-card {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

.button-card:hover, .link-card:hover {
  opacity: 0.7;
}
.sc_container {
    position: relative;
    text-align: center;
    color: #000;
	/*border-radius: 20px;
	border: 2px solid #0155AA;
	margin:10px;*/
}
.top-left {
    position: absolute;
    top: 5px;
    left: 16px;
	background:#0155AA;
	border: 1px solid #000;
	border-radius: 5px;
}
.bottom-right {
    position: absolute;
    bottom: -15px;
    right: 16px;
	background:#0155AA;
	border: 1px solid #000;
	border-radius: 5px;
}
.top-left-first-content{
	color:#fff;
	font-family: arial;
	font-wieght:bold;
	font-size: 8px;
	margin-left:3px;
	margin-top:3px;
}
.top-left-second-content{
	color:#fff;
	font-family: arial;
	font-wieght:bold;
	font-size:40px;
	margin-left:15px;
	margin-right:15px;
}

.div-second-content{
	top:0;
}

.bottom-right-first-content{
	color:#fff;
	font-family: arial;
	font-wieght:bold;
	font-size: 8px;
	margin-left:3px;
	margin-top:3px;
}
.bottom-right-second-content{
	color:#fff;
	font-family: arial;
	font-wieght:bold;
	font-size:30px;
	margin-left:15px;
	margin-right:15px;
}

.badge-area{
	position:absolute;
	width: 145px;
	top: 183px;
	left: 20px;
}

.badge-bsm{
	position:absolute;
	top: 10px;
	right: 2px;
}



</style>
<div class="modal-header">
<h4 class="modal-title">Succession Plan - <?=isset($hilfm->htext)?$hilfm->htext:'*'?> | <?=isset($ct->corp_title)?$ct->corp_title:'*'?> (<?=isset($organization->MYNAME)?$organization->MYNAME:'*'?>), Jobgrade : <?=isset($keyjobs->jobgrade)?$keyjobs->jobgrade:'*'?></h4>
</div>

 <div class="modal-body">
	<div id="modal_body">
		<div align="left" style="margin-bottom:5px;"><button class="btn btn-warning btn-sm back_btn" id="back_btn" value="Back" type="button" title="Click here to back."><i class="fa fa-arrow-left"></i> Back</button></div>
		<div class="row">
			<?php
				if(count($successors) > 0){
				$slice = 0;
				$total_successor = count($successors);
				if($total_successor == 1)
					$slice = 12;
				else if($total_successor == 2)
					$slice = 6;
				else if($total_successor >= 3)
					$slice = 4;
				
				$no = 1;

				/* Define URL to OSP */
				$arr_pernr = array();
				$arr_name = array();
				$id_bucket = isset($talent_bucket->IdBucket)?$talent_bucket->IdBucket:0;
				
				foreach($successors as $idx => $item){
					$arr_pernr[] = isset($item->Pernr)?$item->Pernr:'-';
					$arr_name[] = isset($item->Nama)?$item->Nama:'-';
				}

				$id_bucket = urlencode(base64_encode($id_bucket));
				/* End Defined URL */

				foreach($successors as $item){
	
			?>
			<div class="col-sm-4 col-md-<?=$slice;?> col-lg-<?=$slice;?>">
				<div class="card">
				  <?php
					$file_image = 'https://bristars.bri.co.id/bristars/foto/get/'.urlencode(base64_encode($item->Pernr)).'/L';
				  ?>
				  <div class="sc_container">
					<img src="<?=$file_image;?>" alt="John" style="width:200px;margin-top:5px;height:250px;">
					<div class="badge-area">
						<?php
							$corp_title_array = array();
							if($filter['corp_title_id'] == 'SM' || $filter['corp_title_id'] == 'AVP'){
								$corp_title_array = array('SM', 'AVP');
							}
							elseif($filter['corp_title_id'] == 'SEVP' || $filter['corp_title_id']== 'DIR'){
		
								$corp_title_array = array('SEVP', 'DIR');
							}
							else{
								$corp_title_array = array($filter['corp_title_id']);
							}
							if(isset($item->EmployeeAspiration)){
								if($item->EmployeeAspiration){
									echo '<img src="'.base_url().'sources/images/badge_ea.png?mt=1" title="Employee Aspiration" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							else{
								$ea = $this->succession_model->getEmployeeAspiration($filter['orgeh'], $filter['hilfm'], $corp_title_array, $item->Pernr);
								if($ea){
									echo '<img src="'.base_url().'sources/images/badge_ea.png?mt=1" title="Employee Aspiration" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							if(isset($item->ManagementEndorsement)){
								if($item->ManagementEndorsement){
									echo '<img src="'.base_url().'sources/images/badge_me.png?mt=1" title="Management Endorsement 1" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							else{
								$me = $this->succession_model->getManagementEndorsement($filter['orgeh'], $filter['hilfm'], $corp_title_array, $item->Pernr);
								if($me){
									echo '<img src="'.base_url().'sources/images/badge_me.png?mt=1" title="Management Endorsement 1" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							if(isset($item->ManagementEndorsement2)){
								if($item->ManagementEndorsement2){
									echo '<img src="'.base_url().'sources/images/badge_me2.png?mt=1" title="Management Endorsement 2" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							else{
								$me2 = $this->succession_model->getManagementEndorsement2($filter['orgeh'], $filter['hilfm'], $corp_title_array, $item->Pernr);
								if($me2){
									echo '<img src="'.base_url().'sources/images/badge_me2.png?mt=1" title="Management Endorsement 2" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							if(isset($item->SuccessorEndorsement)){
								if($item->SuccessorEndorsement){
									echo '<img src="'.base_url().'sources/images/badge_se.png?mt=1" title="Successor Endorsement" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							else{
								$se = $this->succession_model->getSuccessorEndorsement($filter['orgeh'], $filter['hilfm'], $corp_title_array, $item->Pernr);
								if($se){
									echo '<img src="'.base_url().'sources/images/badge_se.png?mt=1" title="Successor Endorsement" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							if(isset($item->AwardWinner)){
								if($item->AwardWinner){
									echo '<img src="'.base_url().'sources/images/badge_bea.png?mt=1" title="Award Winner" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							else{
								$aw = $this->succession_model->getAwardWinner($item->Pernr);
								if($aw){
									echo '<img src="'.base_url().'sources/images/badge_bea.png?mt=1" title="Award Winner" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							if(isset($item->CultureAgent)){
								if($item->CultureAgent){
									echo '<img src="'.base_url().'sources/images/badge_ca.png?mt=1" title="Culture Agent" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							else{
								$ca = $this->succession_model->getCultureAgent($item->Pernr);
								if($ca){
									echo '<img src="'.base_url().'sources/images/badge_ca.png?mt=1" title="Culture Agent" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							if(isset($item->Top5BLDPRank)){
								if($item->Top5BLDPRank){
									echo '<img src="'.base_url().'sources/images/badge_t5.png?mt=1" title="Top 5 BLDP Rank" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							else{
								$t5 = $this->succession_model->getTop5BLDPRank($item->Pernr);
								if($t5){
									echo '<img src="'.base_url().'sources/images/badge_t5.png?mt=1" title="Top 5 BLDP Rank" style="width:30px;height:35px;margin-right:5px;">';
								}
							}
							
						?>
					</div>
					<div class="badge-bsm">
						<?php
							if(isset($item->BrilianSocietyMember)){
								if($item->BrilianSocietyMember){
									echo '<img src="'.base_url().'sources/images/badge_bsm.png?mt=2" title="Brilian Society Member" style="width:50px;height:60px;">';
								}
							}
							else{
								$bsm = $this->succession_model->getBrilianSocietyMember($item->Pernr);
								if($bsm){
									echo '<img src="'.base_url().'sources/images/badge_bsm.png?mt=2" title="Brilian Society Member" style="width:50px;height:60px;">';
								}
							}
						?>
					</div>
					<div class="top-left">
						<div class="top-left-first-content" align="left">Rank</div>
						<div class="div-second-content" style="margin-top:-15px;">
							<span class="top-left-second-content"><?=isset($item->SetRank)?$item->SetRank:$no;?></span>
						</div>
					</div>
					<div class="bottom-right">
						<div class="bottom-right-first-content" align="left">Overall Score</div>
						<div class="div-second-content" style="margin-top:-8px;">
							<span class="bottom-right-second-content"><?=isset($item->OverallCompabilityScore)?$item->OverallCompabilityScore:'-';?></span>
						</div>
					</div>
				  </div>
				  <?php
					$nama = isset($item->Nama)?$item->Nama:'-';
					if(strlen($nama) > 15 && false) {
						$nama = substr($nama, 0, 15) . '...';
					}
				?>
				  <h3 style="color:#000;" title="<?=isset($item->Nama)?$item->Nama:'-'?>"><?=$nama;?></h3>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							Jabatan
						</div>
						<div class="col-sm-8"align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?=isset($item->Htext)?$item->Htext:'-'?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							Uker
						</div>
						<?php
							$unit_kerja = isset($item->CostCenter)?$item->CostCenter:'-';
							if(strlen($unit_kerja) > 30) {
								$unit_kerja = substr($unit_kerja, 0, 30) . '...';
							}
						?>
						<div title="<?=isset($item->CostCenter)?$item->CostCenter:'-'?>" class="col-sm-8"align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?=$unit_kerja;?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							CT
						</div>
						<?php
							$ct = isset($item->CorpTitleDesc)?$item->CorpTitleDesc:'-';
							if(strlen($ct) > 24 && false) {
								$ct = substr($ct, 0, 23) . '...';
							}
						?>
						<div class="col-sm-8" align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?=$ct;?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							JG
						</div>
						<div class="col-sm-8" align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?=isset($item->JobGrade)?$item->JobGrade:'-';?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							JF
						</div>
						<div class="col-sm-8" align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?=isset($item->Expertise)?$item->Expertise:'-';?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							SMK
						</div>
						<div class="col-sm-8"align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?php
								$smk = $this->talent_model->get_history_smk($item->Pernr);
								if(count($smk) > 0){
									$arr_smk = array();
									foreach($smk as $y){
										$arr_smk[] = isset($y->score)?$y->score:'-';
									}
									echo implode(' / ', $arr_smk);
								}
								else
									echo '-';
							?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							Usia
						</div>
						<div class="col-sm-8"align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?=isset($item->TanggalLahir)?$this->libs->date_diff($item->TanggalLahir,date('Y-m-d')):'';?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							MKCT
						</div>
						<div class="col-sm-8"align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?php
								$mkct = $this->talent_model->get_masa_kerja($item->Pernr, 'MKCT');
								echo isset($mkct->mk)?$mkct->mk:'-';
							?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							MKJ
						</div>
						<div class="col-sm-8"align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?php
								$mkj = $this->talent_model->get_masa_kerja($item->Pernr, 'MKJ');
								echo isset($mkj->mk)?$mkj->mk:'-';
							?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							MKU
						</div>
						<div class="col-sm-8"align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?php
								$mku = $this->talent_model->get_masa_kerja($item->Pernr, 'MKU');
								echo isset($mku->mk)?$mku->mk:'-';
							?>
						</div>
					</div>
					<div class="row" style="margin:3px;">
						<div class="col-sm-2" align="center" style="width:25%;margin-left:10px;background:#ec6f24;color:#ffff;padding:3px;border: 1px solid #000;border-radius: 5px;">
							ASC
						</div>
						<div class="col-sm-8"align="left"  style="color:#000;margin-left:3px;margin-right:10px;padding:3px;border: 0.5px solid #000;border-radius: 5px;">
							<?php
								$asm = $this->option_model->get_hasil_asm_das($item->Pernr);
								$readiness = isset($asm->readiness)?$asm->readiness:'-';
								if(strlen($readiness) > 14 && false) {
									$readiness = substr($readiness, 0, 14) . '...';
								}
								echo '<span>'.$readiness.'</span>';
								echo  ' / ';
								echo isset($asm->ratas_kompetensi)?($asm->ratas_kompetensi==0?'2.00':$asm->ratas_kompetensi):'-';
							?>
						</div>
					</div>
				  <div style="margin: 15px 0;">
				
				 </div>
				 
				 <p>
				 <button class="button-card cv" id="<?=isset($item->Pernr)?$item->Pernr:'';?>">Detail CV</button>
				 <?php
						$new_arr_pernr = array();
						$new_arr_name = array();
						$new_arr_pernr[] = isset($item->Pernr)?$item->Pernr:'';
						$new_arr_name[] = isset($item->Nama)?$item->Nama:'';
						foreach($arr_pernr as $arr){
							if(isset($item->Pernr)){
								if($arr != $item->Pernr){
									$new_arr_pernr[] = $arr;
								}
							}
						}
						foreach($arr_name as $arr){
							if(isset($item->Nama)){
								if($arr != $item->Nama){
									$new_arr_name[] = $arr;
								}
							}
						}
						$list_pernr = implode('|', $new_arr_pernr);
						$list_pernr = urlencode(base64_encode($list_pernr));
						$list_name = implode('|', $new_arr_name);
						$list_name = urlencode(base64_encode($list_name));
						$osp_url = $this->config->item('osp_url') . 'candidates='.$list_pernr.'&id_bucket='.$id_bucket.'&candidates_name='.$list_name;
					 ?>
					 <!--<a class="button-card osp" target="_blank" href="<?=isset($osp_url)?$osp_url:'';?>" id="osp=<?=isset($item->Pernr)?$item->Pernr:'';?>">One Sheet Profile</a>-->
				 </p>

				</div>
			</div>
			<?php
				$no++;
				}
			}
			else{
				echo '<div class="col-sm-12 col-md-12 col-lg-12">';
				echo $this->libs->generate_message('danger','Tidak ada successor yang dipilih.');
				echo '</div>';
			}
			?>
		</div>
		<?=form_open('succession/save_candidates','id="form_data_compare"')?>
			<?=isset($filter)?form_hidden($filter):''?>
		<?php
		if(count($successors) > 0 && $filter['type'] == 'normal'){
		?>
		<div class="panel panel-primary" style="margin-bottom:10px;">
			<div class="panel-heading"><h3 class="panel-title">Form Save Candidates - <?=isset($hilfm->htext)?$hilfm->htext:'*'?> (<?=isset($organization->MYNAME)?$organization->MYNAME:'*'?>)</h3></div>
			<div class="panel-body">
				<div class="row">
					<div class="col-md-12">Bucket Name : <?=form_input(array('name' => 'bucket_name', 'id' => 'bucket_name', 'class' => 'required form-control input-sm', 'placeholder' => 'Bucket Name', 'rel' => 'Bucket Name', 'value' => ''));?>
					<span class="red msg_bucket_name" id="msg_bucket_name"><?=form_error('bucket_name',' ',' ')?></span>
					</div>
					<div class="col-md-12">
						<br>
						<button class="btn btn-warning btn-sm back_btn" id="back_btn" value="Back" type="button" title="Click here to back."><i class="fa fa-arrow-left"></i> Back</button>&nbsp;&nbsp;
						<button class="btn btn-sm btn-theme save" name="save" id="save" value="Simpan" type="button" title="Klik di sini untuk simpan."><i class="fa fa-floppy-o"></i> Save Candidates</button>
					</div>
				</div>
			</div>
		</div>
		<?php
		}
		?>
		</form>
	</div>
</div>
<script>
$(document).ready(function(){
	$('.back_btn').off().click(function(e){
		$(this).myAjax({
			url : '<?=site_url('succession').'/'.$filter['source']?>',
			data: 'mt=1&'+$('#form_data_compare').serialize(),
			success: function(data){
				$('#general_popup .modal-dialog .modal-content').empty();
				$('#general_popup .modal-dialog').removeClass('modal-lg modal-md modal-sm modal-hav modal-successor modal-compare modal-cv').addClass('modal-successor');
				$('#general_popup .modal-dialog .modal-content').html(data);
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});
	$(".cv").off().click(function(e){
		var id = $(this).attr('id');
		$(this).myAjax({
			url : '<?=site_url('talent/detail_pekerja')?>',
			data: 'mt=1&ctrl=succession&source=successors_compare&pernr='+id+'&'+$('#form_data_compare').serialize(),
			success: function(data){
				$('#general_popup .modal-dialog .modal-content').empty();
				$('#general_popup .modal-dialog').removeClass('modal-lg modal-md modal-sm modal-hav modal-successor modal-compare modal-cv').addClass('modal-lg');
				$('#general_popup .modal-dialog .modal-content').html(data);
				$('#ajax-loader').hide();
			}
		});
		e.preventDefault();
	});

	$(".save").off().click(function(e){
		var error = false;
		error = $('#form_data_compare').formValidation(error);
		if(!error){
			if(confirm('Apakah anda yakin ?')){
				$(this).myAjax({
					url :$('#form_data_compare').attr('action'),
					data: 'mt=1&'+$('#form_data_compare').serialize(),
					success: function(data){
						$('#general_popup').modal('hide');
						$('.main-content').html(data);
						$('#ajax-loader').hide();
					}
				});
			}
		}
		e.preventDefault();
	});
});
</script>